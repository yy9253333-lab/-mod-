package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** 蓝色魔力条与当前刻印术式提示。 */
public final class PrayerHud {
    public static final IGuiOverlay OVERLAY = PrayerHud::render;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int barWidth = Math.min(122, Math.max(60, width / 3));
        int barHeight = 5;
        int x = 8;
        int y = height - 37;
        float ratio = PrayerState.maxMana <= 0 ? 0 : Math.max(0, Math.min(1, PrayerState.mana / (float) PrayerState.maxMana));
        g.fill(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, 0xAA10151C);
        g.fill(x, y, x + barWidth, y + barHeight, 0xFF263441);
        g.fill(x, y, x + (int) (barWidth * ratio), y + barHeight, 0xFF3E9DCE);
        g.drawString(mc.font, "魔力 " + PrayerState.mana + "/" + PrayerState.maxMana, x + barWidth + 6, y - 1, 0xFFBFE7FF);
        String mastery = String.format(java.util.Locale.ROOT, "波动 %.0f%% · 熟练 %.1f · 领悟 %.1f%s",
            PrayerState.instability * 100.0F, PrayerState.proficiency, PrayerState.comprehension,
            PrayerState.noFocusUnlocked ? " · 无法器施法已解锁" : "");
        g.drawString(mc.font, mastery, x, y - 24, 0xFFB9C9D5);
        if (PrayerState.charging || PrayerState.chargeTicks > 0) {
            g.drawString(mc.font, "蓄力 " + PrayerState.chargeTicks + "t · 复制 ×" + PrayerState.duplicates, x, y - 35, 0xFFFFD37A);
        }
        if (!PrayerState.active.isEmpty()) {
            SpellStats st = PrayerState.activeStats;
            String name = st == null ? PrayerState.active : st.name;
            String cooldown = PrayerState.onCooldown() ? String.format(java.util.Locale.ROOT, " · 冷却 %.1fs", PrayerState.cooldownLeft()) : "";
            g.drawString(mc.font, name + cooldown, x, y - 12, PrayerState.onCooldown() ? 0xFFE0A36A : 0xFFFFD37A);
        }
        renderAim(g, mc, width, height);
    }

    /**
     * 准星射线反馈：手持魔导书或法杖瞄准时，在准星上画四角锁定框并显示命中距离，
     * 锁定实体则标出目标名。纯 HUD 表现，判定仍以服务端复核为准。
     */
    private static void renderAim(GuiGraphics g, Minecraft mc, int width, int height) {
        if (mc.screen != null || !AimTracker.aiming() || !AimTracker.fresh()) return;
        int cx = width / 2, cy = height / 2;
        boolean lock = AimTracker.locked != null;
        int col = lock ? 0xFFFFD37A : 0x99BFE7FF;
        int o = 5, len = 4; // 锁定框内圈偏移与边长
        // 四角括号
        g.fill(cx - o - len, cy - o - 1, cx - o, cy - o, col);
        g.fill(cx - o - 1, cy - o - len, cx - o, cy - o, col);
        g.fill(cx + o, cy - o - 1, cx + o + len, cy - o, col);
        g.fill(cx + o, cy - o - len, cx + o + 1, cy - o, col);
        g.fill(cx - o - len, cy + o, cx - o, cy + o + 1, col);
        g.fill(cx - o - 1, cy + o, cx - o, cy + o + len, col);
        g.fill(cx + o, cy + o, cx + o + len, cy + o + 1, col);
        g.fill(cx + o, cy + o + 1, cx + o + 1, cy + o + len, col);
        // 距离与目标名
        String info = String.format(java.util.Locale.ROOT, "射线 %.1fm", Math.max(0, AimTracker.distance));
        if (lock) info += " · 锁定 " + AimTracker.lockedName;
        g.drawCenteredString(mc.font, info, cx, cy + 12, lock ? 0xFFFFD37A : 0xB3BFE7FF);
    }

    private PrayerHud() {}
}
