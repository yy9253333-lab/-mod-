package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.client.Minecraft;
import java.util.*;

/** 客户端缓存的玩家《祈愿》数据（由服务器同步包更新）。 */
public final class PrayerState {
    public static int mana = 0;
    public static int maxMana = 200;
    public static float instability = 1.0F;
    public static float proficiency = 0.0F;
    public static float comprehension = 0.0F;
    public static boolean noFocusUnlocked = false;
    public static boolean charging = false;
    public static int chargeTicks = 0;
    public static int duplicates = 1;
    public static final Set<String> ever = new LinkedHashSet<>();
    public static String active = "";
    /** 最近一次成功刻印的符文串，用于一键恢复到编辑区。 */
    public static String lastEngraved = "";
    public static long cooldownEnd = 0;
    public static boolean guideDone = false;
    public static boolean creative = false;
    public static final List<String[]> presets = new ArrayList<>();
    public static final List<String> recent = new ArrayList<>();
    public static SpellStats activeStats = null;
    /** 施法特效脉冲：服务端 CastFx 包到达时写入当前 gameTime，渲染层据此点亮视野前法阵。 */
    public static long castPulseTick = Long.MIN_VALUE;
    public static int castPulseColor = 0x3D9CB8;

    public static void apply(CompoundTag t) {
        mana = t.getInt("mana");
        maxMana = t.getInt("max");
        instability = t.getFloat("instability");
        proficiency = t.getFloat("proficiency");
        comprehension = t.getFloat("comprehension");
        noFocusUnlocked = t.getBoolean("no_focus_unlocked");
        charging = t.getBoolean("charging");
        chargeTicks = t.getInt("charge_ticks");
        duplicates = Math.max(1, t.getInt("duplicates"));
        creative = t.getBoolean("creative");
        ever.clear();
        for (String r : t.getString("ever").split("\\|")) if (Runes.contains(r)) ever.add(r);
        active = t.getString("active");
        lastEngraved = t.getString("last_engraved");
        cooldownEnd = t.getLong("cooldown");
        guideDone = t.getBoolean("guide");
        recent.clear();
        ListTag recentTag = t.getList("recent", 8);
        for (int i = 0; i < recentTag.size() && recent.size() < PrayerData.RECENT_SLOTS; i++) {
            String rune = recentTag.getString(i);
            if (!PrayerData.parse(rune).isEmpty() && !recent.contains(rune)) recent.add(rune);
        }
        presets.clear();
        for (int i = 0; i < PrayerData.PRESET_SLOTS; i++) presets.add(new String[]{"", ""});
        ListTag list = t.getList("presets", 10);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            int slot = c.getInt("slot");
            if (slot >= 0 && slot < presets.size()) presets.set(slot, new String[]{c.getString("name"), c.getString("runes")});
        }
        activeStats = active.isEmpty() ? null : SpellCalculator.calculate(PrayerData.parse(active));
    }

    public static boolean onCooldown() {
        long now = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
        return now < cooldownEnd;
    }

    public static double cooldownLeft() {
        long now = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
        return Math.max(0, (cooldownEnd - now) / 20.0);
    }

    private PrayerState() {}
}
