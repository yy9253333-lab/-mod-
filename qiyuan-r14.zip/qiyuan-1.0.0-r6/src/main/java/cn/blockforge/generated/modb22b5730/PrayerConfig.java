package cn.blockforge.generated.modb22b5730;

import net.minecraftforge.common.ForgeConfigSpec;

/** 《祈愿》服务端权威数值配置；多人游戏中以服务端配置为准。 */
public final class PrayerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue INITIAL_CAPACITY;
    public static final ForgeConfigSpec.IntValue MAX_CAPACITY;
    public static final ForgeConfigSpec.IntValue NO_FOCUS_UNLOCK_CAPACITY;
    public static final ForgeConfigSpec.DoubleValue COMPREHENSION_UNLOCK;
    public static final ForgeConfigSpec.IntValue GROWTH_WINDOW_TICKS;
    public static final ForgeConfigSpec.IntValue CASTS_PER_CAPACITY;
    public static final ForgeConfigSpec.IntValue CRYSTAL_CAPACITY_GAIN;
    public static final ForgeConfigSpec.IntValue EXHAUSTION_NAUSEA_TICKS;
    public static final ForgeConfigSpec.DoubleValue EXHAUSTION_RATIO;
    public static final ForgeConfigSpec.IntValue MAX_DUPLICATES;
    public static final ForgeConfigSpec.IntValue MAX_CHARGE_TICKS;
    public static final ForgeConfigSpec.DoubleValue VISION_ANCHOR_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue INSTABILITY_MAX_DEVIATION;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("mana");
        INITIAL_CAPACITY = b.comment("新玩家初始魔力上限").defineInRange("initialCapacity", 200, 1, 2000);
        MAX_CAPACITY = b.comment("魔力上限硬上限").defineInRange("maxCapacity", 2000, 200, 2000);
        NO_FOCUS_UNLOCK_CAPACITY = b.comment("无法器施法所需魔力上限").defineInRange("noFocusUnlockCapacity", 1000, 200, 2000);
        COMPREHENSION_UNLOCK = b.comment("无法器施法所需魔法领悟值").defineInRange("comprehensionUnlock", 10.0, 0.0, 10000.0);
        GROWTH_WINDOW_TICKS = b.comment("新手快速成长窗口，默认 3600 秒（20 TPS）").defineInRange("growthWindowTicks", 72000, 1, 7200000);
        CASTS_PER_CAPACITY = b.comment("窗口期内每成功施法多少次增加 1 点魔力上限").defineInRange("castsPerCapacity", 5, 1, 10000);
        CRYSTAL_CAPACITY_GAIN = b.comment("每枚魔力晶石增加的魔力上限").defineInRange("crystalCapacityGain", 5, 0, 1000);
        EXHAUSTION_RATIO = b.comment("魔力枯竭阈值占魔力上限的比例").defineInRange("exhaustionRatio", 0.05, 0.0, 0.5);
        EXHAUSTION_NAUSEA_TICKS = b.comment("魔力枯竭恶心效果时长（tick）").defineInRange("exhaustionNauseaTicks", 100, 1, 72000);
        b.pop();
        b.push("casting");
        MAX_DUPLICATES = b.comment("多重施法数量硬上限").defineInRange("maxDuplicates", 8, 1, 64);
        MAX_CHARGE_TICKS = b.comment("蓄力计入伤害与消耗计算的最大 tick 数").defineInRange("maxChargeTicks", 100, 1, 1200);
        INSTABILITY_MAX_DEVIATION = b.comment("魔力不稳定度为 1 时的最大随机轨迹偏移").defineInRange("instabilityMaxDeviation", 0.18, 0.0, 2.0);
        b.pop();
        b.push("visionRune");
        VISION_ANCHOR_DISTANCE = b.comment("视符文法阵相对摄像机的锚定距离").defineInRange("anchorDistance", 2.0, 0.25, 16.0);
        b.pop();
        SPEC = b.build();
    }

    private PrayerConfig() {}
}
