# 《祈愿》r6 审查修复记录（2026-10-17）

基线：上传的 `qiyuan-1.0.0-r6.zip` 源码（Forge 1.20.1 / 47.4.0 / Java 17）。
**状态说明：源码已修改；编译未执行；游戏内未测试。**
本环境无法访问 Forge/Mojang/Maven 仓库，没有 Minecraft 依赖，因此 `gradle build` 与实机测试均未做。
唯一实际执行过的验证：`bash tools/logic-selftest/run.sh`（不依赖 Minecraft 的纯逻辑自检），结果见文末。

## 一、本次修改的文件与原因

| 文件 | 修改 | 原因 |
|---|---|---|
| `spell/SpellCalculator.java` | `hash()` 末尾 `& 0xffffffff` → `& 0x7fffffff` | `0xffffffff` 在 Java 里是 int `-1`，`h & -1` 仍可为负；`makeName` 用 `h % n` 当数组下标，负数抛 `ArrayIndexOutOfBoundsException`。自由组合（图鉴无匹配）的术式约 10.5% 会在推演/刻印/施法时抛异常。 |
| `block/entity/AnchorRuneBlockEntity.java`<br>`block/entity/InscribedRuneBlockEntity.java` | `worldPos` → `worldPosition` | `BlockEntity` 的字段是 `worldPosition`，`worldPos` 不存在，源码无法编译。 |
| `block/ResonanceTableBlock.java` | `level.sendParticles` 改为 `ServerLevel` 判断后调用 | `Level` 没有 `sendParticles`（仅 `ServerLevel` 有），无法编译。 |
| `net/PrayerNet.java`<br>新增 `client/ClientPacketHandlers.java` | 客户端分支（打开魔导书、同步数据、施法脉冲）改经 `DistExecutor.unsafeRunWhenOn` 调用新增的客户端处理类 | 公共类 `PrayerNet` 直接引用 `Minecraft`/`BookScreen`，专用服务器上校验该类时可能因 `net.minecraft.client.*` 缺失而 `NoClassDefFoundError`。 |
| `entity/SpellCircleEntity.java` | 重写 `getBoundingBoxForCulling()` | 实体碰撞箱仅 1×0.1，法阵可达数格、可竖在墙面；圆心离开屏幕或贴墙时整座法阵被视锥剔除而突然消失。 |
| `spell/SpellCaster.java`<br>`entity/SpellOrbEntity.java` | 新增 `spawnProjectileImpactCircle`；飞弹命中方块/实体时在命中点生成世界法阵（位置、法线服务端确定后固定） | 源码注释声明“命中后在真实命中位置生成”，但并未实现，投射型术式从头到尾看不到法阵。 |
| `entity/SpellOrbEntity.java` | 客户端按同步速度预测位置 | 实体 `updateInterval(10)`，客户端又不自行移动，飞弹每 0.5 秒才跳一次位置。 |
| `tools/logic-selftest/*`（新增） | 纯逻辑自检脚本 | 复现并回归验证上述 `hash` 问题。 |

没有改动：mod ID、注册名、资源路径、符文/术式/图鉴数据、存档字段、`build.gradle`、`gradle.properties`、`mods.toml`。

## 二、问题清单与状态

### 已确认并已改源码（均未编译、未实机验证）
1. 自由组合术式抛 `ArrayIndexOutOfBoundsException`（`SpellCalculator.hash`）——**已复现**：原代码 200000 组随机组合中 21032 组抛异常；修改后 0 组。
2. `worldPos` 字段不存在 ×2 个文件（编译错误）——按 Forge/Mojang 映射核对，非运行复现。
3. `Level.sendParticles` 不存在（编译错误）。
4. `PrayerNet` 公共类引用客户端类（专用服务器风险）。
5. 法阵剔除盒过小。
6. 投射型术式命中后无法阵。
7. 飞弹客户端位置卡顿。

### r6 源码里已经正确、本次只审查未改动
- 仅拿出/切换法杖、魔导书不创建法阵：`ViewCircleRenderer` 是空类；法阵实体只在 `SpellCaster.cast` 成功路径中生成；没有每 tick 创建。
- 法阵定位：服务端 `traceAim`（方块+实体射线）确定命中点与法线，`spawnAt` 在 `addFreshEntity` 前设置坐标与法线；渲染器只在命中面法线方向抬高 0.035，不引用相机坐标，不跟随玩家。
- 生命周期：mode 0 视觉法阵 24 tick 后服务端 `discard`；mode 1 持续区域按术式持续时间；区域重复结算为 `repeat=true`，不再重复生成法阵/召唤/造方块。
- `RenderUtil.entityVertex` 按 NEW_ENTITY 顺序写满位置、颜色、UV0、overlay、lightmap、法线后才 `endVertex()`；`CircleRenderer`/`OrbRenderer` 共用。源码中没有其他 `BufferBuilder`/`endVertex` 写入点。
- 图鉴分页：22949 条图鉴（2295 页，含第 23 页）全部 `calculate` 通过；渲染层有空值与异常兜底。

### 无法确认 / 缺少复现条件（不声称已修复）
- `BufferBuilder: Not filled all elements of the vertex`：当前源码路径审查未发现不完整顶点，但原始崩溃堆栈、日志均未提供，**无法确认历史崩溃是否已消除**；也不能把原因归于 Android/FCL。
- `mod_b22b5730:spell_circle` 生成崩溃：未提供日志。已确认并修复的 `hash` 异常是组合术式时最可能的纯代码崩溃点，但是否就是当时那次崩溃，需要用新日志验证。
- 图鉴第 23 页、“禁忌”闪退：纯逻辑上 22949 条（含禁忌阶）均无异常，GUI 绘制路径未实机运行，**无法复现，未声称修复**。
- 上传的 `qiyuan-1.0.0-r6-forge-1.20.1.jar` 与本源码不一致（JAR 中有 `applyAnchorZone`、`AnchorRuneBlockEntity.clear/canEdit`、`effectiveTargets` 等本源码没有的成员），说明 JAR 来自比本源码更新的版本。请确认以哪份为准。

## 三、构建与测试建议

构建（需联网到 Forge Maven，JDK 17，Gradle 8.x）：
```
gradle build --no-daemon        # 或 gradle buildDesktop / gradle buildAndroid
bash tools/logic-selftest/run.sh
```
PC 端实测：
1. 手持法杖/魔导书反复切换其他物品 → 不应出现任何法阵。
2. 对地面、墙面、天花板、生物、空中分别施法 → 法阵贴合命中面，转头走动不漂移，约 1.2 秒后消失。
3. 连续快速施法、边跑边施法 → 每次一个独立法阵，不叠加残留。
4. 火弹/冰刺等投射术式 → 发射时无法阵，命中处出现法阵。
5. 自由拼 3–8 枚符文（避开图鉴条目）刻印并施法 → 不再报错；翻到图鉴第 23 页、点“禁忌”条目。
6. 专用服务器：启动并让客户端连入，打开魔导书。
Android FCL：同样的 1–5 项；若再出现 `Not filled all elements`，请保留完整 `latest.log` 与崩溃报告，并记录渲染器（MobileGlues/ANGLE）与是否装了光影类模组。FCL 实测本次未做。

## 四、自检结果（本环境实际执行）
```
原代码：  random ok=178968 fail=21032（全部为 ArrayIndexOutOfBounds）
修改后：  codex entries=22949 ok=22949 fail=0；random ok=200000 fail=0
```
