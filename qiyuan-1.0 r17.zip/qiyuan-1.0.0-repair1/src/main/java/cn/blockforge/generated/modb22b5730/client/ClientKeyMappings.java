package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientKeyMappings {
    private static final String CATEGORY = "key.categories.mod_b22b5730";
    public static final KeyMapping PREVIOUS = new KeyMapping("key.mod_b22b5730.recent_previous",
        KeyConflictContext.IN_GAME, KeyModifier.ALT, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Q, CATEGORY);
    public static final KeyMapping NEXT = new KeyMapping("key.mod_b22b5730.recent_next",
        KeyConflictContext.IN_GAME, KeyModifier.ALT, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_E, CATEGORY);
    public static final KeyMapping CHARGE = new KeyMapping("key.mod_b22b5730.spell_charge",
        KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);
    private static final net.minecraftforge.client.settings.IKeyConflictContext VOICELESS_CONTEXT = new net.minecraftforge.client.settings.IKeyConflictContext() {
        @Override public boolean isActive() { return KeyConflictContext.IN_GAME.isActive() && PrayerState.noFocusUnlocked; }
        @Override public boolean conflicts(net.minecraftforge.client.settings.IKeyConflictContext other) { return other == this || other == KeyConflictContext.IN_GAME; }
    };
    public static final KeyMapping ALT_RIGHT_CAST = new KeyMapping("key.mod_b22b5730.alt_right_cast",
        VOICELESS_CONTEXT, KeyModifier.ALT, InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_RIGHT, CATEGORY);
    public static final KeyMapping OPEN_TALENTS = new KeyMapping("key.mod_b22b5730.talents",
        KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY);

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(PREVIOUS);
        event.register(NEXT);
        event.register(CHARGE);
        event.register(ALT_RIGHT_CAST);
        event.register(OPEN_TALENTS);
    }

    private ClientKeyMappings() {}
}
