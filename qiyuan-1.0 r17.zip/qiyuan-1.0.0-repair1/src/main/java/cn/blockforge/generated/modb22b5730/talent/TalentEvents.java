package cn.blockforge.generated.modb22b5730.talent;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.entity.SpellOrbEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID)
public final class TalentEvents {
 @SubscribeEvent public static void attach(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> e){if(e.getObject() instanceof Player){TalentData.Provider provider=new TalentData.Provider();e.addCapability(GeneratedMod.rl("talent"),provider);e.addListener(provider::invalidate);}}
 @SubscribeEvent public static void clone(PlayerEvent.Clone e){
  e.getOriginal().reviveCaps(); e.getEntity().reviveCaps();
  try {e.getOriginal().getCapability(TalentData.CAP).ifPresent(old->e.getEntity().getCapability(TalentData.CAP).ifPresent(now->{now.deserializeNBT(old.serializeNBT());TalentTree.apply(e.getEntity());}));}
  finally {e.getOriginal().invalidateCaps();}
 }
 @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e){TalentTree.apply(e.getEntity());if(e.getEntity() instanceof net.minecraft.server.level.ServerPlayer p)TalentNet.send(p);}
 @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e){TalentTree.apply(e.getEntity());if(e.getEntity() instanceof net.minecraft.server.level.ServerPlayer p)TalentNet.send(p);}
 @SubscribeEvent public static void change(PlayerEvent.PlayerChangedDimensionEvent e){TalentTree.apply(e.getEntity());if(e.getEntity() instanceof net.minecraft.server.level.ServerPlayer p)TalentNet.send(p);}
 @SubscribeEvent public static void hurt(LivingHurtEvent e){
  if(e.getEntity().level().isClientSide) return;
  if(e.getSource().getDirectEntity() instanceof SpellOrbEntity orb && orb.getOwner() instanceof Player owner){
   float charge=Math.max(0,Math.min(100,orb.chargedTick()))/100.0F;
   float multiplier=Math.min(4.0F,1.0F+(1.0F+(float)TalentAttributes.compression(owner))*charge);
   e.setAmount(e.getAmount()*multiplier);
  }
 }
 private TalentEvents(){}
}
