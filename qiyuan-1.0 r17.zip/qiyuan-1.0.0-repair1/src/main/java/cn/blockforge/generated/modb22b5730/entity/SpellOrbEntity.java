package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.Ballistics;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;
import java.util.List;

/** 原有法术飞弹；服务端结算命中，客户端与服务端同用先移动再重力的运动公式。 */
public class SpellOrbEntity extends Projectile {
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> CHARGE = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> MIXED = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.BOOLEAN);
    private int age;
    public SpellOrbEntity(EntityType<? extends SpellOrbEntity> type, Level level) { super(type, level); }

    /** 保留旧调用兼容入口。 */
    public static void launch(Level level, LivingEntity shooter, List<String> runes, Vec3 dir, int color) {
        launchTowards(level, shooter, runes, shooter.getEyePosition().add(dir.normalize().scale(32)), color, 0, 1);
    }
    public static Vec3 launchOrigin(LivingEntity shooter) {
        Vec3 eye = shooter.getEyePosition();
        Vec3 base = shooter.position().add(0, 2.0, 0);
        BlockHitResult ceiling = shooter.level().clip(new ClipContext(eye, base, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
        return ceiling.getType() == HitResult.Type.BLOCK ? new Vec3(base.x, ceiling.getLocation().y - 0.25, base.z) : base;
    }
    public static SpellOrbEntity launchTowards(Level level, LivingEntity shooter, List<String> runes, Vec3 target, int color, int index, int count) {
        if (level.isClientSide) return null;
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), level);
        orb.setOwner(shooter);
        Vec3 origin = launchOrigin(shooter);
        if (count > 1) {
            double phase = Math.PI * 2 * index / count;
            Vec3 ring = origin.add(0.5 * Math.cos(phase), 0, 0.5 * Math.sin(phase));
            BlockHitResult obstruction = level.clip(new ClipContext(origin, ring, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
            origin = obstruction.getType() == HitResult.Type.BLOCK
                ? obstruction.getLocation().add(Vec3.atLowerCornerOf(obstruction.getDirection().getNormal()).scale(0.05)) : ring;
        }
        orb.setPos(origin);
        orb.entityData.set(RUNES, String.join("·", runes));
        orb.entityData.set(COLOR, color);
        if (shooter instanceof Player p) orb.entityData.set(CHARGE, PrayerData.chargeTicks(p));
        Vec3 delta = target.subtract(origin);
        Ballistics.Shot shot = Ballistics.solve(delta.x, delta.y, delta.z);
        orb.setNoGravity(!shot.gravity());
        double speed = Math.sqrt(shot.x()*shot.x() + shot.y()*shot.y() + shot.z()*shot.z());
        orb.shoot(shot.x(), shot.y(), shot.z(), (float)speed, 0);
        return level.addFreshEntity(orb) ? orb : null;
    }
    /** 偏移只在发射瞬间注入一次；熟练度与天赋缩小sigma，飞行中绝不再抖动。 */
    @Override public void shoot(double x, double y, double z, float speed, float unusedInaccuracy) {
        Vec3 dir = new Vec3(x,y,z).normalize();
        if (!level().isClientSide && getOwner() instanceof Player p) {
            double sigma = Ballistics.sigma(PrayerData.instability(p), PrayerData.proficiency(p),
                cn.blockforge.generated.modb22b5730.talent.TalentAttributes.instabilityReduction(p));
            dir = dir.add(random.nextGaussian()*sigma, random.nextGaussian()*sigma, random.nextGaussian()*sigma).normalize();
        }
        super.shoot(dir.x, dir.y, dir.z, speed, 0);
    }
    @Override protected void defineSynchedData() {
        entityData.define(RUNES, ""); entityData.define(COLOR, 0x3D9CB8);
        entityData.define(CHARGE, 0); entityData.define(MIXED, false);
    }
    public String runeString() { return entityData.get(RUNES); }
    public int color() { return entityData.get(COLOR); }
    public int chargedTick() { return entityData.get(CHARGE); }
    public boolean isMixed() { return entityData.get(MIXED); }
    public void setMixed(boolean value) { entityData.set(MIXED, value); }
    public void setSpell(String runes, int color, int charge) {
        entityData.set(RUNES, runes); entityData.set(COLOR, color); entityData.set(CHARGE, Math.max(0, Math.min(100, charge)));
    }
    @Override public boolean canCollideWith(Entity other) { return !(other instanceof SpellOrbEntity) && super.canCollideWith(other); }
    @Override protected boolean canHitEntity(Entity other) { return !(other instanceof SpellOrbEntity) && super.canHitEntity(other); }
    @Override public void tick() {
        super.tick();
        if (++age > 200) { if (!level().isClientSide) discard(); return; }
        Vec3 start = position(), move = getDeltaMovement(), end = start.add(move);
        if (!level().isClientSide) {
            EntityHitResult entity = ProjectileUtil.getEntityHitResult(level(), this, start, end,
                getBoundingBox().expandTowards(move).inflate(0.6), this::canHitEntity);
            BlockHitResult block = level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (entity != null && (block.getType() == HitResult.Type.MISS || start.distanceToSqr(entity.getLocation()) < start.distanceToSqr(block.getLocation()))) onHitEntity(entity);
            else if (block.getType() != HitResult.Type.MISS) onHitBlock(block);
            if (isRemoved()) return; // 已命中不能再推进到障碍后方，也不能重复命中。
        }
        setPos(end);
        if (!isNoGravity()) setDeltaMovement(move.add(0, -Ballistics.GRAVITY, 0));
        if (level().isClientSide) {
            double vx=(random.nextDouble()-.5)*.05, vy=(random.nextDouble()-.5)*.05, vz=(random.nextDouble()-.5)*.05;
            level().addParticle(SpellCaster.dust(color(), .9f), getX(),getY(),getZ(),vx,vy,vz);
            String runes=runeString();
            if(runes.contains("火")) level().addParticle(net.minecraft.core.particles.ParticleTypes.FLAME,getX(),getY(),getZ(),vx,vy,vz);
            if(runes.contains("冰")) level().addParticle(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE,getX(),getY(),getZ(),vx,vy,vz);
            if(runes.contains("水")) level().addParticle(net.minecraft.core.particles.ParticleTypes.BUBBLE,getX(),getY(),getZ(),vx,vy,vz);
            if(runes.contains("雷")) level().addParticle(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,getX(),getY(),getZ(),vx,vy,vz);
            if(runes.contains("风")) level().addParticle(net.minecraft.core.particles.ParticleTypes.CLOUD,getX(),getY(),getZ(),vx,vy,vz);
        }
    }
    @Override protected void onHitEntity(EntityHitResult result) {
        if (level().isClientSide) return;
        Vec3 travel=getDeltaMovement();
        Vec3 normal=travel.lengthSqr()>1e-8?travel.scale(-1).normalize():new Vec3(0,1,0);
        SpellCaster.spawnProjectileImpactCircle(level(),getOwner(),runeString(),result.getLocation(),normal);
        SpellCaster.applyProjectileImpact(level(),this,result.getLocation(),result.getEntity());
        discard();
    }
    @Override protected void onHitBlock(BlockHitResult result) {
        if (level().isClientSide) return;
        Vec3 normal=Vec3.atLowerCornerOf(result.getDirection().getNormal());
        SpellCaster.spawnProjectileImpactCircle(level(),getOwner(),runeString(),result.getLocation().add(normal.scale(.05)),normal);
        SpellCaster.applyProjectileImpact(level(),this,result.getLocation(),null);
        discard();
    }
    @Override public net.minecraft.network.protocol.Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getAddEntityPacket() {
        return net.minecraftforge.network.NetworkHooks.getEntitySpawningPacket(this);
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("prayer_runes",runeString()); tag.putInt("prayer_color",color());
        tag.putInt("prayer_age",age); tag.putInt("prayer_charge",chargedTick()); tag.putBoolean("prayer_mixed",isMixed());
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setSpell(tag.getString("prayer_runes"),tag.getInt("prayer_color"),tag.getInt("prayer_charge"));
        age=Math.max(0,tag.getInt("prayer_age")); setMixed(tag.getBoolean("prayer_mixed"));
    }
}
