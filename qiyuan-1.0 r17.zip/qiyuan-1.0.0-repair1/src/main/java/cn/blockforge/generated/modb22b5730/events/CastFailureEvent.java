package cn.blockforge.generated.modb22b5730.events;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.eventbus.api.Event;

public final class CastFailureEvent extends Event {
    public enum Cause { MANA_DEPLETED, LOCKED, INVALID_SPELL, COOLDOWN }
    private final Player player;
    private final Cause cause;
    public CastFailureEvent(Player player, Cause cause) { this.player = player; this.cause = cause; }
    public Player player() { return player; }
    public Cause cause() { return cause; }
}
