package cn.blockforge.generated.modb22b5730.talent;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.server.level.ServerPlayer;

/** 兼容层的乱魔命中入口；具体术式/符文映射需由数据包或调用方显式指定。 */
public final class DisturbMagic {
    public static void interrupt(ServerPlayer target) {
        if (target == null || !target.isAlive()) return;
        PrayerData.clearCharge(target);
        long until = target.level().getGameTime() + 20;
        PrayerData.of(target).putLong("interrupt_until", until);
        PrayerData.of(target).putFloat("instability", Math.min(5.0F, PrayerData.instability(target) + 1.0F));
        TalentNet.sendInterrupt(target, until);
        PrayerNet.sync(target);
    }
    private DisturbMagic() {}
}
