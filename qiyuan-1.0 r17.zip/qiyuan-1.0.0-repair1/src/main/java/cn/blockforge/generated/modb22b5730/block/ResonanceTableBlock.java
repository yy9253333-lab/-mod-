package cn.blockforge.generated.modb22b5730.block;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.spell.ResonanceRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;

/**
 * 共鸣台：把两个符文分别放在主手和副手，右键台子做实验。
 * 命中配方 → 消耗两个符文 + 30 魔力，把结果术式写入玩家第一个空预设槽。
 * 没命中 → 粒子灰烟，符文保留。
 */
public final class ResonanceTableBlock extends Block {
    private static final int COST_MANA = 30;

    public ResonanceTableBlock() {
        super(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_BLUE)
            .strength(1.2f, 4.0f)
            .sound(SoundType.STONE)
            .lightLevel(s -> 6)
            .requiresCorrectToolForDrops());
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();

        if (!(main.getItem() instanceof RuneItem ra) || !(off.getItem() instanceof RuneItem rb)) {
            player.displayClientMessage(Component.literal("共鸣台：主手放一个符文，副手放另一个符文，然后点这里。"), true);
            return InteractionResult.CONSUME;
        }
        String a = ra.def().rune;
        String b = rb.def().rune;
        if (a.equals(b)) {
            player.displayClientMessage(Component.literal("两枚符文完全相同，没有共鸣反应。"), true);
            return InteractionResult.CONSUME;
        }

        ResonanceRecipes.Recipe recipe = ResonanceRecipes.lookup(a, b);
        if (recipe == null) {
            level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.5f, 0.6f);
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.SMOKE,
                    pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 8, 0.3, 0.4, 0.3, 0.02);
            }
            player.displayClientMessage(Component.literal(a + " 与 " + b + " 没有共鸣……也许换个组合？"), true);
            return InteractionResult.CONSUME;
        }

        // 命中：扣魔力
        if (!PrayerData.spendMana(player, COST_MANA)) {
            player.displayClientMessage(Component.literal("魔力不足（需要 " + COST_MANA + "）。"), true);
            return InteractionResult.CONSUME;
        }
        // 消耗两个符文
        main.shrink(1);
        off.shrink(1);

        // 写入第一个空预设槽
        int slot = -1;
        var presets = PrayerData.presets(player);
        for (int i = 0; i < presets.size(); i++) {
            if (presets.get(i)[1].isEmpty()) { slot = i; break; }
        }
        if (slot < 0) {
            // 满了就覆盖第一个
            slot = 0;
        }
        PrayerData.savePreset(player, slot, recipe.displayName(), recipe.runeString());

        level.playSound(null, pos, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0f, 1.2f);
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.ENCHANT,
                pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 40, 0.5, 0.6, 0.5, 0.3);
        }
        player.displayClientMessage(Component.literal("共鸣成功！领悟术式「" + recipe.displayName() + "」：" + recipe.runeString()), false);
        cn.blockforge.generated.modb22b5730.net.PrayerNet.sync(player);
        return InteractionResult.CONSUME;
    }
}
