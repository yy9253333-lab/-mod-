package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.PrayerConfig;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.talent.TalentAttributes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 玩家数据生命周期、魔力回复、冥想与同步。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlayerEvents {
    public static final String[] STARTER_RUNES = {"己", "视", "火", "灭", "弹"};

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        PrayerData.clearCharge(player);
        PrayerData.of(player).putBoolean("meditating", false);
        giveStarterKit(player);
        if (!player.level().isClientSide) PrayerData.of(player);
        PrayerNet.sync(player);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        // PersistentData is not copied by Forge's replacement player; retain the complete
        // prayer compound, including legacy fields, on death and non-death replacement.
        event.getEntity().getPersistentData().put(
            PrayerData.TAG,
            event.getOriginal().getPersistentData().getCompound(PrayerData.TAG).copy());
        if (event.getOriginal().getPersistentData().getBoolean("prayer_granted"))
            event.getEntity().getPersistentData().putBoolean("prayer_granted", true);
        PrayerData.clearCharge(event.getEntity());
        PrayerData.of(event.getEntity()).putBoolean("meditating", false);
        PrayerNet.sync(event.getEntity());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        PrayerData.clearCharge(event.getEntity());
        PrayerNet.sync(event.getEntity());
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        PrayerNet.sync(event.getEntity());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        PrayerData.clearCharge(event.getEntity());
        cn.blockforge.generated.modb22b5730.spell.AimStore.clear(event.getEntity().getUUID());
    }

    public static void giveStarterKit(Player player) {
        if (player.getPersistentData().getBoolean("prayer_granted")) return;
        player.getInventory().add(new ItemStack(GeneratedMod.PRAYER_BOOK.get()));
        for (String rune : STARTER_RUNES) player.getInventory().add(RuneItem.stack(rune));
        player.getPersistentData().putBoolean("prayer_granted", true);
        if (!player.level().isClientSide)
            player.displayClientMessage(Component.literal("《祈愿》苏醒了：物品栏里多了一本魔导书和 5 枚基础符文，右键打开看看吧。"), false);
    }

    @SubscribeEvent
    public static void onSummonedMobTick(LivingEvent.LivingTickEvent event) {
        if (!event.getEntity().level().isClientSide)
            cn.blockforge.generated.modb22b5730.spell.SummonService.tickTemporarySummon(event.getEntity());
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) return;
        PrayerData.of(player).putBoolean("meditate_interrupted", true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player player = event.player;
        var data = PrayerData.of(player);
        boolean depleted = PrayerData.manaPool(player) <= 0.0F;
        boolean wasDepleted = data.getBoolean("was_depleted");
        if (depleted && !wasDepleted) cn.blockforge.generated.modb22b5730.spell.SpellCaster.handleDepletion(player);
        else if (!depleted) data.putBoolean("was_depleted", false);

        if (!PrayerData.charging(player) && PrayerData.manaPool(player) < PrayerData.capacity(player)) {
            float regen = PrayerConfig.MANA_REGEN.get().floatValue() + (float)TalentAttributes.manaRegen(player);
            PrayerData.addManaPool(player, Math.max(0.0F, regen));
        }
        PrayerData.tickCharging(player);
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer)
            cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity.tickChargingPreview(serverPlayer);
        PrayerData.tickNewbie(player);
        PrayerData.decayInstability(player);

        if (data.getInt("meditate_cooldown") > 0)
            data.putInt("meditate_cooldown", data.getInt("meditate_cooldown") - 1);
        if (data.getBoolean("meditating")) {
            boolean invalid = !player.isShiftKeyDown() || !player.getMainHandItem().isEmpty()
                || !player.getOffhandItem().isEmpty()
                || player.getDeltaMovement().horizontalDistanceSqr() > 0.0001D
                || data.getBoolean("meditate_interrupted");
            if (invalid) {
                data.putBoolean("meditating", false);
                data.putInt("meditate_ticks", 0);
            } else {
                int ticks = data.getInt("meditate_ticks") + 1;
                data.putInt("meditate_ticks", ticks);
                if (ticks >= PrayerConfig.MEDITATION_TICKS.get()) {
                    PrayerData.setCapacity(player, PrayerData.capacity(player) + 2);
                    data.putInt("meditate_cooldown", PrayerConfig.MEDITATION_COOLDOWN.get());
                    data.putInt("meditate_ticks", 0);
                    data.putBoolean("meditating", false);
                }
            }
        }

        if (player.tickCount % 10 == 0) {
            boolean changed = PrayerData.scanInventory(player);
            PrayerNet.sync(player); // charge and mana are observable state; sync at 10 ticks.

        }
    }

    private PlayerEvents() {}
}
