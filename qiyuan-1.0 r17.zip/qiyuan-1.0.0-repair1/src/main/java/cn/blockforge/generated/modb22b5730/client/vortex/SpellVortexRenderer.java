package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.entity.SpellVortexEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;
import software.bernie.geckolib.cache.object.BakedGeoModel;

/** 唯一注册到该EntityType的GeoEntityRenderer；球壳作为GeoRenderLayer绘制。 */
public class SpellVortexRenderer extends GeoEntityRenderer<SpellVortexEntity> {
    public static final ResourceLocation TEX = GeneratedMod.rl("textures/entity/vortex_fluid.png");
    public SpellVortexRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new SpellVortexModel());
        addRenderLayer(new ShellLayer(this));
    }
    @Override public void renderRecursively(PoseStack pose, SpellVortexEntity entity,
        software.bernie.geckolib.cache.object.GeoBone bone, RenderType type, MultiBufferSource buffers,
        VertexConsumer consumer, boolean rerender, float partial, int light, int overlay,
        float red, float green, float blue, float alpha) {
        boolean tip = bone.getName().startsWith("ribbon_") && bone.getName().endsWith("_tip");
        if (tip) bone.setTrackingMatrices(true);
        super.renderRecursively(pose, entity, bone, type, buffers, consumer, rerender, partial, light, overlay, red, green, blue, alpha);
        if (tip && !rerender) {
            int index = bone.getName().charAt(7) - '1';
            var point = bone.getWorldPosition();
            VortexClientEffects.captureTip(entity, index, new net.minecraft.world.phys.Vec3(point.x, point.y, point.z));
        }
    }
    /** 主渲染目标拷贝/真实折射未实现；shader存在但安全实现使用entityTranslucentEmissive。 */
    private static final class ShellLayer extends GeoRenderLayer<SpellVortexEntity> {
        ShellLayer(SpellVortexRenderer renderer) { super(renderer); }
        @Override public void render(PoseStack pose, SpellVortexEntity e, BakedGeoModel model,
            RenderType type, MultiBufferSource buffers, VertexConsumer vc, float partial,
            int light, int overlay) {
            if (!VortexRenderBudget.claim()) return;
            VertexConsumer out = buffers.getBuffer(RenderType.entityTranslucentEmissive(TEX));
            float t = e.tickCount + partial;
            float[][] shells = {{.30f,.85f,4f},{.42f,.50f,6f},{.55f,.25f,9f}};
            for (float[] s : shells) {
                pose.pushPose();
                try {
                    pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(t*s[2]));
                    sphere(pose, out, s[0], s[1], light, t);
                } finally { pose.popPose(); }
            }
            VortexClientEffects.renderTrail(pose, out, e, light);
        }
        private static void sphere(PoseStack ps, VertexConsumer out, float r, float a, int light, float time) {
            PoseStack.Pose p = ps.last();
            for (int y=0;y<8;y++) { float v0=(float)y/8, v1=(float)(y+1)/8;
                float p0=(v0-.5f)*Mth.PI, p1=(v1-.5f)*Mth.PI;
                for (int x=0;x<16;x++) { float u0=(float)x/16,u1=(float)(x+1)/16;
                    vertex(out,p,r,p0,u0,v0,a,light,time); vertex(out,p,r,p0,u1,v0,a,light,time);
                    vertex(out,p,r,p1,u1,v1,a,light,time); vertex(out,p,r,p1,u0,v1,a,light,time);
                }
            }
        }
        private static void vertex(VertexConsumer out, PoseStack.Pose p,float r,float phi,float u,float v,float a,int light,float time){
            float th=u*Mth.TWO_PI, x=r*Mth.cos(phi)*Mth.cos(th), y=r*Mth.sin(phi), z=r*Mth.cos(phi)*Mth.sin(th);
            Matrix3f n=p.normal(); out.vertex(p.pose(),x,y,z).color(80,210,255,(int)(255*a)).uv(u + time * .02f, v + time * .05f)
                .overlayCoords(net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(n, x,y,z).endVertex();
        }
    }
}
