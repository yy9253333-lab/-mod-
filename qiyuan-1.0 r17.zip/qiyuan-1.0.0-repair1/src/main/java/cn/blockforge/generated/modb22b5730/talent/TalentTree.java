package cn.blockforge.generated.modb22b5730.talent;

import com.google.gson.*;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.mojang.logging.LogUtils;

@Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID)
public final class TalentTree {
    public record ModDef(String attr,double amount,AttributeModifier.Operation op) {}
    public record ClientNode(String id,int cost,List<String> prerequisites,List<ModDef> modifiers) {}
    public static final class Node {
        public final String id; public final int cost; public final List<String> prerequisites; public final List<ModDef> modifiers;
        Node(String i,int c,List<String> p,List<ModDef> m){id=i;cost=c;prerequisites=List.copyOf(p);modifiers=List.copyOf(m);}
        public String id(){return id;} public int cost(){return cost;} public List<String> prerequisites(){return prerequisites;} public List<ModDef> modifiers(){return modifiers;}
        ClientNode client(){return new ClientNode(id,cost,prerequisites,modifiers);}
    }
    private static final int MAX_NODES=512;
    private static final Map<String,Node> NODES=new LinkedHashMap<>();
    public static Map<String,Node> all(){return Collections.unmodifiableMap(NODES);}
    @SubscribeEvent public static void reload(AddReloadListenerEvent e){e.addListener(new SimpleJsonResourceReloadListener(GsonHolder.GSON,"talents") {
        @Override protected void apply(Map<ResourceLocation,JsonElement> files,ResourceManager rm,ProfilerFiller pf){
            Map<String,Node> next=new LinkedHashMap<>();
            for(var en:files.entrySet()) try { JsonElement root=en.getValue(); if(root.isJsonArray()) for(JsonElement x:root.getAsJsonArray()) add(next,x); else add(next,root); } catch(Exception ex){LogUtils.getLogger().warn("Ignoring invalid talent JSON {}: {}",en.getKey(),ex.toString());}
            validatePrerequisites(next);
            synchronized(NODES){NODES.clear();NODES.putAll(next);}
            MinecraftServer server=ServerLifecycleHooks.getCurrentServer();
            if(server!=null) server.execute(()->server.getPlayerList().getPlayers().forEach(p->{TalentTree.apply(p);TalentNet.send(p);}));
            if(NODES.isEmpty()) LogUtils.getLogger().warn("No talent nodes loaded; define data/{}/talents/*.json",GeneratedMod.MOD_ID);
        }
    });}
    private static void add(Map<String,Node> out,JsonElement el){
        if(!el.isJsonObject()) throw new IllegalArgumentException("not object"); JsonObject o=el.getAsJsonObject();
        String id=req(o,"id").getAsString(); if(!id.matches("[a-z0-9_:.\\-]{1,128}")||out.containsKey(id)||out.size()>=MAX_NODES) throw new IllegalArgumentException("bad/duplicate/too many id");
        int cost=req(o,"cost").getAsInt(); if(cost<0) throw new IllegalArgumentException("negative cost");
        List<String> pre=new ArrayList<>(); if(o.has("prerequisites")){if(!o.get("prerequisites").isJsonArray())throw new IllegalArgumentException("bad prerequisites"); for(var x:o.getAsJsonArray("prerequisites")){String s=x.getAsString();if(!s.matches("[a-z0-9_:.\\-]{1,128}")||pre.contains(s))throw new IllegalArgumentException("bad prerequisite");pre.add(s);}}
        Set<String> usedAttributes=new HashSet<>(); List<ModDef> mods=new ArrayList<>(); if(o.has("modifiers")){if(!o.get("modifiers").isJsonArray())throw new IllegalArgumentException("bad modifiers"); for(var x:o.getAsJsonArray("modifiers")){JsonObject m=x.getAsJsonObject();String a=req(m,"attribute").getAsString();if(!usedAttributes.add(a))throw new IllegalArgumentException("duplicate attribute in node");if(!Set.of("mana_regen","spell_compression","max_duplicate_bonus","instability_reduction").contains(a))throw new IllegalArgumentException("unknown attribute");double v=req(m,"amount").getAsDouble();if(!Double.isFinite(v))throw new IllegalArgumentException("nonfinite amount");String op=m.has("operation")?m.get("operation").getAsString().toLowerCase(Locale.ROOT):"addition";AttributeModifier.Operation operation=switch(op){case "addition"->AttributeModifier.Operation.ADDITION;case "multiply_base"->AttributeModifier.Operation.MULTIPLY_BASE;case "multiply_total"->AttributeModifier.Operation.MULTIPLY_TOTAL;default->throw new IllegalArgumentException("unknown operation");};mods.add(new ModDef(a,v,operation));}}
        out.put(id,new Node(id,cost,pre,mods));
    }
    private static JsonElement req(JsonObject o,String k){if(!o.has(k)||o.get(k).isJsonNull())throw new IllegalArgumentException("missing "+k);return o.get(k);}
    private static void validatePrerequisites(Map<String,Node> nodes) {
        boolean removed;
        do {
            removed = false;
            var iterator = nodes.values().iterator();
            while (iterator.hasNext()) {
                Node node = iterator.next();
                if (node.prerequisites.stream().anyMatch(id -> !nodes.containsKey(id)) || reaches(node.id, node.id, nodes, new HashSet<>())) {
                    LogUtils.getLogger().warn("Ignoring talent node {} with missing/cyclic prerequisite", node.id);
                    iterator.remove(); removed = true;
                }
            }
        } while (removed);
    }
    private static boolean reaches(String origin, String current, Map<String,Node> nodes, Set<String> visited) {
        if (!visited.add(current)) return false;
        Node node = nodes.get(current); if (node == null) return false;
        for (String prerequisite : node.prerequisites)
            if (prerequisite.equals(origin) || reaches(origin, prerequisite, nodes, visited)) return true;
        return false;
    }
    public static boolean unlock(Player p,String id){Node n=NODES.get(id);if(n==null)return false;TalentData d=TalentData.of(p);if(d.has(id)||n.prerequisites.stream().anyMatch(x->!d.has(x))||PrayerData.talentPoints(p)<n.cost)return false;PrayerData.addTalentPoints(p,-n.cost);d.unlock(id);apply(p);return true;}
    public static void apply(Player p){
        TalentData d=TalentData.of(p); for(var ro:List.of(TalentAttributes.MANA_REGEN,TalentAttributes.SPELL_COMPRESSION,TalentAttributes.MAX_DUPLICATE_BONUS,TalentAttributes.INSTABILITY_REDUCTION)){var inst=p.getAttribute(ro.get());if(inst!=null)inst.getModifiers().stream().filter(x->x.getName().startsWith("talent:")).toList().forEach(inst::removeModifier);}
        for(String id:d.unlocked()){Node n=NODES.get(id);if(n==null)continue;for(ModDef mod:n.modifiers){var ro=switch(mod.attr){case "mana_regen"->TalentAttributes.MANA_REGEN;case "spell_compression"->TalentAttributes.SPELL_COMPRESSION;case "max_duplicate_bonus"->TalentAttributes.MAX_DUPLICATE_BONUS;default->TalentAttributes.INSTABILITY_REDUCTION;};var attr=p.getAttribute(ro.get());if(attr==null)continue;var uuid=UUID.nameUUIDFromBytes(("talent:"+id+":"+mod.attr).getBytes(StandardCharsets.UTF_8));attr.removeModifier(uuid);attr.addPermanentModifier(new AttributeModifier(uuid,"talent:"+id+":"+mod.attr,mod.amount,mod.op));}}
    }
    private static final class GsonHolder{static final Gson GSON=new GsonBuilder().create();}
    private TalentTree(){}
}
