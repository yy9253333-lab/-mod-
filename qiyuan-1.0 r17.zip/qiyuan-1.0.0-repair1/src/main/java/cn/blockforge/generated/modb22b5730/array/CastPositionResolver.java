package cn.blockforge.generated.modb22b5730.array;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/** 目标符文定位规则及互斥校验。 */
public final class CastPositionResolver {
    public static final String RUNE_SELF = "己";
    public static final String RUNE_VIEW = "指";
    public static final String RUNE_VISION = "视";

    private CastPositionResolver() {}

    /** 返回互斥错误；null 表示合法。普通瞄准是默认行为，不需要额外符文。 */
    public static String validate(Collection<String> runes) {
        if (runes == null || runes.isEmpty()) return null;
        Set<String> selected = new LinkedHashSet<>();
        if (runes.contains(RUNE_SELF)) selected.add(RUNE_SELF);
        if (runes.contains(RUNE_VIEW)) selected.add(RUNE_VIEW);
        if (runes.contains("视")) selected.add("视");
        if (selected.size() > 1) {
            return "定位符文互斥：" + String.join("、", selected) + " 不能同时组合，请只保留一种定位方式。";
        }
        return null;
    }

    public static CastAnchor resolve(Collection<String> runes) {
        if (runes == null || runes.isEmpty()) return CastAnchor.AIMED;
        if (runes.contains(RUNE_SELF)) return CastAnchor.FEET;
        if (runes.contains(RUNE_VIEW) || runes.contains(RUNE_VISION)) return CastAnchor.VIEW;
        return CastAnchor.AIMED;
    }
}
