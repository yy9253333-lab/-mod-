package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.client.vortex.VortexClientEffects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** 施法视觉漩涡；只负责生命周期与快照，注册和渲染由父工程接线。 */
public class SpellVortexEntity extends Projectile implements GeoEntity {
    public static final int DEFAULT_LIFETIME = 60;
    private static final EntityDataAccessor<Integer> DATA_MANA_SNAPSHOT =
        SynchedEntityData.defineId(SpellVortexEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_LIFETIME =
        SynchedEntityData.defineId(SpellVortexEntity.class, EntityDataSerializers.INT);
    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);

    public SpellVortexEntity(EntityType<? extends SpellVortexEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
        setNoGravity(true);
    }

    /** 父代理的SpellCaster可用本接口在扣费后生成；type应为已注册的EntityType。 */
    public static SpellVortexEntity spawn(Level level, EntityType<SpellVortexEntity> type,
                                          LivingEntity caster, Vec3 position, int manaCapacity) {
        SpellVortexEntity vortex = new SpellVortexEntity(type, level);
        vortex.setOwner(caster);
        vortex.setPos(position);
        vortex.setManaSnapshot(manaCapacity);
        vortex.setLifetime(DEFAULT_LIFETIME);
        level.addFreshEntity(vortex);
        return vortex;
    }

    @Override protected void defineSynchedData() {
        entityData.define(DATA_MANA_SNAPSHOT, 200);
        entityData.define(DATA_LIFETIME, DEFAULT_LIFETIME);
    }

    public int manaSnapshot() { return entityData.get(DATA_MANA_SNAPSHOT); }
    public void setManaSnapshot(int value) { entityData.set(DATA_MANA_SNAPSHOT, Math.max(0, Math.min(2000, value))); }
    public int lifetime() { return entityData.get(DATA_LIFETIME); }
    public void setLifetime(int ticks) { entityData.set(DATA_LIFETIME, Math.max(1, ticks)); }
    public float particleRadius() { return 0.6f + 1.0f * Math.min(1f, manaSnapshot() / 2000f); }
    public float particleAngularSpeed() { return 4f + 14f * Math.min(1f, manaSnapshot() / 2000f); }
    public int particleCount() { return Math.min(6, 1 + (int)(5f * Math.min(1f, manaSnapshot() / 2000f))); }

    @Override public void registerControllers(ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "spin", 0,
            state -> state.setAndContinue(RawAnimation.begin().thenLoop("animation.spell_vortex.spin"))));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }

    @Override public void tick() {
        super.tick();
        noPhysics = true;
        setNoGravity(true);
        if (!level().isClientSide && tickCount >= lifetime()) { discard(); return; }
        if (level().isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> VortexClientEffects.tick(this));
        }
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ManaSnapshot", manaSnapshot());
        tag.putInt("LifetimeRemaining", Math.max(0, lifetime() - tickCount));
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setManaSnapshot(tag.getInt("ManaSnapshot"));
        int remaining = tag.contains("LifetimeRemaining") ? tag.getInt("LifetimeRemaining")
            : tag.contains("Lifetime") ? tag.getInt("Lifetime") : DEFAULT_LIFETIME;
        setLifetime(Math.max(1, remaining));
    }

    @Override public net.minecraft.world.phys.AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(2.15D);
    }
}
