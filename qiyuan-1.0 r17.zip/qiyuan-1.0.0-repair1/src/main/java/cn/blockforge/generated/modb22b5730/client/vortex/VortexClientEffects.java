package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.entity.SpellVortexEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import java.util.Map;
import java.util.WeakHashMap;

/** 客户端粒子与真实骨骼末端的8帧世界坐标拖尾；弱引用缓存不保留已卸载实体。 */
public final class VortexClientEffects {
    private static final int TRAIL_LENGTH = 8;
    private static final int STREAMS = 3;
    private static final Map<SpellVortexEntity, Vec3[][]> TRAILS = new WeakHashMap<>();
    private static final Map<SpellVortexEntity, Vec3[]> TIPS = new WeakHashMap<>();
    public static void captureTip(SpellVortexEntity entity, int stream, Vec3 point) {
        if (stream < 0 || stream >= STREAMS || !Double.isFinite(point.x) || !Double.isFinite(point.y) || !Double.isFinite(point.z)) return;
        TIPS.computeIfAbsent(entity, e -> new Vec3[STREAMS])[stream] = point;
    }
    private VortexClientEffects() {}
    public static void tick(SpellVortexEntity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != e.level() || mc.player == null || mc.options.particles().get().getId() == 2) return; // MINIMAL
        if (mc.player.distanceToSqr(e) > 48 * 48) return;
        int n = Math.min(120, e.particleCount());
        if (mc.options.particles().get().getId() == 1) n = (n + 1) / 2; // DECREASED
        Level level = e.level();
        Vec3[][] old = TRAILS.get(e), trail = new Vec3[STREAMS][TRAIL_LENGTH];
        double base = e.tickCount * Math.toRadians(e.particleAngularSpeed());
        for (int stream = 0; stream < STREAMS; stream++) {
            Vec3[] recorded = TIPS.get(e);
            Vec3 tip = recorded != null && recorded[stream] != null ? recorded[stream] : e.position();
            trail[stream][0] = tip;
            if (old != null && old[stream] != null)
                System.arraycopy(old[stream], 0, trail[stream], 1, TRAIL_LENGTH - 1);
            for (int i = 1; i < TRAIL_LENGTH; i++)
                if (trail[stream][i] == null) trail[stream][i] = tip;
        }
        TRAILS.put(e, trail);
        double m = e.tickCount * Math.toRadians(e.particleAngularSpeed());
        for (int i = 0; i < n; i++) {
            double a = m + level.random.nextDouble() * Math.PI * 2;
            double r = e.particleRadius();
            double x = e.getX() + Math.cos(a) * r;
            double y = e.getY() + level.random.nextDouble() - .5;
            double z = e.getZ() + Math.sin(a) * r;
            double w = Math.toRadians(e.particleAngularSpeed());
            double vx = w * r * -Math.sin(a), vz = w * r * Math.cos(a);
            level.addParticle((e.tickCount + i) % 2 == 0 ? cn.blockforge.generated.modb22b5730.entity.VortexParticles.GLOW.get() : cn.blockforge.generated.modb22b5730.entity.VortexParticles.SPLASH.get(),
                x, y, z, vx, .01, vz);
        }
    }

    /** Renderer可取用的8帧环形轨迹；alpha由index线性衰减到0。 */
    public static Vec3[][] trail(SpellVortexEntity e) { return TRAILS.get(e); }

    public static void renderTrail(PoseStack ps, VertexConsumer out, SpellVortexEntity e, int light) {
        Vec3[][] streams = TRAILS.get(e); if (streams == null) return;
        PoseStack.Pose p = ps.last();
        for (Vec3[] a : streams) for (int i = 0; a != null && i < a.length - 1; i++) {
            if (a[i] == null || a[i + 1] == null) continue;
            Vec3 q = a[i].subtract(e.position()), n = a[i + 1].subtract(e.position());
            int alpha = (int)(255f * (1f - i / (float) (TRAIL_LENGTH - 1)));
            int nextAlpha = (int)(255f * (1f - (i + 1) / (float)(TRAIL_LENGTH - 1)));
            out.vertex(p.pose(), (float)q.x-.025f,(float)q.y,(float)q.z).color(60,200,255,alpha).uv(0,i/(float)TRAIL_LENGTH).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(),0,1,0).endVertex();
            out.vertex(p.pose(), (float)q.x+.025f,(float)q.y,(float)q.z).color(60,200,255,alpha).uv(1,i/(float)TRAIL_LENGTH).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(),0,1,0).endVertex();
            out.vertex(p.pose(), (float)n.x+.025f,(float)n.y,(float)n.z).color(60,200,255,nextAlpha).uv(1,(i+1)/(float)TRAIL_LENGTH).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(),0,1,0).endVertex();
            out.vertex(p.pose(), (float)n.x-.025f,(float)n.y,(float)n.z).color(60,200,255,nextAlpha).uv(0,(i+1)/(float)TRAIL_LENGTH).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(p.normal(),0,1,0).endVertex();
        }
    }

    private static Vec3 endpoint(SpellVortexEntity e, double angle) {
        double r = e.particleRadius();
        return e.position().add(Math.cos(angle) * r, 0.12 + Math.sin(angle * 1.7) * 0.18,
            Math.sin(angle) * r);
    }
}
