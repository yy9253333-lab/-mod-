package cn.blockforge.generated.modb22b5730.talent;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.*;
import net.minecraft.world.entity.EntityType;

@Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class TalentAttributes {
 public static final DeferredRegister<Attribute> ATTRIBUTES=DeferredRegister.create(ForgeRegistries.ATTRIBUTES,GeneratedMod.MOD_ID);
 public static final RegistryObject<Attribute> MANA_REGEN=ATTRIBUTES.register("mana_regen",()->new RangedAttribute("attribute.name.mana_regen",0,0,1).setSyncable(true));
 public static final RegistryObject<Attribute> SPELL_COMPRESSION=ATTRIBUTES.register("spell_compression",()->new RangedAttribute("attribute.name.spell_compression",0,0,3).setSyncable(true));
 public static final RegistryObject<Attribute> MAX_DUPLICATE_BONUS=ATTRIBUTES.register("max_duplicate_bonus",()->new RangedAttribute("attribute.name.max_duplicate_bonus",0,0,5).setSyncable(true));
 public static final RegistryObject<Attribute> INSTABILITY_REDUCTION=ATTRIBUTES.register("instability_reduction",()->new RangedAttribute("attribute.name.instability_reduction",0,0,.8).setSyncable(true));
 @SubscribeEvent public static void add(EntityAttributeModificationEvent e){if(e.getTypes().contains(EntityType.PLAYER)){e.add(EntityType.PLAYER,MANA_REGEN.get());e.add(EntityType.PLAYER,SPELL_COMPRESSION.get());e.add(EntityType.PLAYER,MAX_DUPLICATE_BONUS.get());e.add(EntityType.PLAYER,INSTABILITY_REDUCTION.get());}}
 private static double value(Player p,RegistryObject<Attribute> a){var inst=p.getAttribute(a.get());return inst==null?0:inst.getValue();}
 public static float manaRegen(Player p){return (float)value(p,MANA_REGEN);}
 public static double compression(Player p){return value(p,SPELL_COMPRESSION);}
 public static int duplicateBonus(Player p){return Math.max(0,(int)Math.floor(value(p,MAX_DUPLICATE_BONUS)));}
 public static double instabilityReduction(Player p){return Math.max(0,Math.min(.8,value(p,INSTABILITY_REDUCTION)));}
 private TalentAttributes(){}
}
