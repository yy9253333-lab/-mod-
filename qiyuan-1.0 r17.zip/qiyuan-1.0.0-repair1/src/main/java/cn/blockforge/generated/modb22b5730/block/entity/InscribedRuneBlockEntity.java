package cn.blockforge.generated.modb22b5730.block.entity;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/**
 * 铭刻方块：把术式"贴"在地上当触发器。
 * 两种触发方式：
 *   ① 怪物/生物踩到它 （AABB 1.5 格内有非玩家 LivingEntity）
 *   ② 旁边有红石充能
 * 触发后冷却 10 秒，避免连炸。
 */
public class InscribedRuneBlockEntity extends BlockEntity {
    private static final int COOLDOWN_TICKS = 200; // 10 秒
    private static final double TRIGGER_RADIUS = 1.5;

    private String runes = "";
    private UUID ownerUuid;
    private long cooldownUntil;

    public InscribedRuneBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.INSCRIBED_RUNE.get(), pos, state);
    }

    public void engrave(Player owner, String runeString) {
        this.runes = runeString == null ? "" : runeString;
        this.ownerUuid = owner == null ? null : owner.getUUID();
        this.cooldownUntil = 0;
        setChanged();
    }

    public String runes() { return runes; }
    public boolean isEngraved() { return !runes.isEmpty(); }

    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        if (now < cooldownUntil) return;
        if (!isEngraved()) return;

        boolean triggered = false;
        // ① 生物踩
        AABB box = new AABB(worldPosition).inflate(TRIGGER_RADIUS, 0.5, TRIGGER_RADIUS);
        List<LivingEntity> nearby = sl.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != null && e.isAlive() && !(e instanceof Player));
        if (!nearby.isEmpty()) triggered = true;

        // ② 红石充能
        if (!triggered && sl.hasNeighborSignal(worldPosition)) triggered = true;

        if (!triggered) return;

        List<String> parsed = PrayerData.parse(runes);
        if (parsed.isEmpty()) return;

        Vec3 pos = new Vec3(worldPosition.getX() + 0.5, worldPosition.getY() + 0.1, worldPosition.getZ() + 0.5);
        // 触发者优先找最近的玩家当 owner，没有就用世界触发（无扣蓝）
        Player owner = resolveOwner(sl);
        SpellCaster.applyZone(sl, owner, parsed, pos, false);
        cooldownUntil = now + COOLDOWN_TICKS;
    }

    private Player resolveOwner(ServerLevel sl) {
        if (ownerUuid == null) return null;
        return sl.players().stream()
            .filter(p -> p.getUUID().equals(ownerUuid))
            .findFirst().orElse(null);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("prayer_runes", runes);
        tag.putLong("prayer_cd", cooldownUntil);
        if (ownerUuid != null) tag.putUUID("prayer_owner", ownerUuid);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        runes = tag.getString("prayer_runes");
        cooldownUntil = tag.getLong("prayer_cd");
        ownerUuid = tag.hasUUID("prayer_owner") ? tag.getUUID("prayer_owner") : null;
    }
}
