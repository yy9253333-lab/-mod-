package cn.blockforge.generated.modb22b5730.spell;

import cn.blockforge.generated.modb22b5730.rune.RuneDef;
import cn.blockforge.generated.modb22b5730.rune.RuneGroup;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import java.util.*;

/**
 * 术式推演：完整移植《祈愿》魔法生成器网页的计算公式
 * （getTier / getMana / calcDamageBreakdown / calcEffectBreakdown / getTime / 图鉴匹配 / 命名）。
 * 模组自定义规则：「瞬」修饰的耗魔倍率由网页的 1.10 提升为 1.60，用于换取无视冷却的瞬发。
 */
public final class SpellCalculator {
    public static final double FLASH_MANA_MULTIPLIER = 1.6; // 模组自定义：瞬发更明显地消耗蓝条
    private static final Map<String, Double> DAMAGE_TIER_MULTIPLIER = pairs("一阶", 0.55, "二阶", 0.80, "三阶", 1.15, "四阶", 1.55, "五阶", 2.00, "禁忌", 3.50);
    private static final Map<String, Double> MANA_MODIFIERS = pairs("疾", 1.00, "缓", 1.00, "续", 1.30, "瞬", FLASH_MANA_MULTIPLIER, "隐", 1.05, "倍", 3.00, "微", 0.50, "裂", 1.45, "锁", 1.05, "转", 1.00);
    private static final Map<String, Double> DAMAGE_MODIFIERS = pairs("疾", 1.00, "缓", 1.05, "续", 1.12, "瞬", 0.95, "隐", 0.90, "倍", 1.80, "微", 0.50, "裂", 0.78, "锁", 1.05, "转", 1.00);
    private static final Set<String> NON_DAMAGE_EFFECTS = Set.of("愈", "解", "真", "传", "幻", "缚", "封");
    private static final Set<String> DAMAGE_EFFECTS = Set.of("创", "灭", "蚀", "引", "斥");
    private static final Set<String> DAMAGE_FORMS = Set.of("弹", "刃", "柱", "雨", "刺", "涡", "潮");
    private static final Map<String, Integer> EFFECT_BASE_VALUE = pairs("愈", 90, "缚", 70, "解", 85, "传", 100, "封", 95, "幻", 65, "真", 60);
    private static final Map<String, String> ELEMENT_DAMAGE_TYPE = pairs("火", "magic", "水", "magic", "风", "physical", "土", "physical", "雷", "magic", "冰", "magic", "木", "magic", "金", "physical", "光", "magic", "暗", "magic");
    private static final int BASE_DAMAGE_BONUS = 150;
    private static final int RESISTANCE_MANA_BASE = 100;
    private static final int FORBIDDEN_MANA_BONUS = 2000;
    private static final int DEFAULT_SUSTAIN_DURATION = 5;
    private static final double SOURCE_MANA_COST_MULTIPLIER = 0.70;
    private static final double SOURCE_DAMAGE_MULTIPLIER = 1.30;

    public static SpellStats calculate(List<String> runes) {
        if (runes == null) runes = List.of();
        SpellStats s = new SpellStats();
        List<String> targets = group(runes, RuneGroup.TARGET);
        List<String> elements = group(runes, RuneGroup.ELEMENT);
        List<String> ancient = group(runes, RuneGroup.ANCIENT);
        List<String> effects = group(runes, RuneGroup.EFFECT);
        List<String> forms = group(runes, RuneGroup.FORM);
        List<String> modifiers = group(runes, RuneGroup.MODIFIER);
        List<String> resistances = group(runes, RuneGroup.RESISTANCE);

        List<String> fullSeq = new ArrayList<>();
        fullSeq.addAll(targets); fullSeq.addAll(elements); fullSeq.addAll(ancient); fullSeq.addAll(effects); fullSeq.addAll(forms); fullSeq.addAll(modifiers); fullSeq.addAll(resistances);
        s.runeString = String.join("·", fullSeq);
        s.runeCount = fullSeq.size();
        boolean hasAncient = !ancient.isEmpty();
        s.forbidden = hasAncient;
        s.flash = modifiers.contains("瞬");
        s.hasSource = ancient.contains("源");

        // 网页规则：至少要有 目标+效果+形态，或包含抗性符文，否则“不能静默计算”
        if ((targets.isEmpty() || forms.isEmpty() || effects.isEmpty()) && resistances.isEmpty()) {
            s.valid = false;
            s.error = "不能静默计算：请至少选择 目标、效果 与 形态（或抗性符文）。";
            return s;
        }

        // 图鉴匹配 → 名称 / 阶位 / 描述
        List<CodexData.Match> matches = CodexData.collectMatches(targets, elements, ancient, effects, forms, modifiers);
        CodexData.Match best = null;
        for (CodexData.Match m : matches) if (m.exact() && !m.spell().generated()) { best = m; break; }
        if (best == null) for (CodexData.Match m : matches) if (!m.spell().generated()) { best = m; break; }
        if (best == null && !matches.isEmpty()) best = matches.get(0);

        String tierKey;
        if (best != null) {
            s.codexMatch = best.spell().name();
            s.name = best.spell().name();
            s.description = best.spell().effect();
            tierKey = hasAncient ? "禁忌" : best.spell().tier();
        } else {
            tierKey = hasAncient ? "禁忌" : tierKeyByCount(fullSeq.size());
            s.name = makeName(s.runeString, elements, effects, forms.isEmpty() ? "" : forms.get(0));
            s.description = makeDesc(targets, elements, effects, forms, modifiers);
        }
        s.tier = tierDisplay(tierKey);
        s.array = tierToArray(s.tier);
        s.stabilizers = Math.max(0, elements.size() - 1) + Math.max(0, effects.size() - 1) + (ancient.stream().anyMatch(a -> !a.equals("源")) ? 1 : 0);

        double tierMult = DAMAGE_TIER_MULTIPLIER.getOrDefault(tierKey, 0.55);

        // 图鉴推导基值（deriveCodexStatsFromRunes）
        int baseRaw = 0;
        for (String r : fullSeq) {
            Runes.Def d = Runes.get(r);
            if (d == null) continue;
            if (d.group == RuneGroup.TARGET || d.group == RuneGroup.ELEMENT || d.group == RuneGroup.ANCIENT || d.group == RuneGroup.EFFECT || d.group == RuneGroup.FORM) {
                if (!isIgnoredDamageRune(d)) baseRaw += Math.max(0, d.damage);
            }
        }
        int codexBonus = isDamageSpell(effects, forms) ? (int) Math.round(baseRaw * 0.25) : 0;

        // 伤害结算（calcDamageBreakdown）
        s.hasDamage = isDamageSpell(effects, forms);
        if (s.hasDamage) {
            int raw = 0;
            for (String r : fullSeq) {
                Runes.Def d = Runes.get(r);
                if (d == null) continue;
                if (isIgnoredDamageRune(d)) continue;
                if (d.group == RuneGroup.TARGET || d.group == RuneGroup.ELEMENT || d.group == RuneGroup.ANCIENT || d.group == RuneGroup.EFFECT || d.group == RuneGroup.FORM) raw += Math.max(0, d.damage);
            }
            double modMult = 1;
            for (String m : modifiers) modMult *= DAMAGE_MODIFIERS.getOrDefault(m, 1.0);
            double pre = raw + BASE_DAMAGE_BONUS + codexBonus;
            int normalTotal = (int) Math.min(50000, Math.max(1, Math.round(pre * tierMult * modMult)));
            int sourceTotal = (int) Math.round(normalTotal * (s.hasSource ? SOURCE_DAMAGE_MULTIPLIER : 1));
            s.damage = (int) Math.min(50000, Math.max(1, Math.round(sourceTotal / 10.0)));
            s.damageType = damageType(elements);
        } else {
            s.damageType = "none";
        }
        s.accuracyBonus = accuracyBonus(modifiers, targets.isEmpty() ? "" : targets.get(0));
        s.resistPenetration = resistPenetration(modifiers, ancient);

        // 效果结算（calcEffectBreakdown）
        double effectMult = 1;
        for (String m : modifiers) {
            if (m.equals("续")) effectMult *= 1.15;
            if (m.equals("瞬")) effectMult *= 0.95;
            if (m.equals("隐")) effectMult *= 0.90;
            if (m.equals("倍")) effectMult *= 1.20;
            if (m.equals("微")) effectMult *= 0.50;
        }
        for (String e : effects) {
            int base;
            String category;
            if (EFFECT_BASE_VALUE.containsKey(e)) {
                base = EFFECT_BASE_VALUE.get(e);
                category = effectCategory(e);
            } else {
                Runes.Def d = Runes.get(e);
                if (d == null || d.damage <= 0) continue;
                base = d.damage;
                category = "damage";
            }
            double factor = 1;
            for (String el : elements) {
                if (e.equals("愈") && List.of("水", "木", "光").contains(el)) factor += 0.15;
                if (e.equals("缚") && List.of("冰", "土", "木").contains(el)) factor += 0.10;
                if (e.equals("幻") && el.equals("暗")) factor += 0.12;
                if (e.equals("解") && el.equals("光")) factor += 0.12;
            }
            for (String f : forms) {
                if (e.equals("愈") && List.of("环", "雨", "雾").contains(f)) factor += 0.12;
                if (e.equals("缚") && List.of("网", "链", "环", "雾").contains(f)) factor += 0.12;
                if (e.equals("封") && List.of("环", "柱", "涡").contains(f)) factor += 0.10;
            }
            int value = Math.max(1, (int) Math.round(base * tierMult * effectMult * factor));
            s.effectTotal += value;
            switch (category) {
                case "healing" -> s.healing += value;
                case "control" -> s.control += value;
                case "utility" -> s.utility += value;
                default -> {}
            }
        }

        // 耗魔结算（getMana）
        int baseMana = 0, sustainMana = 0;
        for (String r : fullSeq) {
            Runes.Def d = Runes.get(r);
            if (d == null) continue;
            if (d.group == RuneGroup.RESISTANCE) continue;
            baseMana += d.mana;
            sustainMana += d.sustain;
        }
        int resistanceMana = resistances.size() * RESISTANCE_MANA_BASE;
        baseMana += resistanceMana;
        double manaMod = 1;
        for (String m : modifiers) manaMod *= MANA_MODIFIERS.getOrDefault(m, 1.0);
        int duration = sustainMana > 0 ? (modifiers.contains("续") ? DEFAULT_SUSTAIN_DURATION * 2 : DEFAULT_SUSTAIN_DURATION) : 0;
        int preSourceInitial = (int) Math.max(0, Math.round(baseMana * manaMod));
        int preSourceSustain = (int) Math.max(0, Math.round(sustainMana * manaMod));
        double srcMult = s.hasSource ? SOURCE_MANA_COST_MULTIPLIER : 1;
        int initial = (int) Math.max(0, Math.round(preSourceInitial * srcMult));
        int sustain = (int) Math.max(0, Math.round(preSourceSustain * srcMult));
        int total = Math.max(0, initial + sustain * duration + (s.forbidden ? FORBIDDEN_MANA_BONUS : 0));
        s.manaTotal = scaleMana(total);
        s.manaInitial = scaleMana(initial);
        s.sustainPerSecond = scaleMana(sustain);
        s.duration = duration;

        // 构建时间（getTime）
        boolean source = s.hasSource;
        int effectiveTotal = Math.max(1, s.runeCount - (source ? 1 : 0));
        double time = effectiveTotal * 0.4;
        if (modifiers.contains("疾")) time *= 0.5;
        if (modifiers.contains("缓")) time *= 2;
        if (s.flash) time = 0.1; // 瞬发最后覆盖，避免与「缓」相乘得到 0.2s
        s.buildTime = Math.max(0.1, time);
        s.cooldownTicks = s.flash ? 0 : (int) Math.max(5, Math.round(s.buildTime * 20));
        return s;
    }

    private static int scaleMana(int v) { return Math.max(0, (int) Math.round(v / 10.0)); }
    private static List<String> group(List<String> runes, RuneGroup g) {
        List<String> out = new ArrayList<>();
        if (runes == null) return out;
        for (String r : runes) { Runes.Def d = Runes.get(r); if (d != null && d.group == g) out.add(r); }
        return out;
    }
    private static boolean isIgnoredDamageRune(Runes.Def d) {
        if (d.group == RuneGroup.EFFECT) return NON_DAMAGE_EFFECTS.contains(d.rune) || d.damage == 0;
        if (d.group == RuneGroup.FORM) return d.damage == 0;
        return d.group == RuneGroup.ANCIENT && d.rune.equals("源");
    }
    private static boolean isDamageSpell(List<String> effects, List<String> forms) {
        for (String e : effects) if (DAMAGE_EFFECTS.contains(e)) return true;
        if (!effects.isEmpty() && NON_DAMAGE_EFFECTS.containsAll(effects)) return false;
        return !effects.isEmpty() && forms.stream().anyMatch(DAMAGE_FORMS::contains);
    }
    private static String effectCategory(String e) {
        return switch (e) {
            case "愈" -> "healing";
            case "缚", "封", "幻" -> "control";
            case "解", "传", "真" -> "utility";
            default -> "damage";
        };
    }
    private static double accuracyBonus(List<String> mods, String target) {
        double bonus = 0;
        for (String m : mods) {
            if (m.equals("锁")) bonus += 0.10;
            else if (m.equals("疾")) bonus += 0.02;
            else if (m.equals("裂")) bonus -= 0.04;
            else if (m.equals("隐")) bonus -= 0.01;
        }
        if (target.equals("群")) bonus -= 0.03;
        if (target.equals("灵")) bonus -= 0.02;
        return Math.max(-0.50, Math.min(0.50, bonus));
    }
    private static double resistPenetration(List<String> mods, List<String> ancient) {
        double pct = 0;
        for (String m : mods) {
            if (m.equals("倍")) pct += 0.05;
            if (m.equals("锁")) pct += 0.03;
        }
        if (ancient.contains("空")) pct += 0.25;
        return Math.max(0, Math.min(0.80, pct));
    }
    private static String damageType(List<String> elements) {
        boolean magic = false, physical = false;
        for (String e : elements) { if ("physical".equals(ELEMENT_DAMAGE_TYPE.get(e))) physical = true; else magic = true; }
        if (magic && physical) return "mixed";
        if (magic) return "magic";
        if (physical) return "physical";
        return "true";
    }
    private static String tierKeyByCount(int total) {
        if (total <= 1) return "一阶";
        if (total <= 3) return "二阶";
        if (total <= 6) return "三阶";
        if (total <= 12) return "四阶";
        return "五阶";
    }
    public static String tierDisplay(String key) {
        return switch (key) {
            case "禁忌" -> "禁忌阶";
            case "一阶" -> "一阶 · 学徒";
            case "二阶" -> "二阶 · 初阶";
            case "三阶" -> "三阶 · 中阶";
            case "四阶" -> "四阶 · 高阶";
            case "五阶" -> "五阶 · 大魔导";
            default -> key;
        };
    }
    private static String tierToArray(String tier) {
        if (tier.contains("禁忌")) return "禁忌复合阵";
        if (tier.contains("一阶")) return "单环阵";
        if (tier.contains("四阶")) return "三环阵";
        if (tier.contains("五阶")) return "星阵";
        return "双环阵";
    }

    // ── 自由组合命名（移植 makeName / makeDesc）──
    /** FNV-1a；必须返回非负数：后面用 h % n 取数组下标，负数会抛 ArrayIndexOutOfBoundsException。 */
    private static int hash(String str) { int h = 0x811c9dc5; for (char c : str.toCharArray()) { h ^= c; h *= 16777619; } return h & 0x7fffffff; }
    private static final Map<String, String[]> ELEM_PREFIX = pairs(
        "火", new String[]{"火","炎","炽","焰","焚"}, "水", new String[]{"水","寒","潮","汐","涟"},
        "风", new String[]{"风","疾","裂","空","岚"}, "土", new String[]{"土","岩","山","沙","磐"},
        "雷", new String[]{"雷","电","磁","霆","霹"}, "冰", new String[]{"冰","霜","寒","雪","凌"},
        "木", new String[]{"木","藤","花","林","荊"}, "金", new String[]{"金","铁","钢","刃","锋"},
        "光", new String[]{"光","圣","日","辉","曜"}, "暗", new String[]{"暗","影","夜","冥","幽"});
    private static final Map<String, String[]> FORM_SUFFIX = pairs(
        "弹", new String[]{"弹","球","珠"}, "刃", new String[]{"刃","斩","锋"}, "壁", new String[]{"壁","墙","障"},
        "环", new String[]{"环","轮","圈"}, "柱", new String[]{"柱","矛","峰"}, "网", new String[]{"网","笼","罩"},
        "链", new String[]{"链","锁","缚"}, "雨", new String[]{"雨","落","坠"}, "雾", new String[]{"雾","霭","幕"},
        "刺", new String[]{"刺","锥","针"}, "涡", new String[]{"涡","旋","卷"}, "潮", new String[]{"潮","浪","涌"});

    private static String makeName(String runeStr, List<String> elements, List<String> effects, String form) {
        int h = hash(runeStr);
        String main = elements.isEmpty() ? "无" : elements.get(0);
        if (effects.contains("愈") && !effects.contains("灭")) {
            String pre = new String[]{"治愈","生命","回春","复苏"}[h % 4];
            String suf = switch (form) { case "壁" -> "壁"; case "环" -> "之环"; case "雨" -> "之雨"; case "雾" -> "之雾"; case "柱" -> "之柱"; case "刺" -> "之刺"; default -> form; };
            return pre + suf;
        }
        if (effects.contains("传")) {
            String pre = new String[]{"瞬移","传送","位移","跃迁"}[h % 4];
            String suf = form.equals("环") ? "之门" : form.equals("刺") ? "之刺" : "";
            return pre + suf;
        }
        if (effects.contains("封") && !effects.contains("灭")) {
            String pre = new String[]{"封印","禁锢","封锁"}[h % 3];
            String mid = main.equals("无") ? "" : main;
            String suf = switch (form) { case "环" -> "环"; case "柱" -> "柱"; case "涡" -> "涡"; case "刺" -> "印"; case "壁" -> "壁"; default -> "之印"; };
            return pre + mid + suf;
        }
        String[] prefixes = ELEM_PREFIX.getOrDefault(main, new String[]{main});
        String[] suffixes = FORM_SUFFIX.getOrDefault(form, new String[]{form});
        return prefixes[h % prefixes.length] + suffixes[(h >>> 5) % suffixes.length];
    }

    private static final Map<String, String> T_DESC = pairs("己","以自身为作用对象","触","通过接触目标","视","向视线方向投射","指","在指定坐标点","域","覆盖一片区域","群","同时作用于多个目标","灵","作用于目标的灵魂层面","物","作用于无生命的物体");
    private static final Map<String, String> E_DESC = pairs("火","燃烧与热能","水","流动与渗透","风","迅捷与切割","土","承载与沉重","雷","爆裂与麻痹","冰","凝滞与封存","木","生长与缠绕","金","锐利与坚硬","光","照耀与净化","暗","吞噬与侵蚀");
    private static final Map<String, String> F_DESC = pairs("创","从无到有地构建实体","灭","以纯粹毁灭瓦解结构","缚","束缚并锁定","解","解除并净化","愈","修复并再生","蚀","腐蚀并削弱","传","位移并传送","封","封印并隔绝","引","吸引并牵引","斥","排斥并推开","幻","制造幻象","真","显形并破妄");
    private static final Map<String, String> S_DESC = pairs("弹","球体","刃","锋面","壁","屏障","环","圆环","柱","柱体","网","网格","链","链条","雨","落雨","雾","弥散场","刺","尖刺","涡","漩涡","潮","冲击波");

    private static String makeDesc(List<String> targets, List<String> elements, List<String> effects, List<String> forms, List<String> mods) {
        List<String> parts = new ArrayList<>();
        parts.add(String.join("与", targets.stream().map(t -> T_DESC.getOrDefault(t, "施放")).toList()));
        if (!elements.isEmpty()) parts.add("凝聚" + String.join("与", elements.stream().map(e -> E_DESC.getOrDefault(e, e)).toList()));
        if (!effects.isEmpty()) parts.add("以" + String.join("、", effects.stream().map(e -> F_DESC.getOrDefault(e, e)).toList()) + "的方式");
        parts.add("形成" + String.join("、", forms.stream().map(f -> S_DESC.getOrDefault(f, f)).toList()) + "。");
        StringBuilder extra = new StringBuilder();
        if (mods.contains("倍")) extra.append("威力被放大至两倍，但魔力消耗剧增。");
        if (mods.contains("微")) extra.append("规模被压缩，消耗与威力同时减半。");
        if (mods.contains("裂")) extra.append("术式可一分为多，同时攻向数个方向。");
        if (mods.contains("锁")) extra.append("命中后会自动追踪目标，难以摆脱。");
        if (mods.contains("续")) extra.append("效果持续时间被显著延长。");
        if (mods.contains("隐")) extra.append("魔力波动被压制，难以被敌方感知。");
        if (mods.contains("瞬")) extra.append("无需蓄力，可瞬间释放（模组规则：耗魔×1.6，无视冷却）。");
        if (mods.contains("疾")) extra.append("构建时间大幅缩短。");
        if (mods.contains("缓")) extra.append("术式被挂起，等待条件触发。");
        if (mods.contains("转")) extra.append("属性可在释放瞬间相互转化。");
        return String.join("，", parts) + (extra.length() > 0 ? " " + extra : "");
    }

    public static String damageTypeLabel(String type) {
        return switch (type) {
            case "magic" -> "魔法伤害（法抗）";
            case "physical" -> "物理伤害（物抗）";
            case "mixed" -> "混合伤害（物抗 + 法抗）";
            case "true" -> "真实伤害（无抗性）";
            default -> "非直接伤害";
        };
    }

    @SuppressWarnings("unchecked")
    private static <V> Map<String, V> pairs(Object... values) {
        Map<String, V> out = new HashMap<>();
        for (int i = 0; i + 1 < values.length; i += 2) out.put((String) values[i], (V) values[i + 1]);
        return out;
    }

    private SpellCalculator() {}
}
