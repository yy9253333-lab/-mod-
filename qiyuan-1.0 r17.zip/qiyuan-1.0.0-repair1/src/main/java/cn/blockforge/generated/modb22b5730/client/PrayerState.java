package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.client.Minecraft;
import java.util.*;

/** 客户端缓存的玩家《祈愿》数据（由服务器同步包更新）。 */
public final class PrayerState {
    public static int mana = 0;
    public static float manaPool = 0.0F;
    public static int maxMana = 200;
    public static float manaCost = 10;
    public static boolean legacyRuneCosts = false;
    public static float spellCost(SpellStats stats) { return legacyRuneCosts ? stats.manaTotal : manaCost; }
    public static float instability = 1.0F;
    public static float proficiency = 0.0F;
    public static float comprehension = 0.0F;
    public static boolean noFocusUnlocked = false;
    public static boolean charging = false;
    public static int chargeTicks = 0;
    public static int duplicates = 1;
    /** 服务端按基础上限与天赋同步的复制上限。 */
    public static int duplicateLimit = 5;
    public static final Set<String> ever = new LinkedHashSet<>();
    public static String active = "";
    /** 最近一次成功刻印的符文串，用于一键恢复到编辑区。 */
    public static String lastEngraved = "";
    public static long cooldownEnd = 0;
    public static boolean guideDone = false;
    public static boolean creative = false;
    public static final List<String[]> presets = new ArrayList<>();
    public static final List<String> recent = new ArrayList<>();
    public static SpellStats activeStats = null;
    /** 施法特效脉冲：服务端 CastFx 包到达时写入当前 gameTime，渲染层据此点亮视野前法阵。 */
    public static long castPulseTick = Long.MIN_VALUE;
    public static int castPulseColor = 0x3D9CB8;

    public static void apply(CompoundTag t) {
        mana = t.getInt("mana");
        manaPool = t.contains("mana_pool") ? t.getFloat("mana_pool") : mana;
        maxMana = t.getInt("max");
        manaCost = t.contains("mana_cost") ? t.getFloat("mana_cost") : 10;
        legacyRuneCosts = t.getBoolean("legacy_rune_costs");
        instability = t.getFloat("instability");
        proficiency = t.getFloat("proficiency");
        comprehension = t.getFloat("comprehension");
        noFocusUnlocked = t.getBoolean("no_focus_unlocked");
        charging = t.getBoolean("charging");
        chargeTicks = t.getInt("charge_ticks");
        duplicateLimit = Math.max(5, t.contains("duplicate_limit") ? t.getInt("duplicate_limit") : 5);
        duplicates = Math.max(1, Math.min(duplicateLimit, t.getInt("duplicates")));
        creative = t.getBoolean("creative");
        ever.clear();
        for (String r : t.getString("ever").split("\\|")) if (Runes.contains(r)) ever.add(r);
        active = t.getString("active");
        lastEngraved = t.getString("last_engraved");
        cooldownEnd = t.getLong("cooldown");
        guideDone = t.getBoolean("guide");
        recent.clear();
        ListTag recentTag = t.getList("recent", 8);
        for (int i = 0; i < recentTag.size() && recent.size() < PrayerData.RECENT_SLOTS; i++) {
            String rune = recentTag.getString(i);
            if (!PrayerData.parse(rune).isEmpty() && !recent.contains(rune)) recent.add(rune);
        }
        presets.clear();
        for (int i = 0; i < PrayerData.PRESET_SLOTS; i++) presets.add(new String[]{"", ""});
        ListTag list = t.getList("presets", 10);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            int slot = c.getInt("slot");
            if (slot >= 0 && slot < presets.size()) presets.set(slot, new String[]{c.getString("name"), c.getString("runes")});
        }
        try {
            activeStats = active.isEmpty() ? null : SpellCalculator.calculate(PrayerData.parse(active));
        } catch (RuntimeException ignored) {
            activeStats = null;
        }
    }

    /** 清理断线/切换世界后的客户端缓存，避免旧角色状态残留。 */
    public static void reset() {
        mana = 0; manaPool = 0.0F; maxMana = 200; instability = 1.0F; proficiency = 0.0F; comprehension = 0.0F;
        noFocusUnlocked = false; charging = false; chargeTicks = 0; duplicates = 1; duplicateLimit = 5;
        active = ""; lastEngraved = ""; cooldownEnd = 0; guideDone = false; creative = false; castPulseTick = Long.MIN_VALUE;
        manaCost = 10; legacyRuneCosts = false;
        TalentClientState.points = 0; TalentClientState.nodes.clear(); TalentClientState.unlocked.clear();
        TalentClientState.interruptedUntil = Long.MIN_VALUE;
        ever.clear(); recent.clear(); presets.clear(); activeStats = null;
    }

    public static boolean onCooldown() {
        long now = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
        return now < cooldownEnd;
    }

    public static double cooldownLeft() {
        long now = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
        return Math.max(0, (cooldownEnd - now) / 20.0);
    }

    private PrayerState() {}
}
