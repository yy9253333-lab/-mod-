package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 键盘与滚轮只发请求；当前术式始终由服务器校验并同步。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientControls {
    private static boolean lastCharging;
    private static int localDuplicates = 1;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            if (lastCharging && mc.getConnection() != null) PrayerNet.sendChargeCancel();
            lastCharging = false;
            localDuplicates = 1;
            PrayerState.reset();
            return;
        }
        // KeyInputEvent 不能取消原版丢弃/背包动作；在 tick 消费冲突映射的 click 才不会丢物。
        boolean previousClicked = ClientKeyMappings.PREVIOUS.consumeClick();
        boolean nextClicked = ClientKeyMappings.NEXT.consumeClick();
        while (previousClicked && mc.options.keyDrop.consumeClick()) { }
        while (nextClicked && mc.options.keyInventory.consumeClick()) { }

        if (!mc.isWindowActive() || mc.screen != null) {
            while (ClientKeyMappings.PREVIOUS.consumeClick()) { }
            while (ClientKeyMappings.NEXT.consumeClick()) { }
            while (ClientKeyMappings.OPEN_TALENTS.consumeClick()) { }
            while (ClientKeyMappings.ALT_RIGHT_CAST.consumeClick()) { }
            if (lastCharging) { lastCharging = false; PrayerNet.sendChargeCancel(); }
            return;
        }
        if (previousClicked && AimTracker.holdsCastingFocus(mc.player)) PrayerNet.sendCycleRecent(-1);
        if (nextClicked && AimTracker.holdsCastingFocus(mc.player)) PrayerNet.sendCycleRecent(1);
        if (!AimTracker.holdsCastingFocus(mc.player)) {
            while (ClientKeyMappings.PREVIOUS.consumeClick()) { }
            while (ClientKeyMappings.NEXT.consumeClick()) { }
        }
        if (ClientKeyMappings.OPEN_TALENTS.consumeClick()) mc.setScreen(new TalentTreeScreen());
        while (ClientKeyMappings.ALT_RIGHT_CAST.consumeClick()) {
            if (PrayerState.noFocusUnlocked) PrayerNet.sendCastRequest();
        }

        // G 是轮询按住状态，只在边沿发包；释放只改变蓄力状态，不触发普通施法。
        boolean interrupted = cn.blockforge.generated.modb22b5730.client.TalentClientState.interrupted(mc.level == null ? 0 : mc.level.getGameTime());
        boolean charging = ClientKeyMappings.CHARGE.isDown() && !interrupted;
        if (charging != lastCharging) {
            if (charging) localDuplicates = 1;
            lastCharging = charging;
            PrayerNet.sendChargeState(charging);
        }
    }

    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || event.getScrollDelta() == 0) return;
        double amount = event.getScrollDelta();
        if (mc.player.isShiftKeyDown() && lastCharging) {
            localDuplicates = Math.max(1, Math.min(PrayerState.duplicateLimit, localDuplicates + (amount > 0 ? 1 : -1)));
            PrayerNet.sendDuplicateCount(localDuplicates);
            event.setCanceled(true);
            return;
        }
        // 普通潜行滚轮必须留给原版快捷栏；只有瞄准施法焦点时才切术式。
        if (!mc.player.isShiftKeyDown() && AimTracker.holdsCastingFocus(mc.player)) {
            PrayerNet.sendCycleRecent(amount > 0 ? -1 : 1);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) return;
        if (event.isUseItem() && PrayerState.noFocusUnlocked
            && ClientKeyMappings.ALT_RIGHT_CAST.isActiveAndMatches(mc.options.keyUse.getKey())) {
            event.setCanceled(true); // 仅解锁无焦点施法后拦截原版 use/swing。
            event.setSwingHand(false); // consumeClick统一发包，避免重复释放。
            return;
        }
        if (event.isUseItem() && player.isShiftKeyDown() && player.getMainHandItem().isEmpty() && player.getOffhandItem().isEmpty()) {
            event.setCanceled(true);
            if (event.getHand() == InteractionHand.MAIN_HAND) PrayerNet.sendMeditate();
        }
    }

    @SubscribeEvent
    public static void onScreenOpening(ScreenEvent.Opening event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getNewScreen() instanceof InventoryScreen && mc.player != null && ClientKeyMappings.NEXT.isDown()) {
            event.setCanceled(true); // Alt+E 不打开背包；按键 click 仍由 tick 消费。
        }
    }

    private ClientControls() {}
}
