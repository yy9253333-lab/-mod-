package cn.blockforge.generated.modb22b5730.client;

import java.util.*;
import cn.blockforge.generated.modb22b5730.talent.TalentTree;

/** Client cache populated only by server packets; never reads server-side NODES. */
public final class TalentClientState {
    public static int points;
    public static long interruptedUntil = Long.MIN_VALUE;
    public static final Set<String> unlocked = new LinkedHashSet<>();
    public static final Map<String,TalentTree.ClientNode> nodes = new LinkedHashMap<>();
    public static void apply(int p, Set<String> ids, Collection<TalentTree.ClientNode> defs) {
        points=Math.max(0,p); unlocked.clear(); unlocked.addAll(ids); nodes.clear();
        for (TalentTree.ClientNode n: defs) if (nodes.size()<512) nodes.put(n.id(),n);
    }
    public static boolean interrupted(long gameTime) { return gameTime < interruptedUntil; }
    private TalentClientState() {}
}
