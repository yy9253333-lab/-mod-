package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

/** 祈愿魔导书：右键打开法阵台（组阵/图鉴/预制/引导），潜行右键施放已刻印的术式。 */
public class PrayerBookItem extends Item {
    public PrayerBookItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (player.isShiftKeyDown()) SpellCaster.tryCast(sp);
            else PrayerNet.openBook(sp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override public Component getName(ItemStack stack) { return Component.literal("《祈愿》魔导书").withStyle(ChatFormatting.LIGHT_PURPLE); }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal("右键：打开法阵台（组阵 · 图鉴 · 预制 · 引导）").withStyle(ChatFormatting.GRAY));
        tips.add(Component.literal("潜行右键：施放已刻印的术式").withStyle(ChatFormatting.GRAY));
        tips.add(Component.literal("施法消耗魔力，魔力随时间恢复，吃魔素结晶可提升魔力容量上限（每枚 +20，不会补满）").withStyle(ChatFormatting.DARK_GRAY));
    }

    @Override public boolean isFoil(ItemStack stack) { return true; }
}
