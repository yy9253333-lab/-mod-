package cn.blockforge.generated.modb22b5730.spell;

/** 规格2.3的无空气阻力离散弹道；与Minecraft类无耦合，供回归测试直接调用。 */
public final class Ballistics {
    public static final double GRAVITY = 0.03;
    public record Shot(double x, double y, double z, boolean gravity, double flightTicks) {}
    public static Shot solve(double dx, double dy, double dz) {
        if (!Double.isFinite(dx) || !Double.isFinite(dy) || !Double.isFinite(dz))
            throw new IllegalArgumentException("Non-finite target");
        double d = Math.hypot(dx, dz);
        if (d < 0.5 || d - dy <= 0.0) {
            double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (length < 1.0e-8) return new Shot(0, 0, 1, false, 0);
            return new Shot(dx / length, dy / length, dz / length, false, length);
        }
        double n = (1 + Math.sqrt(1 + 8 * (d - dy) / GRAVITY)) / 2;
        double vh = d / n;
        return new Shot(dx / n, vh, dz / n, true, n);
    }
    /** 点与包围盒最近点距离平方；AABB仅作粗筛，精筛必须用此几何。 */
    public static double boxDistanceSquared(double x, double y, double z,
            double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        double dx = x - Math.max(minX, Math.min(maxX, x));
        double dy = y - Math.max(minY, Math.min(maxY, y));
        double dz = z - Math.max(minZ, Math.min(maxZ, z));
        return dx * dx + dy * dy + dz * dz;
    }
    public static double sigma(double instability, double proficiency, double reduction) {
        return Math.toRadians(6.0 * Math.max(0, Math.min(5, instability))
            * (1 - 0.9 * Math.max(0, Math.min(500, proficiency)) / 500)
            * (1 - Math.max(0, Math.min(0.8, reduction))));
    }
    private Ballistics() {}
}
