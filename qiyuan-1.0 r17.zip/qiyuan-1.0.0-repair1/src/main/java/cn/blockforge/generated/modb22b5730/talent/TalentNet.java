package cn.blockforge.generated.modb22b5730.talent;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.*;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.*;

public final class TalentNet {
    private static final SimpleChannel CH=NetworkRegistry.newSimpleChannel(GeneratedMod.rl("talent"),()->"1","1"::equals,"1"::equals);
    private static int id; private record Unlock(String node){} private record Sync(int points,Set<String> nodes,List<TalentTree.ClientNode> defs){} private record Interrupt(long until){}
    private static final Map<UUID,Long> last=new HashMap<>();
    public static void register(){
        CH.messageBuilder(Unlock.class,id++,NetworkDirection.PLAY_TO_SERVER).encoder((m,b)->b.writeUtf(m.node,128)).decoder(b->new Unlock(b.readUtf(128))).consumerMainThread((m,c)->{ServerPlayer p=c.get().getSender();if(p!=null){long now=p.level().getGameTime(), prev=last.getOrDefault(p.getUUID(),Long.MIN_VALUE);if(prev==Long.MIN_VALUE||now-prev>=5){last.put(p.getUUID(),now);TalentTree.unlock(p,m.node);}send(p);}c.get().setPacketHandled(true);}).add();
        CH.messageBuilder(Sync.class,id++,NetworkDirection.PLAY_TO_CLIENT).encoder((m,b)->{b.writeVarInt(Math.max(0,m.points));b.writeVarInt(Math.min(512,m.nodes.size()));int n=0;for(String x:m.nodes)if(n++<512)b.writeUtf(x,128);b.writeVarInt(Math.min(512,m.defs.size()));n=0;for(TalentTree.ClientNode d:m.defs)if(n++<512)writeNode(b,d);}).decoder(b->{int points=b.readVarInt(),n=Math.min(512,Math.max(0,b.readVarInt()));Set<String>s=new LinkedHashSet<>();for(int i=0;i<n;i++)s.add(b.readUtf(128));int k=Math.min(512,Math.max(0,b.readVarInt()));List<TalentTree.ClientNode> defs=new ArrayList<>();for(int i=0;i<k;i++)defs.add(readNode(b));return new Sync(points,s,defs);}).consumerMainThread((m,c)->{DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->cn.blockforge.generated.modb22b5730.client.TalentClientState.apply(m.points,m.nodes,m.defs));c.get().setPacketHandled(true);}).add();
        CH.messageBuilder(Interrupt.class,id++,NetworkDirection.PLAY_TO_CLIENT).encoder((m,b)->b.writeLong(m.until)).decoder(b->new Interrupt(b.readLong())).consumerMainThread((m,c)->{DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->cn.blockforge.generated.modb22b5730.client.TalentClientState.interruptedUntil=m.until);c.get().setPacketHandled(true);}).add();
    }
    private static void writeNode(FriendlyByteBuf b,TalentTree.ClientNode d){b.writeUtf(d.id(),128);b.writeVarInt(d.cost());b.writeVarInt(Math.min(512,d.prerequisites().size()));for(String p:d.prerequisites().stream().limit(512).toList())b.writeUtf(p,128);b.writeVarInt(Math.min(512,d.modifiers().size()));for(TalentTree.ModDef m:d.modifiers().stream().limit(512).toList()){b.writeUtf(m.attr(),64);b.writeDouble(m.amount());b.writeEnum(m.op());}}
    private static TalentTree.ClientNode readNode(FriendlyByteBuf b){String id=b.readUtf(128);int cost=b.readVarInt();List<String> pre=new ArrayList<>();int np=Math.min(512,Math.max(0,b.readVarInt()));for(int i=0;i<np;i++)pre.add(b.readUtf(128));List<TalentTree.ModDef> mods=new ArrayList<>();int nm=Math.min(512,Math.max(0,b.readVarInt()));for(int i=0;i<nm;i++)mods.add(new TalentTree.ModDef(b.readUtf(64),b.readDouble(),b.readEnum(net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.class)));return new TalentTree.ClientNode(id,cost,pre,mods);}
    public static void unlock(String id){if(id!=null&&id.length()<=128)CH.sendToServer(new Unlock(id));}
    public static void send(ServerPlayer p){TalentData d=TalentData.of(p);List<TalentTree.ClientNode> defs=TalentTree.all().values().stream().limit(512).map(TalentTree.Node::client).toList();CH.send(PacketDistributor.PLAYER.with(()->p),new Sync(Math.max(0,PrayerData.talentPoints(p)),new LinkedHashSet<>(d.unlocked()),defs));}
    public static void sendInterrupt(ServerPlayer p,long until){CH.send(PacketDistributor.PLAYER.with(()->p),new Interrupt(until));}
    private TalentNet(){}
}
