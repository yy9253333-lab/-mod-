package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.PrayerConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public class ManaCrystalItem extends Item {
    public ManaCrystalItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && PrayerData.capacity(player) >= PrayerConfig.MAX_CAPACITY.get())
            return InteractionResultHolder.fail(player.getItemInHand(hand));
        return ItemUtils.startUsingInstantly(level, player, hand);
    }
    @Override public int getUseDuration(ItemStack stack) { return 32; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.EAT; }
    @Override public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player) {
            int old = PrayerData.capacity(player);
            if (old < PrayerConfig.MAX_CAPACITY.get()) {
                PrayerData.setCapacity(player, old + PrayerConfig.CRYSTAL_CAPACITY_GAIN.get());
                if (!player.getAbilities().instabuild) stack.shrink(1);
                PrayerNet.sync(player);
            }
        }
        return stack;
    }
    @Override public Component getName(ItemStack stack) { return Component.literal("魔素结晶"); }
}
