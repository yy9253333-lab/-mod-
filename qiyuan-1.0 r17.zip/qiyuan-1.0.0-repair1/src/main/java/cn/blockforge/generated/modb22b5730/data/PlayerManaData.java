package cn.blockforge.generated.modb22b5730.data;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Capability门面复用原prayer NBT，避免旧存档与既有符文/预制系统形成两份数据源。 */
public final class PlayerManaData {
    public static final Capability<PlayerManaData> CAP = CapabilityManager.get(new CapabilityToken<>() {});
    private final Player owner;
    private PlayerManaData(Player owner) { this.owner = owner; }
    public float manaPool() { return PrayerData.manaPool(owner); }
    public int manaCapacity() { return PrayerData.capacity(owner); }
    public void setManaPool(float value) { PrayerData.setManaPool(owner, value); }
    public void addTalentPoints(int count) { PrayerData.addTalentPoints(owner, count); }
    public CompoundTag serializeNBT() { return PrayerData.of(owner).copy(); }
    public void deserializeNBT(CompoundTag value) { owner.getPersistentData().put(PrayerData.TAG, value.copy()); }

    private static final class Provider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
        final PlayerManaData data;
        final LazyOptional<PlayerManaData> optional;
        Provider(Player player) { data = new PlayerManaData(player); optional = LazyOptional.of(() -> data); }
        @Override public <T> LazyOptional<T> getCapability(Capability<T> capability, Direction side) {
            return capability == CAP ? optional.cast() : LazyOptional.empty();
        }
        @Override public CompoundTag serializeNBT() { return data.serializeNBT(); }
        @Override public void deserializeNBT(CompoundTag value) { data.deserializeNBT(value); }
    }
    @Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        @SubscribeEvent public static void register(RegisterCapabilitiesEvent event) { event.register(PlayerManaData.class); }
    }
    @Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
    public static final class Attachment {
        @SubscribeEvent public static void attach(AttachCapabilitiesEvent<Entity> event) {
            if (event.getObject() instanceof Player player) {
                Provider provider = new Provider(player);
                event.addCapability(GeneratedMod.rl("mana"), provider);
                event.addListener(provider.optional::invalidate);
            }
        }
    }
}
