package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.talent.TalentNet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Data-driven talent UI; node layout and definitions come from the server sync. */
public class TalentTreeScreen extends Screen {
 public TalentTreeScreen(){super(Component.translatable("screen.mod_b22b5730.talent_tree"));}
 @Override protected void init(){super.init();int y=42;for(var n:TalentClientState.nodes.values()){if(y>height-24)break;boolean unlocked=TalentClientState.unlocked.contains(n.id());addRenderableWidget(Button.builder(Component.literal((unlocked?"✓ ":"")+n.id()+" ("+n.cost()+")"),b->TalentNet.unlock(n.id())).bounds(18,y,width-36,20).build());y+=23;}}
 @Override public void render(GuiGraphics g,int mx,int my,float partial){renderBackground(g);g.drawCenteredString(font,title,width/2,15,0xffffff);g.drawString(font,Component.literal("天赋点数: "+TalentClientState.points),18,28,0xffd8c080);if(TalentClientState.nodes.isEmpty())g.drawCenteredString(font,Component.literal("未加载天赋节点：请定义 data/mod_b22b5730/talents/*.json"),width/2,55,0xffcc66);super.render(g,mx,my,partial);}
}
