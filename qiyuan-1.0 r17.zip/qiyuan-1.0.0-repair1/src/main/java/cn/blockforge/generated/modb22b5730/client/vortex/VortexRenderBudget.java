package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class VortexRenderBudget {
    private static int shellCount;
    @SubscribeEvent public static void beginFrame(RenderLevelStageEvent event) {
        if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_SOLID_BLOCKS) shellCount = 0;
    }
    public static boolean claim() { return shellCount++ < 8; }
    private VortexRenderBudget() {}
}
