package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.entity.VortexParticles;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class VortexParticleProviders {
    @SubscribeEvent public static void register(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(VortexParticles.GLOW.get(), sprites -> new Provider(sprites, false));
        event.registerSpriteSet(VortexParticles.SPLASH.get(), sprites -> new Provider(sprites, true));
    }
    private record Provider(SpriteSet sprites, boolean splash) implements ParticleProvider<SimpleParticleType> {
        @Override public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new VortexParticle(level, x, y, z, vx, vy, vz, sprites, splash);
        }
    }
    private static final class VortexParticle extends TextureSheetParticle {
        VortexParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, boolean splash) {
            super(level, x, y, z);
            xd = vx; yd = vy; zd = vz;
            lifetime = splash ? 12 : 20;
            gravity = splash ? 0.04F : 0.0F;
            quadSize = 0.12F;
            rCol = 0.30F; gCol = 0.82F; bCol = 1.0F;
            hasPhysics = false;
            pickSprite(sprites);
        }
        @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }
        @Override protected int getLightColor(float partial) { return 0xF000F0; }
        @Override public void tick() {
            super.tick();
            alpha = Math.max(0F, 1F - age / (float)lifetime);
        }
    }
    private VortexParticleProviders() {}
}
