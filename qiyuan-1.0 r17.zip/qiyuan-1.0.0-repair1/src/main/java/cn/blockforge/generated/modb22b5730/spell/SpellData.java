package cn.blockforge.generated.modb22b5730.spell;

import cn.blockforge.generated.modb22b5730.PrayerConfig;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import java.util.List;

/** 只描述新增视符文几何；原始符文串和数值仍由既有SpellCalculator负责。 */
public record SpellData(boolean hasVisionRune, float radius, double anchorDistance) {
    public static final Codec<SpellData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.BOOL.optionalFieldOf("hasVisionRune", false).forGetter(SpellData::hasVisionRune),
        Codec.floatRange(0.1F, 32.0F).optionalFieldOf("radius", 1.5F).forGetter(SpellData::radius),
        Codec.doubleRange(0.25, 16.0).optionalFieldOf("anchorDistance", 2.0).forGetter(SpellData::anchorDistance)
    ).apply(instance, SpellData::new));
    public static SpellData fromRunes(List<String> runes) {
        return new SpellData(runes.contains("视"), PrayerConfig.VISION_RADIUS.get().floatValue(), PrayerConfig.VISION_ANCHOR_DISTANCE.get());
    }
    public CompoundTag save() {
        return (CompoundTag)CODEC.encodeStart(NbtOps.INSTANCE, this).getOrThrow(false, error -> org.apache.logging.log4j.LogManager.getLogger().warn(error));
    }
    public static SpellData load(CompoundTag tag) {
        return CODEC.parse(NbtOps.INSTANCE, tag).result().orElse(new SpellData(false, 1.5F, 2.0));
    }
}
