package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.server.level.ServerPlayer;
import java.util.UUID;

/** 法阵实体：mode=0 是短暂、世界坐标固定的施法闪光；mode=1 仅承载持续区域逻辑。 */
public class SpellCircleEntity extends Entity {
    /** 世界法阵动画总时长：约 1.2 秒；不依赖持有法杖的状态。 */
    public static final int CAST_VISUAL_LIFE_TICKS = 24;
    /** 展开与符文依次显现阶段，约 0.5 秒。 */
    public static final int CAST_VISUAL_BUILD_TICKS = 10;
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RADIUS = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> MODE = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MAX_LIFE = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BUILD_TICKS = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    // 法阵法线：地面目标朝上，墙面目标沿命中面法线，实体/空中目标面向施法者。
    private static final EntityDataAccessor<Float> NORMAL_X = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> NORMAL_Y = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> NORMAL_Z = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private int life = CAST_VISUAL_LIFE_TICKS;
    private UUID ownerUuid;

    public SpellCircleEntity(EntityType<? extends SpellCircleEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
        noPhysics = true;
    }

    public static SpellCircleEntity spawn(Level level, Entity owner, String runes, int color, float radius, int mode, int lifeTicks) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks,
            Math.min(Math.max(1, lifeTicks), 20), owner.position());
    }

    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, Vec3 pos) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks,
            Math.min(Math.max(1, lifeTicks), 20), pos);
    }

    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, int buildTicks, Vec3 pos) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks, buildTicks, pos,
            new Vec3(0.0, 1.0, 0.0));
    }

    /** 生成定点法阵；pos 与 normal 均在服务端确认后固定，不随玩家或视角变化。 */
    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, int buildTicks, Vec3 pos, Vec3 normal) {
        SpellCircleEntity circle = new SpellCircleEntity(GeneratedMod.SPELL_CIRCLE.get(), level);
        // 最终坐标与法线必须在 addFreshEntity 前设置，否则客户端会先收到旧坐标/默认朝向。
        circle.setPos(pos.x, pos.y, pos.z);
        Vec3 safeNormal = normal != null && normal.lengthSqr() > 1.0e-8
            ? normal.normalize() : new Vec3(0.0, 1.0, 0.0);
        circle.entityData.set(NORMAL_X, (float) safeNormal.x);
        circle.entityData.set(NORMAL_Y, (float) safeNormal.y);
        circle.entityData.set(NORMAL_Z, (float) safeNormal.z);
        circle.entityData.set(RUNES, runes == null ? "" : runes);
        circle.entityData.set(COLOR, color);
        circle.entityData.set(RADIUS, Math.max(0.1f, radius));
        circle.entityData.set(MODE, mode);
        circle.entityData.set(OWNER_ID, owner == null ? -1 : owner.getId());
        circle.ownerUuid = owner == null ? null : owner.getUUID();
        circle.life = mode == 0 ? CAST_VISUAL_LIFE_TICKS : Math.max(1, lifeTicks);
        circle.entityData.set(MAX_LIFE, circle.life);
        int resolvedBuildTicks = mode == 0 ? CAST_VISUAL_BUILD_TICKS : buildTicks;
        circle.entityData.set(BUILD_TICKS, Math.max(1, Math.min(resolvedBuildTicks, circle.life)));
        level.addFreshEntity(circle);
        return circle;
    }

    /** 兼容旧调用名；施法确认后生成的法阵是固定世界坐标，不再跟随视角。 */
    public static SpellCircleEntity spawnCameraAnchored(Level level, Entity owner, String runes, int color, float radius) {
        if (owner == null) return null;
        Anchor anchor = resolveAnchor(level, owner);
        return spawnAt(level, owner, runes, color, radius, 0, CAST_VISUAL_LIFE_TICKS,
            CAST_VISUAL_BUILD_TICKS, anchor.position(), anchor.normal());
    }

    /** 服务端 PlayerTick END 调用：充能时跟随视线，松开或施法后立即删除预览。 */
    public static void tickChargingPreview(ServerPlayer player) {
        if (player == null) return;
        var previews = player.serverLevel().getEntitiesOfClass(SpellCircleEntity.class,
            player.getBoundingBox().inflate(64.0), e -> e.mode() == 2 && e.ownerId() == player.getId());
        if (!cn.blockforge.generated.modb22b5730.data.PrayerData.charging(player) || !PrayerData.parse(PrayerData.active(player)).contains("视")) {
            for (SpellCircleEntity preview : previews) preview.discard();
            return;
        }
        Anchor anchor = resolveAnchor(player.level(), player);
        SpellCircleEntity preview = previews.isEmpty()
            ? new SpellCircleEntity(GeneratedMod.SPELL_CIRCLE.get(), player.level()) : previews.get(0);
        preview.setPos(anchor.position().x, anchor.position().y, anchor.position().z);
        preview.entityData.set(NORMAL_X, (float) anchor.normal().x);
        preview.entityData.set(NORMAL_Y, (float) anchor.normal().y);
        preview.entityData.set(NORMAL_Z, (float) anchor.normal().z);
        preview.entityData.set(RUNES, PrayerData.active(player));
        preview.entityData.set(COLOR, SpellCaster.primaryColor(PrayerData.parse(PrayerData.active(player))));
        preview.entityData.set(RADIUS, cn.blockforge.generated.modb22b5730.spell.SpellData.fromRunes(PrayerData.parse(PrayerData.active(player))).radius());
        preview.entityData.set(MODE, 2);
        preview.entityData.set(OWNER_ID, player.getId());
        preview.ownerUuid = player.getUUID();
        preview.life = 10;
        preview.entityData.set(MAX_LIFE, 1200);
        preview.entityData.set(BUILD_TICKS, CAST_VISUAL_BUILD_TICKS);
        if (player.level().getEntity(preview.getId()) == null) player.level().addFreshEntity(preview);
    }

    public static Vec3 anchorPosition(Level level, Entity owner) { return resolveAnchor(level, owner).position(); }
    private record Anchor(Vec3 position, Vec3 normal) {}

    private static Anchor resolveAnchor(Level level, Entity owner) {
        Vec3 eye = owner.getEyePosition();
        Vec3 view = owner.getLookAngle().normalize();
        Vec3 end = eye.add(view.scale(cn.blockforge.generated.modb22b5730.spell.SpellData.fromRunes(java.util.List.of("视")).anchorDistance()));
        if (level instanceof ServerLevel server) {
            BlockHitResult hit = server.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, owner));
            if (hit.getType() != net.minecraft.world.phys.HitResult.Type.MISS) {
                Vec3 normal = Vec3.atLowerCornerOf(hit.getDirection().getNormal());
                return new Anchor(hit.getLocation().add(normal.scale(0.05)), normal);
            }
        }
        return new Anchor(end, view.scale(-1.0));
    }

    private int ownerId() { return entityData.get(OWNER_ID); }

    @Override
    protected void defineSynchedData() {
        entityData.define(RUNES, "");
        entityData.define(COLOR, 0x3D9CB8);
        entityData.define(RADIUS, 2.5f);
        entityData.define(MODE, 0);
        entityData.define(OWNER_ID, -1);
        entityData.define(MAX_LIFE, CAST_VISUAL_LIFE_TICKS);
        entityData.define(BUILD_TICKS, CAST_VISUAL_BUILD_TICKS);
        entityData.define(NORMAL_X, 0.0f);
        entityData.define(NORMAL_Y, 1.0f);
        entityData.define(NORMAL_Z, 0.0f);
    }

    public String runeString() { return entityData.get(RUNES); }
    public int color() { return entityData.get(COLOR); }
    public float radius() { return entityData.get(RADIUS); }
    public int mode() { return entityData.get(MODE); }
    public int maxLife() { return entityData.get(MAX_LIFE); }
    public int buildTicks() { return entityData.get(BUILD_TICKS); }
    public Vec3 normal() {
        Vec3 value = new Vec3(entityData.get(NORMAL_X), entityData.get(NORMAL_Y), entityData.get(NORMAL_Z));
        return value.lengthSqr() > 1.0e-8 ? value.normalize() : new Vec3(0.0, 1.0, 0.0);
    }

    public Entity findOwner() {
        if (ownerUuid != null && level() instanceof ServerLevel serverLevel) {
            Entity byUuid = serverLevel.getEntity(ownerUuid);
            if (byUuid != null) return byUuid;
        }
        return level().getEntity(entityData.get(OWNER_ID));
    }

    private final java.util.Map<java.util.UUID, Long> lastVisionHits = new java.util.HashMap<>();
    private void visionPulse() {
        Entity owner = findOwner();
        Vec3 center = position(); double radius = radius(), radiusSquared = radius * radius;
        long now = level().getGameTime();
        var hits = level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,
            new net.minecraft.world.phys.AABB(center, center).inflate(radius), entity -> {
                if (entity == owner || !entity.isAlive()) return false;
                if (lastVisionHits.containsKey(entity.getUUID()) && now - lastVisionHits.get(entity.getUUID()) < 20) return false;
                var box = entity.getBoundingBox();
                double x = net.minecraft.util.Mth.clamp(center.x, box.minX, box.maxX);
                double y = net.minecraft.util.Mth.clamp(center.y, box.minY, box.maxY);
                double z = net.minecraft.util.Mth.clamp(center.z, box.minZ, box.maxZ);
                return center.distanceToSqr(x, y, z) <= radiusSquared;
            });
        for (var hit : hits) lastVisionHits.put(hit.getUUID(), now);
        SpellCaster.applyVisionPulse(level(), owner, runeString(), center, (float)radius, hits);
    }
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (mode() == 2 && (!(findOwner() instanceof net.minecraft.world.entity.player.Player player) || !PrayerData.charging(player))) { discard(); return; }
        if (--life <= 0) { discard(); return; }
        if (mode() == 0 && PrayerData.parse(runeString()).contains("视") && tickCount % 5 == 0) visionPulse();
        if (mode() == 1 && tickCount % 20 == 0) {
            SpellCaster.applyZone(level(), findOwner(), PrayerData.parse(runeString()), position(), true);
        }
    }

    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return new ClientboundAddEntityPacket(this); }
    @Override public boolean isPickable() { return false; }
    @Override public boolean hurt(DamageSource source, float amount) { return false; }
    @Override public boolean canBeCollidedWith() { return false; }
    @Override public void push(Entity entity) { }
    @Override public void push(double x, double y, double z) { }
    @Override public boolean shouldRenderAtSqrDistance(double dist) { return dist < 256 * 256; }

    /**
     * 实体碰撞箱只有 1×0.1，而法阵贴图可达数格且可沿墙面竖起；
     * 不放大剔除盒的话，圆心一出屏幕法阵就会整体消失。
     */
    @Override
    public AABB getBoundingBoxForCulling() {
        double r = Math.max(0.5, radius()) * 1.2 + 0.3;
        return new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("prayer_runes", runeString());
        tag.putInt("prayer_color", color());
        tag.putFloat("prayer_radius", radius());
        tag.putInt("prayer_mode", mode());
        tag.putInt("prayer_life", life);
        tag.putInt("prayer_max_life", maxLife());
        tag.putInt("prayer_build_ticks", buildTicks());
        tag.putFloat("prayer_normal_x", entityData.get(NORMAL_X));
        tag.putFloat("prayer_normal_y", entityData.get(NORMAL_Y));
        tag.putFloat("prayer_normal_z", entityData.get(NORMAL_Z));
        if (ownerUuid != null) tag.putUUID("prayer_owner_uuid", ownerUuid);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(RUNES, tag.getString("prayer_runes"));
        entityData.set(COLOR, tag.getInt("prayer_color"));
        entityData.set(RADIUS, Math.max(0.1f, tag.getFloat("prayer_radius")));
        int savedMode = tag.getInt("prayer_mode");
        entityData.set(MODE, savedMode);
        int savedLife = Math.max(1, tag.contains("prayer_life") ? tag.getInt("prayer_life")
            : (savedMode == 0 ? CAST_VISUAL_LIFE_TICKS : 30));
        life = savedMode == 0 ? Math.min(CAST_VISUAL_LIFE_TICKS, savedLife) : savedLife;
        int maxLife = savedMode == 0 ? CAST_VISUAL_LIFE_TICKS
            : Math.max(life, tag.getInt("prayer_max_life"));
        entityData.set(MAX_LIFE, maxLife);
        int buildTicks = savedMode == 0 ? CAST_VISUAL_BUILD_TICKS : tag.getInt("prayer_build_ticks");
        entityData.set(BUILD_TICKS, Math.max(1, Math.min(maxLife, buildTicks)));
        entityData.set(NORMAL_X, tag.getFloat("prayer_normal_x"));
        entityData.set(NORMAL_Y, tag.contains("prayer_normal_y") ? tag.getFloat("prayer_normal_y") : 1.0f);
        entityData.set(NORMAL_Z, tag.getFloat("prayer_normal_z"));
        if (new Vec3(entityData.get(NORMAL_X), entityData.get(NORMAL_Y), entityData.get(NORMAL_Z)).lengthSqr() <= 1.0e-8) {
            entityData.set(NORMAL_X, 0.0f);
            entityData.set(NORMAL_Y, 1.0f);
            entityData.set(NORMAL_Z, 0.0f);
        }
        ownerUuid = tag.hasUUID("prayer_owner_uuid") ? tag.getUUID("prayer_owner_uuid") : null;
        entityData.set(OWNER_ID, -1);
    }
}
