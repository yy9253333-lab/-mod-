package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class VortexParticles {
    public static final DeferredRegister<ParticleType<?>> TYPES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, GeneratedMod.MOD_ID);
    public static final RegistryObject<SimpleParticleType> GLOW = TYPES.register("vortex_glow", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> SPLASH = TYPES.register("vortex_splash", () -> new SimpleParticleType(false));
    private VortexParticles() {}
}
