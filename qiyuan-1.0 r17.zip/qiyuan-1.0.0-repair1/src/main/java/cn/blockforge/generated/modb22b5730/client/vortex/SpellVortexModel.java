package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.entity.SpellVortexEntity;
import software.bernie.geckolib.model.GeoModel;
import net.minecraft.resources.ResourceLocation;

public class SpellVortexModel extends GeoModel<SpellVortexEntity> {
    @Override public ResourceLocation getModelResource(SpellVortexEntity e) { return GeneratedMod.rl("geo/spell_vortex.geo.json"); }
    @Override public ResourceLocation getTextureResource(SpellVortexEntity e) { return GeneratedMod.rl("textures/entity/vortex_fluid.png"); }
    @Override public ResourceLocation getAnimationResource(SpellVortexEntity e) { return GeneratedMod.rl("animations/spell_vortex.animation.json"); }
}
