package cn.blockforge.generated.modb22b5730.events;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.Event;

/** 非可取消事件：仅在费用已扣且实际施法成功后发布。 */
public final class CastSpellEvent extends Event {
    private final ServerPlayer player;
    public CastSpellEvent(ServerPlayer player) { this.player = player; }
    public ServerPlayer player() { return player; }
}
