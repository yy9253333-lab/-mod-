package cn.blockforge.generated.modb22b5730.talent;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
/** 父代理可在构造器调用 register(bus)；事件类也提供可独立接入的注册点。 */
@Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class TalentRegistration {
 @SubscribeEvent public static void capabilities(RegisterCapabilitiesEvent e){TalentData.register(e);}
 public static void register(net.minecraftforge.eventbus.api.IEventBus bus){TalentAttributes.ATTRIBUTES.register(bus);TalentNet.register();}
 private TalentRegistration(){}
}
