package cn.blockforge.generated.modb22b5730.spell;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity;
import cn.blockforge.generated.modb22b5730.entity.SpellOrbEntity;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.rune.RuneGroup;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import java.util.*;

/** 施法执行：把网页推演出的术式落到原版机制上（伤害、状态、传送、粒子法阵）。 */
public final class SpellCaster {

    /** 瞄准射线长度：客户端预演与服务端复核必须用同一个公式（含「门」远古符文加成）。 */
    public static double castReach(List<String> runes) {
        return runes.contains("门") ? 48.0 : 32.0;
    }

    /** 服务端复核时允许的客户端方向偏差（点积阈值，约 10°），超过即忽略客户端提示。 */
    public static final double AIM_DOT_TOLERANCE = 0.985;
    /** 服务端复核时客户端锁定实体与服务端射线终点的最大容差（格）。 */
    public static final double AIM_LOCK_TOLERANCE = 3.0;

    // ───────────────────────── 施法入口 ─────────────────────────
    public static void handleDepletion(Player player) {
        failure(player, cn.blockforge.generated.modb22b5730.events.CastFailureEvent.Cause.MANA_DEPLETED);
        PrayerData.handleDepletion(player);
    }
    public static void failure(Player player, cn.blockforge.generated.modb22b5730.events.CastFailureEvent.Cause cause) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new cn.blockforge.generated.modb22b5730.events.CastFailureEvent(player, cause));
    }
    public enum CastMode { NORMAL, VOICELESS }
    public static void tryCast(ServerPlayer player) { tryCast(player, CastMode.NORMAL); }
    public static boolean hasFocus(ServerPlayer player) {
        return player.getMainHandItem().is(GeneratedMod.PRAYER_STAFF.get())
            || player.getMainHandItem().is(GeneratedMod.PRAYER_BOOK.get())
            || player.getOffhandItem().is(GeneratedMod.PRAYER_STAFF.get())
            || player.getOffhandItem().is(GeneratedMod.PRAYER_BOOK.get());
    }
    public static void tryCast(ServerPlayer player, CastMode castMode) {
        if (!player.isAlive() || player.isSpectator()) { PrayerData.clearCharge(player); return; }
        if ((castMode == CastMode.NORMAL && !hasFocus(player))
            || (castMode == CastMode.VOICELESS && !PrayerData.noFocusUnlocked(player))) {
            player.displayClientMessage(Component.literal("施法条件未满足：普通施法需持法杖/魔导书，无法器施法需魔力上限1000与领悟100。"), true);
            failure(player, cn.blockforge.generated.modb22b5730.events.CastFailureEvent.Cause.LOCKED);
            PrayerData.clearCharge(player); PrayerNet.sync(player); return;
        }
        long requestTick = player.level().getGameTime();
        if (PrayerData.of(player).getLong("last_cast_request_tick") == requestTick
            && PrayerData.of(player).contains("last_cast_request_tick")) return;
        PrayerData.of(player).putLong("last_cast_request_tick", requestTick);
        String active = PrayerData.active(player);
        if (active.isEmpty()) {
            player.displayClientMessage(Component.literal("尚未刻印术式：右键魔导书打开法阵台，组阵后点「刻印」。"), true);
            return;
        }
        List<String> runes = PrayerData.parse(active);
        String positionError = cn.blockforge.generated.modb22b5730.array.CastPositionResolver.validate(runes);
        if (positionError != null) {
            player.displayClientMessage(Component.literal(positionError), true);
            return;
        }
        SpellStats st = SpellCalculator.calculate(runes);
        if (!st.valid) {
            player.displayClientMessage(Component.literal(st.error), true);
            return;
        }
        int duplicates = PrayerData.duplicates(player);
        float totalCost = (cn.blockforge.generated.modb22b5730.PrayerConfig.LEGACY_RUNE_COSTS.get()
            ? st.manaTotal : cn.blockforge.generated.modb22b5730.PrayerConfig.MANA_COST.get().floatValue()) * duplicates;
        long now = player.level().getGameTime();
        // 「瞬」术式无视冷却（与提示文字、图鉴说明一致）
        if (!st.flash && now < PrayerData.cooldownEnd(player)) {
            failure(player, cn.blockforge.generated.modb22b5730.events.CastFailureEvent.Cause.COOLDOWN);
            double left = (PrayerData.cooldownEnd(player) - now) / 20.0;
            player.displayClientMessage(Component.literal(String.format(Locale.ROOT, "术式冷却中 %.1fs（「瞬」可无视冷却）", left)), true);
            return;
        }
        boolean free = PrayerData.creativeUnlocked(player); // 保留创造符文原有无限魔力能力。
        float beforeMana = PrayerData.manaPool(player);
        if (!free && beforeMana + 1.0e-5F < totalCost) {
            PrayerData.setManaPool(player, 0);
            handleDepletion(player);
            PrayerNet.sync(player);
            player.displayClientMessage(Component.literal("魔力不足：需要 " + totalCost + "，剩余魔力耗尽；未生成法术、未进入冷却。"), true);
            return;
        }
        if (!free) PrayerData.spendMana(player, totalCost);
        long oldCooldown = PrayerData.cooldownEnd(player);
        boolean castSucceeded;
        try {
            castSucceeded = cast(player, runes, st);
        } catch (RuntimeException ex) {
            if (!free) PrayerData.setManaPool(player, beforeMana);
            PrayerData.setCooldownEnd(player, oldCooldown);
            PrayerData.clearCharge(player);
            PrayerNet.sync(player);
            org.apache.logging.log4j.LogManager.getLogger().error("祈愿术式执行失败，已返还魔力并恢复冷却", ex);
            player.displayClientMessage(Component.literal("术式执行失败；已返还魔力且未进入冷却。"), true);
            return;
        }
        if (!castSucceeded) {
            if (!free) PrayerData.setManaPool(player, beforeMana);
            PrayerNet.sync(player);
            player.displayClientMessage(Component.literal("前方没有安全的瞬移落点；未消耗魔力且未进入冷却。"), true);
            return;
        }
        // 「瞬」不进入冷却，也不能把已有的冷却清零（否则瞬发一次就能绕过前一个术式的冷却）
        if (!st.flash) PrayerData.setCooldownEnd(player, now + st.cooldownTicks);
        Vec3 vortexOrigin = SpellOrbEntity.launchOrigin(player);
        if (runes.contains("视")) vortexOrigin = SpellCircleEntity.anchorPosition(player.level(), player);
        try {
            cn.blockforge.generated.modb22b5730.entity.SpellVortexEntity.spawn(player.level(), GeneratedMod.SPELL_VORTEX.get(),
                player, vortexOrigin, PrayerData.capacity(player));
        } catch (RuntimeException visualFailure) {
            org.apache.logging.log4j.LogManager.getLogger().warn("漩涡视觉生成失败，保留已成功结算的法术", visualFailure);
        }
        PrayerData.rememberRecent(player, st.runeString);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new cn.blockforge.generated.modb22b5730.events.CastSpellEvent(player));
        PrayerData.clearCharge(player);
        if (!free && PrayerData.manaPool(player) <= 0) handleDepletion(player);
        PrayerNet.sync(player);
    }

    // ───────────────────────── 瞄准复核（服务端权威） ─────────────────────────
    /** 准星射线的复核结果：最终命中点 + 直接命中实体。 */
    public record AimResolution(Vec3 pos, LivingEntity direct, boolean clientLocked, Vec3 normal) {}

    /**
     * 用与服务端相同公式重算准星射线，并复核客户端预演：
     * ① 服务端自行 pick 一次（权威基线，防修改客户端）；
     * ② 若客户端在容差内声称锁定了某实体，且服务端射线同样能扫到它，
     *    则把命中"锁定"到该实体（预演什么就打中什么，消除延迟感）；
     * ③ 客户端数据过期/偏差过大时完全回退服务端射线。
     */
    public static AimResolution resolveAim(ServerPlayer player, List<String> runes) {
        double reach = castReach(runes);
        HitResult hit = traceAim(player, reach);
        Vec3 serverPos = hit.getLocation();
        Vec3 serverNormal = impactNormal(player, hit);
        LivingEntity direct = hit.getType() == HitResult.Type.ENTITY && hit instanceof EntityHitResult ehr
            && ehr.getEntity() instanceof LivingEntity le ? le : null;

        AimStore.Aim aim = AimStore.getValid(player.getUUID(), player.level().getGameTime());
        if (aim != null && player.getLookAngle().dot(aim.dir()) >= AIM_DOT_TOLERANCE) {
            // 服务端射线已经打中实体：与客户端所报一致时直接确认锁定。
            if (direct != null && direct.getId() == aim.targetId()) {
                // 使用射线与实体碰撞箱的真实交点，不能把法阵强行移到实体中心。
                return new AimResolution(serverPos, direct, true, serverNormal);
            }
            // 服务端射线打中的是方块/空：核对客户端锁定的实体是否确实位于这条射线上
            // （用相同视线向量算垂距），在容差内且视线可达才把命中锁定到它——
            // 这样客户端预演看到的锁定目标，服务端重算后依然成立，消除网络旋转延迟的偏差。
            if (direct == null) {
                net.minecraft.world.entity.Entity hinted = player.level().getEntity(aim.targetId());
                if (hinted instanceof LivingEntity hl && hl != player && hl.isAlive() && !hl.isInvisible()) {
                    Vec3 eye = player.getEyePosition();
                    Vec3 look = player.getLookAngle().normalize();
                    Vec3 end = eye.add(look.scale(reach));
                    var clipped = hl.getBoundingBox().inflate(hl.getPickRadius()).clip(eye, end);
                    if (clipped.isPresent()) {
                        var obstacle = player.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
                        double wallDist = obstacle.getType() == HitResult.Type.BLOCK ? eye.distanceToSqr(obstacle.getLocation()) : reach * reach;
                        if (eye.distanceToSqr(clipped.get()) < wallDist)
                            return new AimResolution(clipped.get(), hl, true, player.getLookAngle().scale(-1).normalize());
                    }
                }
            }
        }
        return new AimResolution(serverPos, direct, false, serverNormal);
    }

    /** 法阵朝向命中面：方块用真实面法线，实体或空中射线面向施法者。 */
    private static Vec3 impactNormal(Entity source, HitResult hit) {
        if (hit instanceof BlockHitResult block && hit.getType() == HitResult.Type.BLOCK) {
            Direction face = block.getDirection();
            return new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
        }
        return source.getLookAngle().scale(-1).normalize();
    }

    private static boolean cast(ServerPlayer player, List<String> runes, SpellStats st) {
        String runeString = st.runeString;
        int color = primaryColor(runes);
        List<String> targets = group(runes, RuneGroup.TARGET);
        List<String> effects = group(runes, RuneGroup.EFFECT);
        List<String> forms = group(runes, RuneGroup.FORM);
        List<String> ancient = group(runes, RuneGroup.ANCIENT);

        // 符文驱动分派表决定施法方式（术式类型分派系统）。
        CastDispatch.Mode mode = CastDispatch.decide(targets, effects, forms);

        // 先确认瞬移落点安全，再扣费和施加其他效果；不能在被墙拦截后回退穿墙。
        Vec3 blinkTarget = mode == CastDispatch.Mode.BLINK
            ? findBlinkTarget(player, ancient.contains("门") ? 32 : 16) : null;
        if (mode == CastDispatch.Mode.BLINK && blinkTarget == null) return false;

        // 自身术式的法阵固定在施法时脚下；视线系法阵稍后固定在服务端射线落点。
        if (mode == CastDispatch.Mode.SELF_GROUND) {
            if (runes.contains("视")) SpellCircleEntity.spawnCameraAnchored(player.level(), player, runeString, color, castCircleRadius(runes));
            else SpellCircleEntity.spawn(player.level(), player, runeString, color, castCircleRadius(runes), 0, 30);
        }
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
            SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 0.7f, st.flash ? 1.4f : 1.0f);

        applyResistances(player, runes);
        // 「己 + 雷」是自我增益：每枚雷属性符文提升一级抗性，持续 10 秒。
        if (targets.contains("己") && runes.contains("雷")) {
            int lightningCount = (int) runes.stream().filter("雷"::equals).count();
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, Math.max(0, lightningCount - 1), false, true, true));
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.45f, 1.5f);
        }

        if (mode == CastDispatch.Mode.BLINK) {
            if (runes.contains("视")) SpellCircleEntity.spawnCameraAnchored(player.level(), player, runeString, color, castCircleRadius(runes));
            else SpellCircleEntity.spawnAt(player.level(), player, runeString, color, castCircleRadius(runes), 0, 30, 12, player.position());
            player.teleportTo(blinkTarget.x, blinkTarget.y, blinkTarget.z);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.6f, 1.3f);
            return true;
        }

        if (mode == CastDispatch.Mode.SELF_GROUND) {
            applyImpact(player.level(), player, runeString, player.position(), player);
            return true;
        }

        // 准星射线：客户端预演，服务端用相同射线公式重算并锁定命中位置。
        AimResolution res = resolveAim(player, runes);
        Vec3 aimPos = res.pos();
        LivingEntity direct = res.direct();
        // 投射型术式在发射阶段不生成准星/视线法阵，避免法阵看起来黏在玩家视线前方；
        // 命中后由 SpellOrbEntity 调用 spawnProjectileImpactCircle 在真实命中位置生成。
        if (runes.contains("视")) {
            SpellCircleEntity.spawnCameraAnchored(player.level(), player, runeString, color, castCircleRadius(runes));
        } else if (mode != CastDispatch.Mode.PROJECTILE) {
            SpellCircleEntity.spawnAt(player.level(), player, runeString, color, castCircleRadius(runes), 0, 30, 12, aimPos, res.normal());
        }

        if (mode == CastDispatch.Mode.PROJECTILE) {
            Vec3 target = direct != null ? direct.getBoundingBox().getCenter() : aimPos;
            int count = Math.max(runes.contains("裂") ? 3 : 1, PrayerData.duplicates(player));
            int spawned = 0;
            for (int i = 0; i < count; i++) {
                if (SpellOrbEntity.launchTowards(player.level(), player, runes, target, color, i, count) != null) spawned++;
            }
            if (spawned == 0) return false;
        } else {
            // TOUCH / POINT：命中点直接结算（applyImpact 自带命中点粒子环特效）。
            applyImpact(player.level(), player, runeString, aimPos, direct);
        }
        return true;
    }

    /**
     * 投射物真正命中后，在命中点生成一次世界坐标法阵（位置与朝向在服务端确定，之后固定）。
     * 发射阶段不生成法阵，避免法阵看起来黏在玩家视线前方。
     */
    public static void spawnProjectileImpactCircle(Level level, Entity owner, String runeString, Vec3 pos, Vec3 normal) {
        if (!(level instanceof ServerLevel) || pos == null) return;
        List<String> runes = PrayerData.parse(runeString);
        if (runes.isEmpty() || runes.contains("视")) return;
        SpellCircleEntity.spawnAt(level, owner, runeString, primaryColor(runes), castCircleRadius(runes), 0,
            SpellCircleEntity.CAST_VISUAL_LIFE_TICKS, SpellCircleEntity.CAST_VISUAL_BUILD_TICKS, pos, normal);
    }

    // ───────────────────────── 命中结算 ─────────────────────────
    public static void applyImpact(Level level, Entity owner, String runeString, Vec3 pos, Entity direct) {
        applyImpact(level, owner, runeString, SpellCalculator.calculate(PrayerData.parse(runeString)), pos, direct, false, null);
    }

    public static void applyZone(Level level, Entity owner, List<String> runes, Vec3 pos, boolean repeat) {
        applyImpact(level, owner, String.join("·", runes), SpellCalculator.calculate(runes), pos, null, repeat, null);
    }

    public static void applyProjectileImpact(Level level, SpellOrbEntity projectile, Vec3 pos, Entity directHit) {
        applyImpact(level, projectile.getOwner(), projectile.runeString(),
            SpellCalculator.calculate(PrayerData.parse(projectile.runeString())), pos, directHit, false, projectile);
    }
    public static void applyVisionPulse(Level level, Entity owner, String runes, Vec3 pos, float radius, List<LivingEntity> hits) {
        if (hits.isEmpty()) return;
        applyImpact(level, owner, runes, SpellCalculator.calculate(PrayerData.parse(runes)), pos, null, true, null, hits, radius);
    }
    private static void applyImpact(Level level, Entity owner, String runeString, SpellStats st, Vec3 pos, Entity directHit, boolean repeat, Entity damageSource) {
        applyImpact(level, owner, runeString, st, pos, directHit, repeat, damageSource, null, 0);
    }
    private static void applyImpact(Level level, Entity owner, String runeString, SpellStats st, Vec3 pos, Entity directHit, boolean repeat, Entity damageSource, List<LivingEntity> fixedHits, double fixedRadius) {
        if (!(level instanceof ServerLevel sl)) return;
        List<String> runes = PrayerData.parse(runeString);
        List<String> targets = group(runes, RuneGroup.TARGET);
        List<String> elements = group(runes, RuneGroup.ELEMENT);
        List<String> ancient = group(runes, RuneGroup.ANCIENT);
        List<String> effects = group(runes, RuneGroup.EFFECT);
        List<String> forms = group(runes, RuneGroup.FORM);
        // 「土 + 创」只在首次命中时生成方块；持续区域每次重复结算不会反复堆方块。
        // 「创」也可调用原版生物进行限时召唤；同样只在首次命中时触发，避免持续场每 tick 召唤。
        if (!repeat) {
            EarthSpellBlocks.create(sl, runes, st, pos);
            int summoned = SummonService.summon(sl, owner, runes, st, pos);
            if (summoned > 0 && owner instanceof Player player) {
                player.displayClientMessage(Component.literal("召唤成功：" + summoned + " 个临时召唤物"), true);
            }
        }
        // 「壁」形态代表平面屏障：在实际命中点生成 5×3 的限时、不可破坏玻璃墙。
        // 仅占用空气方块；每个方块使用原版计划刻，服务器重载后仍能按时清除。
        if (!repeat && forms.contains("壁")) {
            createTemporaryWall(sl, owner, runes, pos);
        }
        Player caster = owner instanceof Player p ? p : null;
        double radius = fixedRadius > 0 ? fixedRadius : radius(runes, st);
        int color = primaryColor(runes);
        spawnRing(sl, pos, color, radius);
        // 普通目标的雷属性施法生成一道纯视觉原版闪电；不额外制造火焰或重复伤害。
        if (!repeat && elements.contains("雷") && !targets.contains("己")) {
            net.minecraft.world.entity.LightningBolt bolt = net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(sl);
            if (bolt != null) {
                bolt.moveTo(pos.x, pos.y, pos.z);
                bolt.setVisualOnly(true);
                sl.addFreshEntity(bolt);
            }
        }

        boolean area = targets.contains("域") || targets.contains("群") || forms.contains("雨") || forms.contains("雾") || forms.contains("潮") || forms.contains("涡");
        List<LivingEntity> hits;
        if (fixedHits != null) {
            hits = fixedHits;
        } else if (!area && directHit instanceof LivingEntity le) {
            hits = List.of(le);
        } else {
            double radiusSqr = radius * radius;
            hits = sl.getEntitiesOfClass(LivingEntity.class, new AABB(pos.x - radius, pos.y - radius, pos.z - radius, pos.x + radius, pos.y + radius + 1, pos.z + radius),
                e -> e != owner && !SummonService.isOwnedBy(e, owner) && e.isAlive() && sphereIntersects(e, pos, radiusSqr));
        }

        // 伤害
        if (st.hasDamage && caster != null) {
            float dmg = (float) (st.damage * (1 + st.accuracyBonus * 0.5) * (repeat ? 0.35 : 1) * (runes.contains("裂") ? 0.8 : 1));
            int maxTargets = targets.contains("群") ? 6 : 99;
            int done = 0;
            for (LivingEntity e : hits) {
                if (done >= maxTargets) break;
                if (targets.contains("己") && e == caster) continue;
                dealDamage(sl, caster, e, st, dmg, elements, damageSource);
                done++;
            }
            sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.5f + Math.min(0.5f, st.damage / 500f), 1.5f);
        }

        // 治疗与净化（对我方）
        if (st.healing > 0 || effects.contains("解")) {
            List<LivingEntity> allies = fixedHits != null ? fixedHits.stream().filter(e -> e instanceof Player).toList() : targets.contains("己") && caster != null ? List.of(caster)
                : sl.getEntitiesOfClass(LivingEntity.class, new AABB(pos.x - radius, pos.y - radius, pos.z - radius, pos.x + radius, pos.y + radius + 1, pos.z + radius),
                    e -> (e == caster || (e instanceof Player && !targets.contains("灵"))) && sphereIntersects(e, pos, radius * radius));
            if (fixedHits == null && allies.isEmpty() && caster != null) allies = List.of(caster);
            for (LivingEntity a : allies) {
                if (st.healing > 0) a.heal((float) Math.min(20, st.healing / 10.0 * (repeat ? 0.4 : 1)));
                if (effects.contains("解")) {
                    for (MobEffectInstance me : new ArrayList<>(a.getActiveEffects()))
                        if (!me.getEffect().isBeneficial()) a.removeEffect(me.getEffect());
                }
            }
            sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8f, 0.9f);
        }

        int ctrlDur = ancient.contains("时") ? 2 : 1;
        for (LivingEntity e : hits) {
            if (e == caster) continue;
            // 控制
            if (effects.contains("缚")) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, Math.min(600, (60 + st.control * 2)) * ctrlDur, 4));
            if (effects.contains("封")) {
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200 * ctrlDur, 1));
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 200 * ctrlDur, 1));
            }
            if (effects.contains("幻")) {
                e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100 * ctrlDur, 0));
                e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100 * ctrlDur, 0));
            }
            if (effects.contains("真")) e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
            if (effects.contains("蚀")) e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
            // 元素附加
            if (elements.contains("火")) e.setSecondsOnFire(3);
            if (elements.contains("冰")) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            if (elements.contains("暗")) e.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 0));
            if (elements.contains("水")) e.extinguishFire();
            // 位移
            if (effects.contains("引")) {
                Vec3 v = pos.subtract(e.position()).normalize().multiply(0.9, 0.5, 0.9);
                e.setDeltaMovement(v); e.hurtMarked = true;
            }
            if (effects.contains("斥")) {
                Vec3 v = e.position().subtract(pos).normalize().multiply(1.4, 0.7, 1.4);
                e.setDeltaMovement(v); e.hurtMarked = true;
            }
        }

        // 远古符文的额外表现
        if (ancient.contains("忆") && caster != null) {
            caster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0));
            caster.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 200, 0));
        }
        if (ancient.contains("魂")) for (LivingEntity e : hits) e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));

        // 持续区域：首次命中时生成法阵实体
        if (!repeat && st.duration > 0 && owner != null && forms.stream().anyMatch(f -> List.of("雾", "雨", "环", "网", "涡").contains(f))) {
            int durationTicks = Math.max(20, st.duration * 20 * ctrlDur);
            SpellCircleEntity.spawnAt(sl, owner, runeString, color, (float) radius, 1, durationTicks,
                Math.min(20, durationTicks), pos);
        }
    }

    private static void createTemporaryWall(ServerLevel level, Entity owner, List<String> runes, Vec3 impact) {
        if (level == null || impact == null) return;
        BlockPos center = BlockPos.containing(impact.x, impact.y, impact.z);
        // 让屏障平面垂直于施法者的水平朝向；接近正上/正下瞄准时采用稳定的 X 轴墙面。
        Vec3 look = owner == null ? Vec3.ZERO : owner.getLookAngle();
        boolean spanX = Math.abs(look.x) <= Math.abs(look.z);
        int durationTicks = 15 * 20;
        long sustainRunes = runes.stream().filter("续"::equals).count();
        durationTicks += (int) Math.min(1200L, sustainRunes * 15L * 20L);
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        BlockPos belowCenter = center.below();
        boolean onGround = level.hasChunkAt(belowCenter)
            && level.getBlockState(center).isAir()
            && level.getBlockState(belowCenter).isSolidRender(level, belowCenter);
        int startY = onGround ? center.getY() : center.getY() - 1;
        for (int width = -2; width <= 2; width++) {
            for (int height = 0; height < 3; height++) {
                int x = center.getX() + (spanX ? width : 0);
                int z = center.getZ() + (spanX ? 0 : width);
                cursor.set(x, startY + height, z);
                if (!level.hasChunkAt(cursor)) continue;
                if (!level.getBlockState(cursor).isAir() || level.getBlockEntity(cursor) != null) continue;
                if (level.setBlock(cursor, GeneratedMod.TEMPORARY_GLASS.get().defaultBlockState(), Block.UPDATE_ALL)) {
                    level.scheduleTick(cursor, GeneratedMod.TEMPORARY_GLASS.get(), durationTicks);
                }
            }
        }
    }

    private static void dealDamage(ServerLevel level, Player caster, LivingEntity target, SpellStats st, float dmg, List<String> elements, Entity directSource) {
        var registry = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE);
        Holder<DamageType> magic = registry.getHolderOrThrow(DamageTypes.MAGIC);
        Holder<DamageType> physical = registry.getHolderOrThrow(DamageTypes.PLAYER_ATTACK);
        float amount = dmg;
        if (elements.contains("光") && target instanceof Monster) amount *= 1.25f;
        if (elements.contains("雷")) amount *= 1.1f;
        switch (st.damageType) {
            case "physical" -> target.hurt(new DamageSource(physical, directSource == null ? caster : directSource, caster), amount);
            case "mixed" -> {
                target.hurt(new DamageSource(magic, directSource == null ? caster : directSource, caster), amount);
            }
            default -> target.hurt(new DamageSource(magic, directSource == null ? caster : directSource, caster), amount);
        }
        if (elements.contains("雷")) level.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + 1, target.getZ(), 10, 0.4, 0.6, 0.4, 0.05);
    }

    private static final Map<String, MobEffectInstance[]> RESIST_MAP = resistMap();

    private static Map<String, MobEffectInstance[]> resistMap() {
        Map<String, MobEffectInstance[]> map = new HashMap<>();
        map.put("物抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0)});
        map.put("法抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.ABSORPTION, 200, 1)});
        map.put("火抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0)});
        map.put("水抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.WATER_BREATHING, 600, 0)});
        map.put("风抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0)});
        map.put("土抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0)});
        map.put("雷抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0)});
        map.put("冰抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0)});
        map.put("木抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.REGENERATION, 100, 0)});
        map.put("金抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1)});
        map.put("光抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0)});
        map.put("暗抗", new MobEffectInstance[]{new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0)});
        return map;
    }

    private static void applyResistances(Player caster, List<String> runes) {
        for (String r : runes) {
            MobEffectInstance[] insts = RESIST_MAP.get(r);
            if (insts != null) for (MobEffectInstance i : insts) caster.addEffect(new MobEffectInstance(i));
        }
    }

    private static Vec3 findBlinkTarget(Player player, int maxDist) {
        Vec3 dir = player.getLookAngle().normalize();
        Vec3 eye = player.getEyePosition();
        Vec3 feet = player.position();
        double eyeOffset = player.getEyeY() - player.getY();
        AABB original = player.getBoundingBox();
        Vec3 lastSafe = null;
        for (double d = 0.5; d <= maxDist; d += 0.5) {
            Vec3 eyeTarget = eye.add(dir.scale(d));
            Vec3 feetTarget = eyeTarget.add(0, -eyeOffset, 0);
            AABB candidate = original.move(feetTarget.subtract(feet));
            if (!player.level().noCollision(player, candidate)) break;
            if (d >= 3.0) lastSafe = feetTarget;
        }
        return lastSafe;
    }

    // ───────────────────────── 表现 ─────────────────────────
    public static DustParticleOptions dust(int color, float scale) {
        return new DustParticleOptions(new Vector3f(((color >> 16) & 0xFF) / 255f, ((color >> 8) & 0xFF) / 255f, (color & 0xFF) / 255f), scale);
    }

    private static void spawnRing(ServerLevel level, Vec3 pos, int color, double radius) {
        ParticleOptions dust = dust(color, 1.1f);
        int n = 24;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            level.sendParticles(dust, pos.x + Math.cos(a) * radius, pos.y + 0.1, pos.z + Math.sin(a) * radius, 1, 0, 0.02, 0, 0);
        }
        level.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y + 0.3, pos.z, 6, radius * 0.4, 0.2, radius * 0.4, 0.01);
    }

    public static int primaryColor(List<String> runes) {
        for (String r : runes) {
            Runes.Def d = Runes.get(r);
            if (d != null && d.group == RuneGroup.ELEMENT) return d.color;
        }
        for (String r : runes) {
            Runes.Def d = Runes.get(r);
            if (d != null) return d.color;
        }
        return 0x3D9CB8;
    }

    private static double radius(List<String> runes, SpellStats st) {
        double r = 2.5;
        if (runes.contains("域")) r += 2.0;
        if (runes.contains("群")) r += 1.5;
        if (runes.contains("雨")) r += 1.5;
        if (runes.contains("雾")) r += 2.0;
        if (runes.contains("潮")) r += 2.0;
        if (runes.contains("环")) r += 1.0;
        if (runes.contains("界")) r *= 1.3;
        if (runes.contains("微")) r *= 0.6;
        if (runes.contains("倍")) r *= 1.4;
        // 「域」既保留其原有基础范围加成，再将最终法术半径扩大到两倍；
        // 所有依赖 radius 的范围判定、粒子边界和持续区域因此同步扩大。
        if (runes.contains("域")) r *= 2.0;
        return r;
    }

    /** 普通施法法阵以 1.6 格为基准；符文域将视觉直径同步扩大到两倍。 */
    private static float castCircleRadius(List<String> runes) {
        if (runes.contains("视")) return SpellData.fromRunes(runes).radius();
        return runes.contains("域") ? 3.0f : 1.5f;
    }

    /** 统一的实体+方块射线：实体必须位于首个方块命中之前，服务端与客户端共用。 */
    public static HitResult traceAim(Entity source, double reach) {
        Vec3 start = source.getEyePosition();
        Vec3 direction = source.getLookAngle().normalize();
        Vec3 end = start.add(direction.scale(reach));
        BlockHitResult block = source.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
            ClipContext.Fluid.NONE, source));
        double maxDistanceSqr = block.getType() == HitResult.Type.BLOCK
            ? start.distanceToSqr(block.getLocation()) : reach * reach;
        AABB scan = source.getBoundingBox().expandTowards(direction.scale(reach)).inflate(1.0);
        LivingEntity nearest = null;
        Vec3 nearestPos = null;
        double nearestDistanceSqr = maxDistanceSqr;
        for (LivingEntity candidate : source.level().getEntitiesOfClass(LivingEntity.class, scan,
            e -> e != source && e.isAlive() && !e.isSpectator() && !e.isInvisible() && e.isPickable())) {
            var intersection = candidate.getBoundingBox().inflate(candidate.getPickRadius()).clip(start, end);
            if (intersection.isEmpty()) continue;
            double distanceSqr = start.distanceToSqr(intersection.get());
            if (distanceSqr < nearestDistanceSqr) {
                nearestDistanceSqr = distanceSqr;
                nearest = candidate;
                nearestPos = intersection.get();
            }
        }
        if (nearest != null) return new EntityHitResult(nearest, nearestPos);
        if (block.getType() == HitResult.Type.BLOCK) return block;
        return BlockHitResult.miss(end, Direction.getNearest(direction.x, direction.y, direction.z), BlockPos.containing(end));
    }

    public static boolean sphereIntersects(Entity entity, Vec3 center, double radiusSqr) {
        AABB b = entity.getBoundingBox();
        return Ballistics.boxDistanceSquared(center.x, center.y, center.z, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ) <= radiusSqr;
    }
    private static List<String> group(List<String> runes, RuneGroup g) {
        List<String> out = new ArrayList<>();
        if (runes == null) return out;
        for (String r : runes) { Runes.Def d = Runes.get(r); if (d != null && d.group == g) out.add(r); }
        return out;
    }

    private SpellCaster() {}
}
