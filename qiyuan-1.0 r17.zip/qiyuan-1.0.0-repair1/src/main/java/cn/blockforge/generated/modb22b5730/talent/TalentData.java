package cn.blockforge.generated.modb22b5730.talent;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.Nullable;
import net.minecraft.core.Direction;
import java.util.*;

/** Persistent unlocked talent ids; talent points remain owned by PrayerData. */
public final class TalentData implements INBTSerializable<CompoundTag> {
    public static final Capability<TalentData> CAP = CapabilityManager.get(new CapabilityToken<>() {});
    private static final int MAX_NODES = 512;
    private final Set<String> unlocked = new LinkedHashSet<>();
    private TalentData() {}
    public static TalentData of(Player p) { return p.getCapability(CAP).orElseGet(TalentData::new); }
    public Set<String> unlocked() { return Collections.unmodifiableSet(unlocked); }
    public boolean has(String id) { return unlocked.contains(id); }
    public void unlock(String id) { if (unlocked.size() < MAX_NODES) unlocked.add(id); }
    public void clear() { unlocked.clear(); }
    public static void register(RegisterCapabilitiesEvent e) { e.register(TalentData.class); }
    @Override public CompoundTag serializeNBT() { CompoundTag out=new CompoundTag(); ListTag l=new ListTag(); for(String s:unlocked) l.add(StringTag.valueOf(s)); out.put("unlocked",l); return out; }
    @Override public void deserializeNBT(CompoundTag in) { unlocked.clear(); ListTag l=in.getList("unlocked", Tag.TAG_STRING); for(int i=0;i<l.size() && unlocked.size()<MAX_NODES;i++) { String s=l.getString(i); if (s.length()<=128 && s.matches("[a-z0-9_:.\\-]{1,128}")) unlocked.add(s); } }
    public static final class Provider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
        private final TalentData data=new TalentData(); private final LazyOptional<TalentData> opt=LazyOptional.of(()->data);
        public Provider() { }
        public void invalidate() { opt.invalidate(); }
        @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, @Nullable Direction side) { return cap==CAP?opt.cast():LazyOptional.empty(); }
        @Override public CompoundTag serializeNBT(){return data.serializeNBT();}
        @Override public void deserializeNBT(CompoundTag n){data.deserializeNBT(n);}
    }
}
