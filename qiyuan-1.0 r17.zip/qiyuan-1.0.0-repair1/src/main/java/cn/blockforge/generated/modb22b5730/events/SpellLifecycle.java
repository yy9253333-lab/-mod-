package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class SpellLifecycle {
    @SubscribeEvent public static void success(CastSpellEvent event) { PrayerData.successfulCast(event.player()); }
    @SubscribeEvent public static void failure(CastFailureEvent event) {
        if (event.cause() == CastFailureEvent.Cause.MANA_DEPLETED) PrayerData.clearCharge(event.player());
    }
    private SpellLifecycle() {}
}
