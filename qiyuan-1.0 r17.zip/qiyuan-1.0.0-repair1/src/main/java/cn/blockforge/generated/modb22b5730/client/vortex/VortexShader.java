package cn.blockforge.generated.modb22b5730.client.vortex;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 注册独立着色器；当前渲染采用无帧缓冲拷贝的安全fallback，不假称实现屏幕折射。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class VortexShader {
    public static ShaderInstance shader;
    @SubscribeEvent public static void register(RegisterShadersEvent event) {
        shader = null;
        try {
            event.registerShader(new ShaderInstance(event.getResourceProvider(), GeneratedMod.rl("spell_vortex"), DefaultVertexFormat.NEW_ENTITY), loaded -> shader = loaded);
        } catch (java.io.IOException | RuntimeException error) {
            org.apache.logging.log4j.LogManager.getLogger().warn("祈愿漩涡shader加载失败，继续使用半透明发光回退", error);
        }
    }
    private VortexShader() {}
}
