#version 150
uniform sampler2D Sampler0; uniform vec4 GlowColor; uniform float RefractStrength;
in vec4 vertexColor; in vec2 texCoord0; out vec4 fragColor;
void main(){ vec4 tex=texture(Sampler0,texCoord0); fragColor=tex*vertexColor*GlowColor; }
