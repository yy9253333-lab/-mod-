#version 150
in vec3 Position; in vec4 Color; in vec2 UV0; in ivec2 UV2; in vec3 Normal;
out vec4 vertexColor; out vec2 texCoord0;
uniform mat4 ModelViewMat; uniform mat4 ProjMat; uniform float GameTime; uniform vec2 ScrollSpeed;
void main(){ gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0); vertexColor=Color; texCoord0=UV0+GameTime*ScrollSpeed; }
