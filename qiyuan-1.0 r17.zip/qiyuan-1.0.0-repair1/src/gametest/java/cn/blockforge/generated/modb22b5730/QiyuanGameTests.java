package cn.blockforge.generated.modb22b5730;

import cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity;
import cn.blockforge.generated.modb22b5730.entity.SpellOrbEntity;
import cn.blockforge.generated.modb22b5730.entity.SpellVortexEntity;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Small, server-side regression tests for the entities whose APIs are stable in 1.20.1. */
@GameTestHolder("mod_b22b5730")
@PrefixGameTestTemplate(false)
public final class QiyuanGameTests {
    private QiyuanGameTests() {}

    @GameTest(template = "empty", timeoutTicks = 40)
    public static void circleIsAnchoredAndExpires(GameTestHelper helper) {
        Vec3 fixed = Vec3.atLowerCornerOf(helper.absolutePos(new net.minecraft.core.BlockPos(4, 2, 4))).add(0.5, 0, 0.5);
        SpellCircleEntity circle = SpellCircleEntity.spawnAt(
            helper.getLevel(), null, "", 0x3D9CB8, 2.0f, 0, 24, 10, fixed, new Vec3(0, 0, 1));
        helper.assertTrue(circle.position().distanceToSqr(fixed) < 1.0e-8, "circle moved at spawn");
        helper.assertTrue(circle.mode() == 0 && circle.maxLife() == 24, "wrong visual-circle mode/lifetime");
        helper.assertTrue(circle.normal().distanceToSqr(new Vec3(0, 0, 1)) < 1.0e-6, "wrong circle normal");
        helper.runAtTickTime(23, () -> helper.assertTrue(!circle.isRemoved(), "circle discarded before 24 ticks"));
        helper.runAtTickTime(24, () -> {
            helper.assertTrue(circle.isRemoved(), "mode 0 circle survived 24 ticks");
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 80)
    public static void vortexExpiresAfterSixtyTicks(GameTestHelper helper) {
        SpellVortexEntity vortex = new SpellVortexEntity(GeneratedMod.SPELL_VORTEX.get(), helper.getLevel());
        vortex.setPos(Vec3.atLowerCornerOf(helper.absolutePos(new net.minecraft.core.BlockPos(2, 2, 2))));
        vortex.setManaSnapshot(2000);
        vortex.setLifetime(60);
        helper.getLevel().addFreshEntity(vortex);
        helper.assertTrue(vortex.manaSnapshot() == 2000, "mana snapshot was not retained");
        helper.runAtTickTime(59, () -> helper.assertTrue(!vortex.isRemoved(), "vortex expired early"));
        helper.runAtTickTime(60, () -> {
            helper.assertTrue(vortex.isRemoved(), "vortex did not expire at 60 ticks");
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 12)
    public static void orbUsesFortyFiveDegreeMotionAndGravity(GameTestHelper helper) {
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), helper.getLevel());
        orb.setPos(Vec3.atLowerCornerOf(helper.absolutePos(new net.minecraft.core.BlockPos(2, 2, 2))));
        orb.shoot(1, 1, 0, 1.0f, 0.0f);
        helper.getLevel().addFreshEntity(orb);
        double diagonal = Math.sqrt(0.5);
        Vec3 before = orb.getDeltaMovement();
        helper.assertTrue(Math.abs(before.x - diagonal) < 1.0e-5 && Math.abs(before.y - diagonal) < 1.0e-5,
            "orb was not launched at 45 degrees: " + before);
        helper.runAtTickTime(1, () -> {
            Vec3 after = orb.getDeltaMovement();
            helper.assertTrue(Math.abs(after.y - (diagonal - 0.03)) < 1.0e-5,
                "orb gravity is not 0.03 per tick: " + after.y);
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 12)
    public static void projectileStopsAtWall(GameTestHelper helper) {
        var base = helper.absolutePos(new net.minecraft.core.BlockPos(2, 2, 2));
        helper.getLevel().setBlockAndUpdate(base.offset(2, 0, 0), Blocks.STONE.defaultBlockState());
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), helper.getLevel());
        orb.setPos(base.getX() + 0.5, base.getY() + 0.5, base.getZ() + 0.5);
        orb.setDeltaMovement(1.0, 0.0, 0.0);
        helper.getLevel().addFreshEntity(orb);
        helper.runAtTickTime(2, () -> {
            helper.assertTrue(orb.isRemoved(), "orb continued through a colliding wall");
            helper.succeed();
        });
    }

    private static net.minecraftforge.common.util.FakePlayer freshCaster(GameTestHelper helper, String name) {
        var profile = new com.mojang.authlib.GameProfile(java.util.UUID.nameUUIDFromBytes(name.getBytes(java.nio.charset.StandardCharsets.UTF_8)), name);
        var player = net.minecraftforge.common.util.FakePlayerFactory.get(helper.getLevel(), profile);
        player.setPos(Vec3.atLowerCornerOf(helper.absolutePos(new net.minecraft.core.BlockPos(4, 2, 4))));
        cn.blockforge.generated.modb22b5730.data.PrayerData.of(player).getAllKeys().stream().toList().forEach(key -> player.getPersistentData().getCompound("prayer").remove(key));
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, new net.minecraft.world.item.ItemStack(GeneratedMod.PRAYER_STAFF.get()));
        cn.blockforge.generated.modb22b5730.data.PrayerData.of(player).putString("active", "己·木·愈·环");
        return player;
    }

    @GameTest(template = "empty", timeoutTicks = 15)
    public static void authoritativeManaGrowthAndCooldown(GameTestHelper helper) {
        var player = freshCaster(helper, "[QiyuanMana]");
        var data = cn.blockforge.generated.modb22b5730.data.PrayerData.of(player);
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.capacity(player) == 200, "fresh capacity is not 200");
        helper.assertTrue(Math.abs(cn.blockforge.generated.modb22b5730.data.PrayerData.manaPool(player) - 200) < 1.0e-4, "fresh mana is not 200");
        cn.blockforge.generated.modb22b5730.spell.SpellCaster.tryCast(player);
        helper.assertTrue(Math.abs(cn.blockforge.generated.modb22b5730.data.PrayerData.manaPool(player) - 190) < 1.0e-4, "one successful spell did not spend exactly 10 mana");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.capacity(player) == 205, "successful cast event did not add 5 capacity");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.proficiency(player) == 1, "successful cast event did not add one proficiency");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.cooldownEnd(player) > helper.getLevel().getGameTime(), "successful spell did not begin cooldown");
        helper.runAtTickTime(1, () -> {
            cn.blockforge.generated.modb22b5730.spell.SpellCaster.tryCast(player);
            helper.assertTrue(Math.abs(cn.blockforge.generated.modb22b5730.data.PrayerData.manaPool(player) - 190) < 1.0e-4, "cooldown rejection spent mana");
            helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.proficiency(player) == 1, "cooldown rejection granted growth");
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 10)
    public static void insufficientManaRejectsWithoutGrowthOrCooldown(GameTestHelper helper) {
        var player = freshCaster(helper, "[QiyuanLowMana]");
        cn.blockforge.generated.modb22b5730.data.PrayerData.setManaPool(player, 9);
        cn.blockforge.generated.modb22b5730.spell.SpellCaster.tryCast(player);
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.manaPool(player) == 0, "failed cast did not deplete mana");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.capacity(player) == 200, "failed cast grew capacity");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.proficiency(player) == 0, "failed cast grew proficiency");
        helper.assertTrue(cn.blockforge.generated.modb22b5730.data.PrayerData.cooldownEnd(player) == 0, "failed cast began cooldown");
        var nausea = player.getEffect(net.minecraft.world.effect.MobEffects.CONFUSION);
        helper.assertTrue(nausea != null && nausea.getAmplifier() == 0 && nausea.getDuration() == 100, "depletion did not apply nausea I for 100 ticks");
        helper.succeed();
    }
}
