package cn.blockforge.generated.modb22b5730;

import cn.blockforge.generated.modb22b5730.client.*;
import cn.blockforge.generated.modb22b5730.client.vortex.SpellVortexRenderer;
import cn.blockforge.generated.modb22b5730.entity.*;
import cn.blockforge.generated.modb22b5730.spell.*;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.*;
import net.minecraftforge.fml.common.Mod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import java.nio.file.*;

/** 自动验收专用；只在 -PqaClient 下加载，正式JAR与正常runClient均不包含。 */
@Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID,value=Dist.CLIENT)
public final class QiyuanClientQA {
    private static long start, lastSpawn;
    private static int stage, circleFrames, vortexFrames;
    private static CodexData.Spell forbidden;
    private static volatile boolean forbiddenCastSucceeded;
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (!Boolean.getBoolean("qiyuan.qa") || event.phase != TickEvent.Phase.END) return;
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null || mc.player==null || mc.getSingleplayerServer()==null) return;
        long now=System.currentTimeMillis();
        if(start==0){start=now;forbidden=CodexData.SPELLS.stream().filter(s->s.tier().contains("禁忌")&&SpellCalculator.calculate(PrayerData.parse(s.rune())).valid).findFirst().orElseThrow();}
        long elapsed=now-start;
        try {
            if(stage==0){
                stage=1;
                mc.getSingleplayerServer().execute(()->{
                    var p=mc.getSingleplayerServer().getPlayerList().getPlayers().get(0);
                    p.setGameMode(net.minecraft.world.level.GameType.CREATIVE);
                    p.setYRot(0); p.setXRot(0); p.teleportTo(0,250,0);
                    p.getAbilities().flying=true; p.onUpdateAbilities();
                    p.serverLevel().setDayTime(6000);
                    p.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new net.minecraft.world.item.ItemStack(GeneratedMod.PRAYER_STAFF.get()));
                    PrayerData.of(p).putFloat("instability",0);
                });
            }
            if(stage==1 && now-lastSpawn>650){
                lastSpawn=now;
                mc.getSingleplayerServer().execute(()->{
                    var p=mc.getSingleplayerServer().getPlayerList().getPlayers().get(0);
                    Vec3 look=p.getLookAngle(), pos=p.getEyePosition().add(look.scale(3));
                    SpellCircleEntity.spawnAt(p.level(),p,"视·水·愈·弹",0x3D9CB8,1.5F,0,24,8,pos,look.scale(-1));
                    SpellVortexEntity.spawn(p.level(),GeneratedMod.SPELL_VORTEX.get(),p,pos.add(1.4,0,0),2000);
                });
            }
            if(stage==1 && elapsed>12000){snap("qa-world.png");openBook(false);stage=2;}
            if(stage==2 && elapsed>17000){snap("qa-page23.png");openBook(true);stage=3;}
            if(stage==3 && elapsed>22000){snap("qa-forbidden.png");mc.setScreen(null);stage=4;
                mc.getSingleplayerServer().execute(()->{
                    var p=mc.getSingleplayerServer().getPlayerList().getPlayers().get(0);
                    PrayerData.setActive(p,forbidden.rune()); PrayerData.setManaPool(p,200);
                    PrayerData.setCooldownEnd(p,0); float before=PrayerData.proficiency(p); SpellCaster.tryCast(p);
                    forbiddenCastSucceeded=PrayerData.proficiency(p)==before+1;
                });
            }
            if(stage==4 && elapsed>28000){
                snap("qa-after-forbidden-cast.png");
                String result="{\"completed\":true,\"circle_render_calls\":"+circleFrames+",\"vortex_render_calls\":"+vortexFrames+",\"forbidden_cast_succeeded\":"+forbiddenCastSucceeded+",\"forbidden\":\""+forbidden.name()+"\",\"environment\":\"Linux Mesa llvmpipe, development runtime; not Android or all forbidden spells\"}\n";
                Files.writeString(Path.of("../verification/client-qa.json"),result);stage=5;
            }
            if(stage==5 && elapsed>33000) mc.stop();
        } catch(Exception error){throw new RuntimeException("客户端开发验收失败",error);}
    }
    private static void openBook(boolean taboo) throws Exception {
        PrayerState.guideDone=true;
        var screen=new BookScreen();Minecraft.getInstance().setScreen(screen);
        set(screen,"tab",1);set(screen,"codexPage",22);set(screen,"selectedSpell",taboo?forbidden:CodexData.SPELLS.get(220));
        var sync=BookScreen.class.getDeclaredMethod("syncWidgets");sync.setAccessible(true);sync.invoke(screen);
    }
    private static void set(BookScreen screen,String name,Object value)throws Exception{var f=BookScreen.class.getDeclaredField(name);f.setAccessible(true);f.set(screen,value);}
    private static void snap(String name){var mc=Minecraft.getInstance();Screenshot.grab(mc.gameDirectory,name,mc.getMainRenderTarget(),message->org.apache.logging.log4j.LogManager.getLogger().info("QA screenshot: {}",message.getString()));}
    @Mod.EventBusSubscriber(modid=GeneratedMod.MOD_ID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
    public static final class RenderAudit {
        @SubscribeEvent(priority=EventPriority.LOWEST) public static void renderers(EntityRenderersEvent.RegisterRenderers event){
            if(!Boolean.getBoolean("qiyuan.qa"))return;
            event.registerEntityRenderer(GeneratedMod.SPELL_CIRCLE.get(),ctx->new CircleRenderer(ctx){
                @Override public void render(SpellCircleEntity e,float yaw,float partial,PoseStack poses,MultiBufferSource buffers,int light){super.render(e,yaw,partial,poses,buffers,light);circleFrames++;}
            });
            event.registerEntityRenderer(GeneratedMod.SPELL_VORTEX.get(),ctx->new SpellVortexRenderer(ctx){
                @Override public void render(SpellVortexEntity e,float yaw,float partial,PoseStack poses,MultiBufferSource buffers,int light){super.render(e,yaw,partial,poses,buffers,light);vortexFrames++;}
            });
        }
    }
}
