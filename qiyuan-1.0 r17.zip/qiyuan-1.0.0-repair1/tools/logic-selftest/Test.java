import cn.blockforge.generated.modb22b5730.spell.*;
import cn.blockforge.generated.modb22b5730.rune.*;
import cn.blockforge.generated.modb22b5730.array.*;
import java.util.*;
public class Test {
  public static void main(String[] a){
    int ok=0, fail=0; Map<String,Integer> errs=new TreeMap<>();
    // 1. every codex entry
    for (CodexData.Spell s : CodexData.SPELLS) {
      try { SpellCalculator.calculate(cn.blockforge.generated.modb22b5730.data.PrayerData.parse(s.rune())); ok++; }
      catch (Throwable t){ fail++; errs.merge("codex:"+t, 1, Integer::sum);} }
    System.out.println("codex entries="+CodexData.SPELLS.size()+" ok="+ok+" fail="+fail);
    // 2. random combos
    Random r=new Random(1); List<String> all=new ArrayList<>(Runes.DATA.keySet()); int rok=0, rfail=0;
    for(int i=0;i<200000;i++){ int n=1+r.nextInt(8); List<String> c=new ArrayList<>(); for(int k=0;k<n;k++) c.add(all.get(r.nextInt(all.size())));
      try{ SpellStats st=SpellCalculator.calculate(c); if(st.valid){ RuneArrayLayout.build(st.runeString,1.6,12);} rok++; }
      catch(Throwable t){ rfail++; errs.merge("rand:"+t.getClass().getSimpleName()+":"+t.getMessage(),1,Integer::sum);} }
    System.out.println("random ok="+rok+" fail="+rfail); errs.forEach((k,v)->System.out.println(v+"  "+k));
    // codex page 23 (10 per page) & forbidden
    int per=10, p=22; for(int i=p*per;i<Math.min(CodexData.SPELLS.size(),p*per+per);i++){ CodexData.Spell s=CodexData.SPELLS.get(i); System.out.println("p23 "+s.name()+" | "+s.rune()+" | "+s.tier()); }
    System.out.println("pages="+((CodexData.SPELLS.size()+9)/10));
    if (fail != 0 || rfail != 0) throw new AssertionError("Logic regression failed");
  }
}
