package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.array.CastAnchor;
import cn.blockforge.generated.modb22b5730.array.CastPositionResolver;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.*;

public class Test {
  static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }
  public static void main(String[] args) {
    check(CastPositionResolver.resolve(List.of("视")) == CastAnchor.VIEW, "视 must resolve to VIEW");
    check(CastPositionResolver.resolve(List.of("指")) == CastAnchor.VIEW, "legacy 指 must resolve to VIEW");
    check(CastPositionResolver.resolve(List.of("己")) == CastAnchor.FEET, "己 must resolve to FEET");
    check(CastPositionResolver.validate(List.of("视", "己")) != null, "定位符文 must be mutually exclusive");
    check(CastPositionResolver.validate(List.of("视", "火")) == null, "视 plus ordinary rune is valid");

    RecordingConsumer out = new RecordingConsumer();
    RenderUtil.entityVertex(out, new PoseStack.Pose(), 1, 2, 3, 10, 20, 30, 40,
        .25f, .75f, 0, 1, 0);
    check(out.events.equals(List.of("vertex", "color", "uv", "overlay", "light", "normal", "end")),
        "NEW_ENTITY attributes/order: " + out.events);
    check(out.overlay == 0, "NO_OVERLAY must be written");
    check(out.light == 15728880, "FULL_BRIGHT must be written");
    System.out.println("render-selftest: PASS (resolver, anchor mode, NEW_ENTITY vertex order/attributes)");
  }

  private static final class RecordingConsumer implements VertexConsumer {
    final List<String> events = new ArrayList<>();
    int overlay, light;
    public VertexConsumer vertex(org.joml.Matrix4f m, float x, float y, float z) { events.add("vertex"); return this; }
    public VertexConsumer color(int r, int g, int b, int a) { events.add("color"); return this; }
    public VertexConsumer uv(float u, float v) { events.add("uv"); return this; }
    public VertexConsumer overlayCoords(int value) { events.add("overlay"); overlay = value; return this; }
    public VertexConsumer uv2(int value) { events.add("light"); light = value; return this; }
    public VertexConsumer normal(org.joml.Matrix3f m, float x, float y, float z) { events.add("normal"); return this; }
    public void endVertex() { events.add("end"); }
  }
}
