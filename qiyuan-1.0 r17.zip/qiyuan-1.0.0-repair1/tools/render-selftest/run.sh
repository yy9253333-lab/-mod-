#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
mkdir -p "$W/src/com/mojang/blaze3d/vertex" "$W/src/net/minecraft/client/renderer/texture" "$W/src/net/minecraft/client/renderer" "$W/src/org/joml" "$W/out"
cat > "$W/src/org/joml/Matrix4f.java" <<'EOF'
package org.joml; public class Matrix4f {}
EOF
cat > "$W/src/org/joml/Matrix3f.java" <<'EOF'
package org.joml; public class Matrix3f {}
EOF
cat > "$W/src/com/mojang/blaze3d/vertex/VertexConsumer.java" <<'EOF'
package com.mojang.blaze3d.vertex;
import org.joml.Matrix3f; import org.joml.Matrix4f;
public interface VertexConsumer {
  VertexConsumer vertex(Matrix4f m,float x,float y,float z);
  VertexConsumer color(int r,int g,int b,int a);
  VertexConsumer uv(float u,float v);
  VertexConsumer overlayCoords(int value);
  VertexConsumer uv2(int value);
  VertexConsumer normal(Matrix3f m,float x,float y,float z);
  void endVertex();
}
EOF
cat > "$W/src/com/mojang/blaze3d/vertex/PoseStack.java" <<'EOF'
package com.mojang.blaze3d.vertex;
import org.joml.Matrix3f; import org.joml.Matrix4f;
public class PoseStack { public static class Pose { public Matrix4f pose(){return new Matrix4f();} public Matrix3f normal(){return new Matrix3f();} } }
EOF
cat > "$W/src/net/minecraft/client/renderer/LightTexture.java" <<'EOF'
package net.minecraft.client.renderer; public final class LightTexture { public static final int FULL_BRIGHT=0xF000F0; }
EOF
cat > "$W/src/net/minecraft/client/renderer/texture/OverlayTexture.java" <<'EOF'
package net.minecraft.client.renderer.texture; public final class OverlayTexture { public static final int NO_OVERLAY=0; }
EOF
javac -encoding UTF-8 -d "$W/out" \
  $(find "$W/src" -name '*.java' -print) \
  "$ROOT/src/main/java/cn/blockforge/generated/modb22b5730/array/CastAnchor.java" \
  "$ROOT/src/main/java/cn/blockforge/generated/modb22b5730/array/CastPositionResolver.java" \
  "$ROOT/src/main/java/cn/blockforge/generated/modb22b5730/client/RenderUtil.java" \
  "$ROOT/tools/render-selftest/Test.java"
java -Dfile.encoding=UTF-8 -cp "$W/out" cn.blockforge.generated.modb22b5730.client.Test
