#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ ! -f run-gametest/world/level.dat ]]; then
  echo '请先运行 ./gradlew runGameTestServer -x downloadAssets 生成独立测试世界。' >&2
  exit 2
fi
if [[ -e run-client/saves/QiyuanQA ]]; then
  echo 'QiyuanQA目录已存在；为避免覆盖，请先手动移走该测试世界。' >&2
  exit 2
fi
mkdir -p run-client/saves verification
cp -a run-gametest/world run-client/saves/QiyuanQA
./gradlew runClient -PqaClient --console=plain 2>&1 | tee verification/client.log
