# 真实 Forge 验收入口

使用 JDK 17，项目根目录执行：

```bash
./gradlew runGameTestServer -x downloadAssets
```

`-x downloadAssets` 仅跳过服务端不使用的客户端音效等资源，不跳过模组代码或断言。测试源码与 `mod_b22b5730:empty` 结构属于独立 gametest 源码集，不进入正式 JAR。

当前六项测试：法阵世界坐标/法线与24tick清理；漩涡魔力快照与60tick清理；弹体45度初速度及每tick重力0.03；弹体撞墙移除；真实Forge FakePlayer的200→190扣费、上限+5、熟练+1及冷却拒绝；魔力9不足时归零、无成长/冷却且恶心I100tick。

默认值断言使用独立测试目录下的默认配置。若自行改过 `run-gametest/config/mod_b22b5730-common.toml`，请使用新的测试目录或还原该测试配置；不要为跑测试删除正常游戏配置。

客户端专项验收：先运行GameTest生成空测试世界，再运行 `bash tools/gametest/run-client-qa.sh`。该脚本拒绝覆盖已有 QiyuanQA 世界。需要可用X11/OpenGL图形环境；它不会登录账号，不会读取用户正常游戏存档。驱动只在 `-PqaClient` 显式开启，普通runClient与正式JAR均不包含此驱动。

驱动会重复生成短命法阵/漩涡以取得画面，打开图鉴第23页，查看一个有效禁忌术式并尝试一次施法，记录真实渲染器super调用次数、保存四张Minecraft原生截图并退出。它不是安卓实机、联机延迟、全部禁忌术式或攻击伤害的完整验收。

本轮客户端命令因全量音效下载耗时使用了 `-x downloadAssets`，该运行的音频缺资源警告应与渲染错误区分。复现脚本默认不跳过资源下载。

实际通过或失败只以 `verification/` 中最终日志、截图及交付说明为准，不能因为有测试源码就认为测试已通过。早期夹具NBT错误和开发环境GeckoLib refmap错误的日志也保留作区分，不隐瞒失败过程。
