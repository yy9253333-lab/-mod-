#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p verification
# 请事先让JAVA_HOME指向JDK17。三个无MC测试只需javac/java。
bash tools/logic-selftest/run.sh 2>&1 | tee verification/logic-selftest.log
bash tools/render-selftest/run.sh 2>&1 | tee verification/render-selftest.log
bash tools/core-selftest 2>&1 | tee verification/core-selftest.log
./gradlew --console=plain build verifyAndroidCompat 2>&1 | tee verification/build.log
./gradlew --console=plain runGameTestServer -x downloadAssets 2>&1 | tee verification/gametest.log
# 最后一步是真实Forge服务端GameTest，但不是客户端或Android实机验收。
