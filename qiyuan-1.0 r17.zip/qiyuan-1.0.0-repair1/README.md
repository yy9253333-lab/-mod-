# 《祈愿》Forge 1.20.1 修复版 repair1

本项目在原有源码上定点修复，没有另起项目重写。请先阅读 [修改说明与测试记录](FIXES_AND_TESTS.md)，其中明确区分真实测试、stub逻辑测试、未实测项目和未定义的游戏设计。

## 版本来源

唯一收到的附件名为 `qiyuan-r14.zip`，内部目录名却是 `qiyuan-1.0.0-r6`，原 build.gradle 版本另写 r5。没有使用一份未收到的独立 r14 源码。原说明保留在 `docs/history/README-original-r5.md`；原包其他历史说明不是本轮验收证据。

## 环境与安装

Minecraft 1.20.1、Forge 47.4.0、Java 17。客户端和服务端都需要修复版 JAR 与 **GeckoLib 4.4.9 Forge 1.20.1** JAR；GeckoLib 的 mclib 已内置。先备份旧存档，在独立新存档试运行，替换旧祈愿 JAR，不要并存两个版本。

已有配置不会被新的默认值覆盖。精确规格使用 `legacyRuneCosts=false`、`manaCost=10.0`、`exhaustionNauseaTicks=100`；升级时请核对旧配置中的对应值，不要删除自己的存档。

## 构建与验收

设置 `JAVA_HOME` 为JDK17，Windows使用 `gradlew.bat`：

```bash
./gradlew build verifyAndroidCompat
./gradlew runGameTestServer -x downloadAssets
bash tools/verify.sh
```

正式产物：`build/libs/qiyuan-1.0.0-repair1-forge-1.20.1.jar`。Gradle 8.8 Wrapper、固定 ForgeGradle 版本及测试夹具都已附上；首次构建需要联网。

`buildDesktop` 与 `buildAndroid` 生成同一通用 JAR。Android任务只做禁用API静态扫描，不等于FCL/MobileGlues或安卓实机测试通过。

真实服务端六项GameTest和开发客户端测试说明见 `tools/gametest/README.md`。客户端自动验收只在显式 `-PqaClient` 开启，测试代码不进入正式JAR，也不影响普通游戏。

## 保留与边界

保留原136张PNG、符文、图鉴和禁忌术式数据及原有效果分派。增加服务端权威费用/命中、冻结世界法阵、左下HUD、最近三术式切换、蓄力与天赋接口。

MagicComprehension/TalentPoints来源、实际天赋节点、“水＋风”雷暴数值和乱魔触发符文没有定义，因此保留接口与调试入口，不擅自添加玩法。漩涡目前使用半透明发光回退，没有真正的主帧缓冲折射。
