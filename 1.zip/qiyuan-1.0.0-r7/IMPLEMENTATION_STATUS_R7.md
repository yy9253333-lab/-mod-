# 《祈愿》R7 实施状态（基础与魔力成长阶段）

目标环境：Minecraft 1.20.1 / Forge 47.4.0 / Java 17；Mod ID 保持 `mod_b22b5730`。

## 本阶段已写入源码（基础阶段，不等于 23 步全完成）

1. 新增 `capability/PlayerManaData`，存储魔力表中的 13 个字段，带上下限裁剪、NBT 读写和 `copyFrom`；额外保存内部 `WasDepleted` 边沿标志。
2. 新增 `PlayerManaProvider` 与 `PlayerManaEvents`。仅对玩家附加 Capability；仅在死亡 Clone 时复制；支持存档序列化。
3. 在现有 `PrayerNet` 的单一 `SimpleChannel` 上增加 `S2CSyncManaPacket`，登录、重生、换维度以及周期同步时推送完整魔力字段。原本的法术书同步协议保留。
4. 将现有 `PrayerData.mana/maxMana/addMana/spendMana` 接到新的 Capability，避免旧法术入口继续读写第二份魔力池。
5. 新增四个可同步属性注册与两种粒子类型注册。属性通过 `EntityAttributeModificationEvent` 添加到玩家；粒子 Provider 还未绑定。
6. 新增 `CastFailureEvent` 与 `CastSpellEvent`。现有施法入口仅在真正成功、没有返还费用时发布成功事件。
7. 服务端 END tick 实现魔力回复、耗尽边沿时反胃 100 ticks、耗尽复位，以及波动值向 1.0 衰减。零魔力再次施法会发布失败事件，已有反胃不会被重复刷新。
8. 首次成功施法启动新手计时；只有窗口启动后才累计 `NewbieTicks`。窗口内每次成功施法将 `ManaCapacity` 增加 5，硬上限 2000；增加容量不会填充 `ManaPool`。
9. 工程产物版本名更新为 R7；新增 `network`、`event`、`capability`、`registry`、`talent`、`command`、`render` 包基础结构。

## 按总规格尚未完成的基础项

- 本阶段只注册了 `S2CSyncManaPacket`；`C2SCastPacket`、`C2SChargeStatePacket`、`C2SSetDuplicatePacket`、`C2SMeditatePacket`、`S2CAnchorSyncPacket`、`S2CSyncTalentDataPacket`、`C2SUnlockNodePacket`、`S2CInterruptCastPacket` 尚未注册，等待对应功能一起落地，避免先注册空处理器。

## 尚未完成

- 这不是 23 步总规格的完整实现。蓄力、无杖施法、冥想、水晶新用法、弹道反解与碰撞、锚点法阵、漩涡实体/着色器、混合魔法、天赋 Capability/界面/指令和其余指定网络包，均未在本阶段完成。
- R6 的旧水晶仍保持旧有用法；尚未替换为 32 ticks 使用、容量 +20 的规则。
- `DuplicateCount` 目前仍按字段表限制为 1–5。后续复制加成属性最高 +5 与此范围冲突，实施蓄力复制前必须把字段有效范围调整至 1–10，否则天赋加成无法生效。
- 弹道公式给出的飞行时间可能是小数 tick；真正落点要求必须依赖每 tick 的扫掠碰撞/交点处理，不能只执行 `setPos(pos + motion)`。
- KeyMapping 不是 `DeferredRegister` 项；它应继续通过 `RegisterKeyMappingsEvent` 注册。网络通道用 `SimpleChannel` 初始化；Capability 用 `CapabilityManager` 获取并通过 `AttachCapabilitiesEvent` 挂载。

## 验证状态

已进行源码层面的调用路径与字段检查；当前运行环境没有 Gradle 可执行文件，工程也不含 Gradle Wrapper，因此**尚未完成 Forge 编译，更没有生成或启动测试 JAR**。不要把此源码包视为已编译验证通过的版本。
