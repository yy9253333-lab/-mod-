package cn.blockforge.generated.modb22b5730.registry;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 在模组生命周期事件中把已注册的自定义属性附加给玩家。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class RegistryEvents {
    @SubscribeEvent
    public static void addPlayerAttributes(EntityAttributeModificationEvent event) {
        event.add(EntityType.PLAYER, ModAttributes.MANA_REGEN.get());
        event.add(EntityType.PLAYER, ModAttributes.SPELL_COMPRESSION.get());
        event.add(EntityType.PLAYER, ModAttributes.MAX_DUPLICATE_BONUS.get());
        event.add(EntityType.PLAYER, ModAttributes.INSTABILITY_REDUCTION.get());
    }

    private RegistryEvents() {}
}
