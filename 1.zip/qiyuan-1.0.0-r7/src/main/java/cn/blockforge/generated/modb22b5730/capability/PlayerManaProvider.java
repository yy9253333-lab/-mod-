package cn.blockforge.generated.modb22b5730.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.Capability;
import javax.annotation.Nullable;

/** 玩家魔力 Capability 的附加、序列化和生命周期包装器。 */
public final class PlayerManaProvider implements ICapabilitySerializable<CompoundTag> {
    private final PlayerManaData data = new PlayerManaData();
    private final LazyOptional<PlayerManaData> optional = LazyOptional.of(() -> data);

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction side) {
        return PlayerManaCapability.PLAYER_MANA.orEmpty(capability, optional);
    }

    @Override public CompoundTag serializeNBT() { return data.writeNBT(); }
    @Override public void deserializeNBT(CompoundTag nbt) { data.readNBT(nbt); }
    public void invalidate() { optional.invalidate(); }
}
