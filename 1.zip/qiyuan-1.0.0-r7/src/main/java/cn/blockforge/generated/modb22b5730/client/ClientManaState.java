package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.network.S2CSyncManaPacket;

/** 客户端只读快照，供 HUD、施法提示与蓄力界面使用。 */
public final class ClientManaState {
    public static int manaCapacity = 200;
    public static float manaPool = 200.0F;
    public static float manaRegen = 0.05F;
    public static float manaCost = 10.0F;
    public static float manaInstability = 1.0F;
    public static int spellProficiency;
    public static int magicComprehension;
    public static boolean newbieStarted;
    public static int newbieTicks;
    public static int meditateCooldown;
    public static boolean chargingState;
    public static int chargedTick;
    public static int duplicateCount = 1;

    public static void apply(S2CSyncManaPacket p) {
        manaCapacity = p.manaCapacity();
        manaPool = p.manaPool();
        manaRegen = p.manaRegen();
        manaCost = p.manaCost();
        manaInstability = p.manaInstability();
        spellProficiency = p.spellProficiency();
        magicComprehension = p.magicComprehension();
        newbieStarted = p.newbieStarted();
        newbieTicks = p.newbieTicks();
        meditateCooldown = p.meditateCooldown();
        chargingState = p.chargingState();
        chargedTick = p.chargedTick();
        duplicateCount = p.duplicateCount();

        // 兼容现有法术书/HUD：它们读取 PrayerState 的旧字段。
        PrayerState.mana = Math.max(0, (int) Math.floor(manaPool + 1.0e-4F));
        PrayerState.maxMana = manaCapacity;
    }

    private ClientManaState() {}
}
