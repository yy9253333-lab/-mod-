package cn.blockforge.generated.modb22b5730.menu;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 9×9 符文摆放区 + 玩家背包。此阶段先实现可靠的摆放/保存，不伪装成已完成符文合成。 */
public final class RuneWorkbenchMenu extends AbstractContainerMenu {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, GeneratedMod.MOD_ID);
    public static final RegistryObject<MenuType<RuneWorkbenchMenu>> TYPE = MENUS.register("rune_workbench",
        () -> IForgeMenuType.create(RuneWorkbenchMenu::new));

    private final Container workbench;
    private final ContainerLevelAccess access;

    public RuneWorkbenchMenu(int id, Inventory playerInventory, FriendlyByteBuf data) {
        this(id, playerInventory, new SimpleContainer(81), ContainerLevelAccess.NULL);
        // 位置由 NetworkHooks 写入，用于协议校验/后续服务端交互扩展。
        if (data != null && data.readableBytes() >= 8) data.readBlockPos();
    }

    public RuneWorkbenchMenu(int id, Inventory playerInventory, Container workbench, ContainerLevelAccess access) {
        super(TYPE.get(), id);
        checkContainerSize(workbench, 81);
        this.workbench = workbench;
        this.access = access;
        workbench.startOpen(playerInventory.player);

        // 81 格符文区，9×9。
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(workbench, col + row * 9, 7 + col * 18, 22 + row * 18));
            }
        }
        // 玩家背包。
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 7 + col * 18, 202 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 7 + col * 18, 260));
        }
    }

    @Override public boolean stillValid(Player player) { return workbench.stillValid(player); }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        ItemStack empty = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return empty;
        ItemStack source = slot.getItem();
        ItemStack copy = source.copy();
        if (index < 81) {
            if (!this.moveItemStackTo(source, 81, this.slots.size(), true)) return empty;
        } else {
            if (!this.moveItemStackTo(source, 0, 81, false)) return empty;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        if (source.getCount() == copy.getCount()) return empty;
        slot.onTake(player, source);
        return copy;
    }

    @Override public void removed(Player player) {
        super.removed(player);
        workbench.stopOpen(player);
    }
}
