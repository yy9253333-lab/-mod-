/** 法阵与漩涡的客户端渲染实现。 */
package cn.blockforge.generated.modb22b5730.render;
