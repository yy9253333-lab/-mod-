package cn.blockforge.generated.modb22b5730.registry;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 粒子类型注册；客户端 Provider 在客户端阶段另外绑定。 */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
        DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, GeneratedMod.MOD_ID);
    public static final RegistryObject<SimpleParticleType> SPLASH_DEBRIS =
        PARTICLE_TYPES.register("splash_debris", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> GLOW =
        PARTICLE_TYPES.register("glow", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
