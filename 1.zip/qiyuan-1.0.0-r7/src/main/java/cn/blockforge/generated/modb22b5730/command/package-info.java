/** 调试指令注册与参数验证（在后续实现阶段填充）。 */
package cn.blockforge.generated.modb22b5730.command;
