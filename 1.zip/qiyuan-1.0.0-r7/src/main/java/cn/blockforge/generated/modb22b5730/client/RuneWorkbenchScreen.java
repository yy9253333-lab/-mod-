package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.menu.RuneWorkbenchMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 石质风格的 9×9 符文工作台界面。 */
public final class RuneWorkbenchScreen extends AbstractContainerScreen<RuneWorkbenchMenu> {
    public RuneWorkbenchScreen(RuneWorkbenchMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 286;
        this.inventoryLabelY = 190;
        this.titleLabelX = 8;
        this.titleLabelY = 6;
    }

    @Override protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        // 石板底色、外框与内嵌紫灰色细边。
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF282A2D);
        g.fill(x + 2, y + 2, x + imageWidth - 2, y + imageHeight - 2, 0xFF55575A);
        g.fill(x + 5, y + 5, x + imageWidth - 5, y + 18, 0xFF34363A);
        g.fill(x + 5, y + 19, x + imageWidth - 5, y + 187, 0xFF414348);
        g.fill(x + 5, y + 189, x + imageWidth - 5, y + 281, 0xFF383A3E);
        g.fill(x + 6, y + 20, x + imageWidth - 6, y + 21, 0xFF8B8494);
        // 九乘九格子的石刻底槽。
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                int sx = x + 7 + col * 18;
                int sy = y + 22 + row * 18;
                g.fill(sx, sy, sx + 16, sy + 16, 0xFF292B2F);
                g.fill(sx + 1, sy + 1, sx + 15, sy + 15, 0xFF686A6E);
                g.fill(sx + 2, sy + 2, sx + 14, sy + 14, 0xFF44464A);
            }
        }
        // 玩家背包区域分隔线。
        g.fill(x + 6, y + 188, x + imageWidth - 6, y + 189, 0xFF8B8494);
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }
}
