package cn.blockforge.generated.modb22b5730.block.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 所有 BlockEntity 类型统一在这里注册。 */
public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, GeneratedMod.MOD_ID);

    public static final RegistryObject<BlockEntityType<AnchorRuneBlockEntity>> ANCHOR_RUNE =
        BLOCK_ENTITIES.register("anchor_rune", () -> BlockEntityType.Builder.of(
            AnchorRuneBlockEntity::new,
            GeneratedMod.ANCHOR_RUNE_BLOCK.get()
        ).build(null));

    public static final RegistryObject<BlockEntityType<InscribedRuneBlockEntity>> INSCRIBED_RUNE =
        BLOCK_ENTITIES.register("inscribed_rune", () -> BlockEntityType.Builder.of(
            InscribedRuneBlockEntity::new,
            GeneratedMod.INSCRIBED_RUNE_BLOCK.get()
        ).build(null));


    public static final RegistryObject<BlockEntityType<RuneWorkbenchBlockEntity>> RUNE_WORKBENCH =
        BLOCK_ENTITIES.register("rune_workbench", () -> BlockEntityType.Builder.of(
            RuneWorkbenchBlockEntity::new, GeneratedMod.RESONANCE_TABLE_BLOCK.get()
        ).build(null));

    private ModBlockEntities() {}
}
