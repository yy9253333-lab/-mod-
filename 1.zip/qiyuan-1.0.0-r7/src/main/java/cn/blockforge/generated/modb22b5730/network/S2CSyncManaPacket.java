package cn.blockforge.generated.modb22b5730.network;

import cn.blockforge.generated.modb22b5730.capability.PlayerManaCapability;
import cn.blockforge.generated.modb22b5730.capability.PlayerManaData;
import cn.blockforge.generated.modb22b5730.client.ClientManaState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** S2C 全字段魔力同步包。只由服务端构造和发送，客户端不具备写回权限。 */
public record S2CSyncManaPacket(
    int manaCapacity,
    float manaPool,
    float manaRegen,
    float manaCost,
    float manaInstability,
    int spellProficiency,
    int magicComprehension,
    boolean newbieStarted,
    int newbieTicks,
    int meditateCooldown,
    boolean chargingState,
    int chargedTick,
    int duplicateCount
) {
    public static S2CSyncManaPacket from(ServerPlayer player) {
        return player.getCapability(PlayerManaCapability.PLAYER_MANA)
            .map(S2CSyncManaPacket::from)
            .orElseGet(() -> new S2CSyncManaPacket(200, 200.0F, 0.05F, 10.0F, 1.0F, 0, 0, false, 0, 0, false, 0, 1));
    }

    private static S2CSyncManaPacket from(PlayerManaData d) {
        return new S2CSyncManaPacket(d.getManaCapacity(), d.getManaPool(), d.getManaRegen(), d.getManaCost(),
            d.getManaInstability(), d.getSpellProficiency(), d.getMagicComprehension(), d.isNewbieStarted(),
            d.getNewbieTicks(), d.getMeditateCooldown(), d.isChargingState(), d.getChargedTick(), d.getDuplicateCount());
    }

    public static void encode(S2CSyncManaPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.manaCapacity);
        buf.writeFloat(p.manaPool);
        buf.writeFloat(p.manaRegen);
        buf.writeFloat(p.manaCost);
        buf.writeFloat(p.manaInstability);
        buf.writeVarInt(p.spellProficiency);
        buf.writeVarInt(p.magicComprehension);
        buf.writeBoolean(p.newbieStarted);
        buf.writeVarInt(p.newbieTicks);
        buf.writeVarInt(p.meditateCooldown);
        buf.writeBoolean(p.chargingState);
        buf.writeVarInt(p.chargedTick);
        buf.writeVarInt(p.duplicateCount);
    }

    public static S2CSyncManaPacket decode(FriendlyByteBuf buf) {
        return new S2CSyncManaPacket(
            buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
            buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readVarInt(), buf.readVarInt(),
            buf.readBoolean(), buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(S2CSyncManaPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.setPacketHandled(true);
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientManaState.apply(packet)));
    }
}
