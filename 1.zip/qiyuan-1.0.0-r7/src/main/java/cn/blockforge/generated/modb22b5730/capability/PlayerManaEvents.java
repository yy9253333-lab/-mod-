package cn.blockforge.generated.modb22b5730.capability;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 只给玩家挂载魔力 Capability；死亡重生时复制完整数据。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlayerManaEvents {
    private static final ResourceLocation KEY = GeneratedMod.rl("player_mana");

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (!(event.getObject() instanceof Player)) return;
        PlayerManaProvider provider = new PlayerManaProvider();
        event.addCapability(KEY, provider);
        event.addListener(provider::invalidate);
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        event.getOriginal().reviveCaps();
        try {
            event.getOriginal().getCapability(PlayerManaCapability.PLAYER_MANA).ifPresent(oldData ->
                event.getEntity().getCapability(PlayerManaCapability.PLAYER_MANA).ifPresent(newData -> newData.copyFrom(oldData)));
        } finally {
            event.getOriginal().invalidateCaps();
        }
    }

    private PlayerManaEvents() {}
}
