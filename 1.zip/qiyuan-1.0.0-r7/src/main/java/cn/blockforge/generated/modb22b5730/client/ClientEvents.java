package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterMenuScreensEvent;
import cn.blockforge.generated.modb22b5730.menu.RuneWorkbenchMenu;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 客户端注册实体渲染器与魔力 HUD。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientEvents {
    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> ItemBlockRenderTypes.setRenderLayer(GeneratedMod.TEMPORARY_GLASS.get(), RenderType.translucent()));
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(RuneWorkbenchMenu.TYPE.get(), RuneWorkbenchScreen::new);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GeneratedMod.SPELL_ORB.get(), OrbRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SPELL_CIRCLE.get(), CircleRenderer::new);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("prayer_mana", PrayerHud.OVERLAY);
    }

    private ClientEvents() {}
}
