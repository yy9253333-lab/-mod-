package cn.blockforge.generated.modb22b5730.event;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.registry.ModAttributes;
import cn.blockforge.generated.modb22b5730.capability.PlayerManaCapability;
import cn.blockforge.generated.modb22b5730.capability.PlayerManaData;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 服务端魔力回复、耗尽边沿处理与首次施法后的两小时成长窗口。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ManaGrowthEvents {
    private static final int DEPLETION_NAUSEA_TICKS = 100;

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        player.getCapability(PlayerManaCapability.PLAYER_MANA).ifPresent(data -> tickMana(player, data));
    }

    private static void tickMana(ServerPlayer player, PlayerManaData data) {
        // 先检测耗尽，再回复，避免 0 魔力在同一 tick 被 +0.05 掩盖掉边沿。
        if (data.getManaPool() <= 0.0F) {
            if (!data.wasDepleted()) {
                onDepletedEdge(player, data);
                data.setWasDepleted(true);
            }
        } else {
            data.setWasDepleted(false);
        }

        if (!data.isChargingState() && data.getManaPool() < data.getManaCapacity()) {
            double attributeRegen = player.getAttributeValue(ModAttributes.MANA_REGEN.get());
            float amount = (float) Math.max(0.0D, data.getManaRegen() + attributeRegen);
            data.setManaPool(Math.min(data.getManaCapacity(), data.getManaPool() + amount));
        }

        if (data.getManaInstability() > 1.0F) {
            data.setManaInstability(Math.max(1.0F, data.getManaInstability() - 0.005F));
        }

        // 计时器从首次成功施法后才走；新建玩家不会白白消耗掉成长窗口。
        if (data.isNewbieStarted() && data.getNewbieTicks() < PlayerManaData.MAX_NEWBIE_TICKS) {
            data.setNewbieTicks(data.getNewbieTicks() + 1);
        }

        // 同步新 Capability 与兼容旧法术书/HUD 使用的数据视图。
        if (player.tickCount % 10 == 0) PrayerNet.syncMana(player);
    }

    private static void onDepletedEdge(ServerPlayer player, PlayerManaData data) {
        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, DEPLETION_NAUSEA_TICKS, 0, false, false, true));
        data.setChargingState(false);
        data.setChargedTick(0);
        data.setDuplicateCount(1);
        MinecraftForge.EVENT_BUS.post(new CastFailureEvent(player, CastFailureEvent.Cause.MANA_DEPLETED));
    }

    /** 有效施法尝试在 0 魔力时调用：不刷新已有反胃持续时间。 */
    public static void notifyCastAttemptAtZero(ServerPlayer player) {
        player.getCapability(PlayerManaCapability.PLAYER_MANA).ifPresent(data -> data.setWasDepleted(true));
        MinecraftForge.EVENT_BUS.post(new CastFailureEvent(player, CastFailureEvent.Cause.MANA_DEPLETED));
        if (!player.hasEffect(MobEffects.CONFUSION)) {
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, DEPLETION_NAUSEA_TICKS, 0, false, false, true));
        }
    }

    @SubscribeEvent
    public static void onSuccessfulCast(CastSpellEvent event) {
        ServerPlayer player = event.getPlayer();
        player.getCapability(PlayerManaCapability.PLAYER_MANA).ifPresent(data -> {
            if (!data.isNewbieStarted()) data.setNewbieStarted(true);
            if (data.getNewbieTicks() < PlayerManaData.MAX_NEWBIE_TICKS) {
                data.setManaCapacity(Math.min(PlayerManaData.MAX_CAPACITY, data.getManaCapacity() + 5));
            }
            PrayerNet.syncMana(player);
            PrayerNet.sync(player);
        });
    }

    private ManaGrowthEvents() {}
}
