package cn.blockforge.generated.modb22b5730.capability;

import net.minecraft.nbt.CompoundTag;

/**
 * 持久化的玩家魔力数据。容量成长不会自动补充当前魔力。
 * 注意：wasDepleted 是服务端边沿检测状态，不属于对外属性表，但需要写入 NBT。
 */
public final class PlayerManaData {
    public static final int MIN_CAPACITY = 200;
    public static final int MAX_CAPACITY = 2000;
    public static final int MAX_NEWBIE_TICKS = 72000;

    private int manaCapacity = 200;
    private float manaPool = 200.0F;
    private float manaRegen = 0.05F;
    private float manaCost = 10.0F;
    private float manaInstability = 1.0F;
    private int spellProficiency = 0;
    private int magicComprehension = 0;
    private boolean newbieStarted = false;
    private int newbieTicks = 0;
    private int meditateCooldown = 0;
    private boolean chargingState = false;
    private int chargedTick = 0;
    private int duplicateCount = 1;
    private boolean wasDepleted = false;

    public int getManaCapacity() { return manaCapacity; }
    public void setManaCapacity(int value) {
        manaCapacity = clamp(value, MIN_CAPACITY, MAX_CAPACITY);
        // 只在上限下降时裁剪当前魔力；提高上限绝不自动补满。
        if (manaPool > manaCapacity) manaPool = manaCapacity;
    }

    public float getManaPool() { return manaPool; }
    public void setManaPool(float value) {
        manaPool = clamp(value, 0.0F, (float) manaCapacity);
    }

    public float getManaRegen() { return manaRegen; }
    public void setManaRegen(float value) { manaRegen = Math.max(0.0F, value); }

    public float getManaCost() { return manaCost; }
    public void setManaCost(float value) { manaCost = Math.max(0.0F, value); }

    public float getManaInstability() { return manaInstability; }
    public void setManaInstability(float value) { manaInstability = clamp(value, 0.0F, 5.0F); }

    public int getSpellProficiency() { return spellProficiency; }
    public void setSpellProficiency(int value) { spellProficiency = clamp(value, 0, 500); }

    public int getMagicComprehension() { return magicComprehension; }
    public void setMagicComprehension(int value) { magicComprehension = Math.max(0, value); }

    public boolean isNewbieStarted() { return newbieStarted; }
    public void setNewbieStarted(boolean value) { newbieStarted = value; }

    public int getNewbieTicks() { return newbieTicks; }
    public void setNewbieTicks(int value) { newbieTicks = clamp(value, 0, MAX_NEWBIE_TICKS); }

    public int getMeditateCooldown() { return meditateCooldown; }
    public void setMeditateCooldown(int value) { meditateCooldown = Math.max(0, value); }

    public boolean isChargingState() { return chargingState; }
    public void setChargingState(boolean value) { chargingState = value; }

    public int getChargedTick() { return chargedTick; }
    public void setChargedTick(int value) { chargedTick = clamp(value, 0, 100); }

    public int getDuplicateCount() { return duplicateCount; }
    public void setDuplicateCount(int value) { duplicateCount = clamp(value, 1, 5); }

    public boolean wasDepleted() { return wasDepleted; }
    public void setWasDepleted(boolean value) { wasDepleted = value; }

    public CompoundTag writeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("ManaCapacity", manaCapacity);
        tag.putFloat("ManaPool", manaPool);
        tag.putFloat("ManaRegen", manaRegen);
        tag.putFloat("ManaCost", manaCost);
        tag.putFloat("ManaInstability", manaInstability);
        tag.putInt("SpellProficiency", spellProficiency);
        tag.putInt("MagicComprehension", magicComprehension);
        tag.putBoolean("NewbieStarted", newbieStarted);
        tag.putInt("NewbieTicks", newbieTicks);
        tag.putInt("MeditateCooldown", meditateCooldown);
        tag.putBoolean("ChargingState", chargingState);
        tag.putInt("ChargedTick", chargedTick);
        tag.putInt("DuplicateCount", duplicateCount);
        tag.putBoolean("WasDepleted", wasDepleted);
        return tag;
    }

    public void readNBT(CompoundTag tag) {
        // 缺字段按初始值处理，以兼容空标签和早期测试存档。
        setManaCapacity(tag.contains("ManaCapacity") ? tag.getInt("ManaCapacity") : 200);
        setManaPool(tag.contains("ManaPool") ? tag.getFloat("ManaPool") : manaCapacity);
        setManaRegen(tag.contains("ManaRegen") ? tag.getFloat("ManaRegen") : 0.05F);
        setManaCost(tag.contains("ManaCost") ? tag.getFloat("ManaCost") : 10.0F);
        setManaInstability(tag.contains("ManaInstability") ? tag.getFloat("ManaInstability") : 1.0F);
        setSpellProficiency(tag.getInt("SpellProficiency"));
        setMagicComprehension(tag.getInt("MagicComprehension"));
        setNewbieStarted(tag.getBoolean("NewbieStarted"));
        setNewbieTicks(tag.getInt("NewbieTicks"));
        setMeditateCooldown(tag.getInt("MeditateCooldown"));
        setChargingState(tag.getBoolean("ChargingState"));
        setChargedTick(tag.getInt("ChargedTick"));
        setDuplicateCount(tag.contains("DuplicateCount") ? tag.getInt("DuplicateCount") : 1);
        setWasDepleted(tag.getBoolean("WasDepleted"));
    }

    public void copyFrom(PlayerManaData other) {
        setManaCapacity(other.manaCapacity);
        setManaPool(other.manaPool);
        setManaRegen(other.manaRegen);
        setManaCost(other.manaCost);
        setManaInstability(other.manaInstability);
        setSpellProficiency(other.spellProficiency);
        setMagicComprehension(other.magicComprehension);
        setNewbieStarted(other.newbieStarted);
        setNewbieTicks(other.newbieTicks);
        setMeditateCooldown(other.meditateCooldown);
        setChargingState(other.chargingState);
        setChargedTick(other.chargedTick);
        setDuplicateCount(other.duplicateCount);
        setWasDepleted(other.wasDepleted);
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static float clamp(float v, float min, float max) {
        if (!Float.isFinite(v)) return min;
        return Math.max(min, Math.min(max, v));
    }
}
