package cn.blockforge.generated.modb22b5730.registry;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 可同步自定义属性；KeyMapping、SimpleChannel 与 Capability 不属于这些 DeferredRegister。 */
public final class ModAttributes {
    public static final DeferredRegister<Attribute> ATTRIBUTES =
        DeferredRegister.create(ForgeRegistries.ATTRIBUTES, GeneratedMod.MOD_ID);

    public static final RegistryObject<Attribute> MANA_REGEN = ATTRIBUTES.register("mana_regen",
        () -> new RangedAttribute("attribute." + GeneratedMod.MOD_ID + ".mana_regen", 0.0D, 0.0D, 1.0D).setSyncable(true));
    public static final RegistryObject<Attribute> SPELL_COMPRESSION = ATTRIBUTES.register("spell_compression",
        () -> new RangedAttribute("attribute." + GeneratedMod.MOD_ID + ".spell_compression", 0.0D, 0.0D, 3.0D).setSyncable(true));
    public static final RegistryObject<Attribute> MAX_DUPLICATE_BONUS = ATTRIBUTES.register("max_duplicate_bonus",
        () -> new RangedAttribute("attribute." + GeneratedMod.MOD_ID + ".max_duplicate_bonus", 0.0D, 0.0D, 5.0D).setSyncable(true));
    public static final RegistryObject<Attribute> INSTABILITY_REDUCTION = ATTRIBUTES.register("instability_reduction",
        () -> new RangedAttribute("attribute." + GeneratedMod.MOD_ID + ".instability_reduction", 0.0D, 0.0D, 0.8D).setSyncable(true));

    private ModAttributes() {}
}
