package cn.blockforge.generated.modb22b5730.event;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.Event;

/** 统一施法失败事件；其他失败原因可在后续施法入口中追加。 */
public final class CastFailureEvent extends Event {
    public enum Cause { MANA_DEPLETED, LOCKED, INVALID_SPELL, INTERRUPTED, OTHER }

    private final ServerPlayer player;
    private final Cause cause;

    public CastFailureEvent(ServerPlayer player, Cause cause) {
        this.player = player;
        this.cause = cause == null ? Cause.OTHER : cause;
    }

    public ServerPlayer getPlayer() { return player; }
    public Cause getCause() { return cause; }
}
