package cn.blockforge.generated.modb22b5730.capability;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

/** Capability 本身由 Forge CapabilityManager 提供，并不是 DeferredRegister 注册项。 */
public final class PlayerManaCapability {
    public static final Capability<PlayerManaData> PLAYER_MANA =
        CapabilityManager.get(new CapabilityToken<>() {});

    private PlayerManaCapability() {}
}
