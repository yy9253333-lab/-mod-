/** 天赋树与节点数据（在后续实现阶段填充）。 */
package cn.blockforge.generated.modb22b5730.talent;
