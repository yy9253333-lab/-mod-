package cn.blockforge.generated.modb22b5730.block;

import cn.blockforge.generated.modb22b5730.block.entity.RuneWorkbenchBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

/** 《祈愿》符文工作台：右键打开 9×9 符文摆放界面。 */
public final class ResonanceTableBlock extends BaseEntityBlock {
    public ResonanceTableBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
            .strength(3.0f, 6.0f).sound(SoundType.STONE).requiresCorrectToolForDrops());
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RuneWorkbenchBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                  InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity entity = level.getBlockEntity(pos);
        if (entity instanceof RuneWorkbenchBlockEntity workbench && player instanceof ServerPlayer serverPlayer) {
            NetworkHooks.openScreen(serverPlayer, workbench, buf -> buf.writeBlockPos(pos));
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }
}
