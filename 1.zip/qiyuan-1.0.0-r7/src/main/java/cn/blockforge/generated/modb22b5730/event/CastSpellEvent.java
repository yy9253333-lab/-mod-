package cn.blockforge.generated.modb22b5730.event;

import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.Event;

/** 服务端施法确实完成、扣费未回滚后才发布。失败施法不得触发本事件。 */
public final class CastSpellEvent extends Event {
    private final ServerPlayer player;
    private final String runeString;
    private final SpellStats stats;

    public CastSpellEvent(ServerPlayer player, String runeString, SpellStats stats) {
        this.player = player;
        this.runeString = runeString == null ? "" : runeString;
        this.stats = stats;
    }

    public ServerPlayer getPlayer() { return player; }
    public String getRuneString() { return runeString; }
    public SpellStats getStats() { return stats; }
}
