package cn.blockforge.generated.modb22b5730.block.entity;

import cn.blockforge.generated.modb22b5730.block.AnchorRuneBlock;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/**
 * 阵基石 BlockEntity：把刻好的术式永久锚定在世界里。
 * 每 20 tick（1 秒）从最近的刻阵者身上抽一次魔力，然后在阵位上结算一次法术。
 * 魔力不够时法阵暂停，粒子变暗，不消耗任何东西。
 */
public class AnchorRuneBlockEntity extends BlockEntity {
    public static final int TRIGGER_INTERVAL = 20;          // 1 秒触发一次
    public static final double FIND_RADIUS = 16.0;          // 在 16 格内找主人
    private static final double EFFECT_RADIUS = 4.0;        // 法阵影响半径

    private String runes = "";
    private UUID ownerUuid;
    private long nextTriggerAt;

    public AnchorRuneBlockEntity(BlockPos pos, BlockState state) {
        super(cn.blockforge.generated.modb22b5730.block.entity.ModBlockEntities.ANCHOR_RUNE.get(), pos, state);
    }

    public void engrave(Player owner, String runeString) {
        this.runes = runeString == null ? "" : runeString;
        this.ownerUuid = owner == null ? null : owner.getUUID();
        this.nextTriggerAt = 0;
        setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public String runes() { return runes; }
    public boolean isEngraved() { return !runes.isEmpty(); }
    public UUID owner() { return ownerUuid; }

    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();

        // 视觉：每 4 tick 画一圈尘埃（8 个粒子，比原来省一半）
        if (now % 4 == 0) {
            int color = isEngraved() ? SpellCaster.primaryColor(PrayerData.parse(runes)) : 0x3D9CB8;
            var dust = SpellCaster.dust(color, 1.0f);
            double cx = worldPos.getX() + 0.5;
            double cy = worldPos.getY() + 0.15;
            double cz = worldPos.getZ() + 0.5;
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI * 2 / 8 + now * 0.02;
                sl.sendParticles(dust, cx + Math.cos(a) * EFFECT_RADIUS, cy, cz + Math.sin(a) * EFFECT_RADIUS, 1, 0, 0, 0, 0);
            }
        }

        if (!isEngraved()) return;
        if (now < nextTriggerAt) return;

        List<String> parsed = PrayerData.parse(runes);
        if (parsed.isEmpty()) { nextTriggerAt = now + TRIGGER_INTERVAL; return; }

        // 找最近的主人
        Player owner = findOwner();
        if (owner == null) { nextTriggerAt = now + TRIGGER_INTERVAL * 5; return; }

        SpellStats st = SpellCalculator.calculate(parsed);
        if (!st.valid) { nextTriggerAt = now + TRIGGER_INTERVAL; return; }

        // 扣魔力：每次触发按法术基础消耗的 20% 抽（持续法阵比单发便宜）
        int cost = Math.max(1, st.manaTotal / 5);
        if (!PrayerData.spendMana(owner, cost)) {
            // 魔力不足：粒子红一下，不触发
            if (now % 40 == 0) {
                sl.sendParticles(ParticleTypes.ANGRY_VILLAGER,
                    worldPos.getX() + 0.5, worldPos.getY() + 1.0, worldPos.getZ() + 0.5, 1, 0.2, 0.3, 0.2, 0);
            }
            nextTriggerAt = now + TRIGGER_INTERVAL;
            return;
        }

        // 触发法术（repeat=true，伤害衰减到 35%，适合持续场）
        Vec3 pos = new Vec3(worldPos.getX() + 0.5, worldPos.getY() + 0.5, worldPos.getZ() + 0.5);
        SpellCaster.applyZone(sl, owner, parsed, pos, true);
        nextTriggerAt = now + TRIGGER_INTERVAL;
    }

    private Player findOwner() {
        if (level == null) return null;
        AABB box = new AABB(worldPos).inflate(FIND_RADIUS);
        List<Player> players = level.getEntitiesOfClass(Player.class, box, p -> p != null && p.isAlive());
        Player best = null;
        double bestDist = Double.MAX_VALUE;
        for (Player p : players) {
            if (ownerUuid != null && !p.getUUID().equals(ownerUuid)) continue;
            double d = p.distanceToSqr(worldPos.getCenter());
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("prayer_runes", runes);
        tag.putLong("prayer_next_trigger", nextTriggerAt);
        if (ownerUuid != null) tag.putUUID("prayer_owner", ownerUuid);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        runes = tag.getString("prayer_runes");
        nextTriggerAt = tag.getLong("prayer_next_trigger");
        ownerUuid = tag.hasUUID("prayer_owner") ? tag.getUUID("prayer_owner") : null;
    }
}
