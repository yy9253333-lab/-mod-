# 《祈愿》r5 源码修订记录

目标环境：Minecraft Java 1.20.1 / Forge 47.4.0 / Java 17。

## 本轮修改

1. `RenderUtil.entityVertex` 改为显式逐字段写入位置、颜色、UV、NO_OVERLAY、FULL_BRIGHT、法线，最后才提交顶点；`CircleRenderer` 和 `OrbRenderer` 继续共用该入口。此修订针对 NEW_ENTITY 顶点格式完整性，但必须进入实际客户端复现原始崩溃，才能确认是否彻底消除。
2. 新增 `EarthSpellBlocks`。只有术式同时包含「土」「创」才触发，每次命中最多 1–9 个方块，阶位越高生成数量与石材等级越高。仅在有坚实地面、目标格与上方格均为空、区块已加载且不存在方块实体时放置；不会替换任何已有方块，也会避开方块实体；自然石材构成的玩家建筑仍无法仅凭通用方块标签百分之百识别，因此该策略是保守限制，不等同于领地插件保护。
3. `SpellOrbEntity` 为火、冰、水、雷、风分别添加原版粒子；保留原有飞弹实体与 100 tick 超时逻辑。
4. 新增 `/qiyuan give_all_runes`，需要权限等级 2，且执行者必须是创造模式玩家。命令遍历注册表中的 RuneItem，按物品对象去重，每种发放 1 枚；背包满时掉落在玩家附近。
5. 工程版本更新为 `1.0.0-r5`，Gradle jar 输出名设置为 `qiyuan-1.0.0-r5-forge-1.20.1.jar`。

## 尚未验证

当前运行容器没有 Gradle 可执行文件、没有工程自带 Gradle Wrapper，并且 Gradle 下载地址无法解析，因此本轮无法完成 `compileJava`、`reobfJar` 或 JAR 启动验证。本包是已修改的源码工程，不应冒充为已编译成功的 r5 JAR。请在具备 Java 17、Gradle 8.x 与网络依赖访问的环境中运行 `gradle build`，再在 Minecraft 1.20.1 Forge 与 FCL/MobileGlues 实机测试。

## r5 补丁：取消拿起道具时的视野前预览

- `ViewCircleRenderer` 新增 `IDLE_PREVIEW = false`：手持魔导书/法杖不再常驻绘制视野前法阵预览。
- 施法时的世界坐标法阵闪光保持不变（`SpellCircleEntity` mode=0）。
- 如需恢复旧预览，把 `IDLE_PREVIEW` 改为 `true` 即可。

## r5 补丁：瞬符文与冷却逻辑修正

- 「瞬」术式现在真正无视冷却：`SpellCaster.tryCast` 冷却检查跳过 `flash`（之前提示文字说无视冷却，实际仍被拦截）。
- 「瞬」施法不再覆盖已有冷却（之前会把冷却时间清零，允许绕过前一个术式的冷却）。
- 「瞬」构建时间固定为 0.1s，且在「缓」之后覆盖，不再得到 0.2s。
- 术式不完整（不能静默计算）时，推演面板的构建时间/冷却显示 "--"，不再显示误导性的 0.0s。


## 本轮法阵修复（2026-10-15）

6. `CastDispatch` 处理目标符文时增加“视”优先规则：组合同时包含“己”和“视”时，不再被 `SELF_GROUND` 抢先分派到玩家脚下；按准星命中位置施法。投射形态仍由原有规则分派。`isSelfTarget` 同步修正，避免把“己 + 视”误判为纯自身术式。
7. `SpellCircleEntity` 的施法视觉实体生命周期从 4 tick 调整为 24 tick（约 1.2 秒），构建动画时长从 2 tick 调整为 10 tick，使展开、旋转、符文逐层显现及淡出能够被看清。该生命周期只作用于 `mode=0` 视觉法阵，不改变 `mode=1` 持续区域逻辑。
8. `CircleRenderer` 加入从 30% 尺寸平滑展开至完整尺寸的动画，并在释放阶段短暂增强亮度；法阵仍在生成时确定的世界坐标渲染，不跟随玩家或相机移动。
9. 持有法杖时的视野前常驻预览仍由 `ViewCircleRenderer.IDLE_PREVIEW = false` 关闭；实体只在服务端成功施法路径中生成。`PrayerStaffItem.use` 仍是右键施法入口，不在每 tick 生成法阵。

## 验证状态

- 已检查本轮改动的调用路径与相关 Java 源码。
- 当前执行环境没有 `gradle` 可执行文件，也没有已缓存的 ForgeGradle/Forge 依赖；尝试访问 Gradle 分发地址时 DNS 解析失败。因此本轮**未能完成 Gradle 编译或游戏内验证**，不能把此源码包称为已编译成功的 JAR。
- 建议在本地 JDK 17 + Gradle 8.x 环境运行 `gradle buildDesktop`；随后运行 `gradle buildAndroid` 检查静态兼容性，再分别在 PC Forge 1.20.1 与 FCL/MobileGlues 实机测试。

## 本轮追加：法阵锚点与朝向（2026-10-15）

10. 目标实体被准星射线直接命中时，法阵锚点使用射线与实体碰撞箱的真实交点，不再偏移到目标身体中心；网络旋转延迟的锁定兜底逻辑保持不变。
11. 短暂施法法阵新增同步/存档法线。命中方块时按实际命中面法线摆放，命中实体或空中射线时朝向施法者；位置和法线都在实体生成前固定，渲染时仅沿命中面法线偏移少量距离避免表面闪烁。
12. `CircleRenderer` 先将法阵平面旋转至命中面，再执行原有展开、分层旋转、符文显现、释放亮光及淡出动画。常驻第一人称预览仍关闭，施法动画只由成功施法创建的世界实体触发。

验证状态：已完成源码级调用链检查与资源包结构检查；此执行环境没有 Gradle，也无法解析 `services.gradle.org`，因此无法在此处运行 ForgeGradle 编译或启动游戏。源码包不是已编译 JAR，仍需在具备 Java 17、Gradle 8.x 和 Forge 依赖访问的环境中执行 `gradle buildDesktop`，再分别进行 PC 与 FCL/MobileGlues 实机验证。
