#!/usr/bin/env bash
# 不依赖 Minecraft 的纯逻辑自检：用占位 Item/PrayerData 编译 rune/array/spell 计算类，
# 跑遍全部图鉴条目 + 20 万组随机符文组合（含 RuneArrayLayout.build）。
# 用法：在项目根目录执行  bash tools/logic-selftest/run.sh   （需要 JDK 17+）
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
S="$ROOT/src/main/java/cn/blockforge/generated/modb22b5730"
W="$(mktemp -d)"; P="$W/src/cn/blockforge/generated/modb22b5730"
mkdir -p "$W/stubs/net/minecraft/world/item" "$P/spell" "$P/data" "$W/out"
cp -r "$S/rune" "$S/array" "$P/"
cp "$S"/spell/{SpellCalculator,SpellStats,CodexData,CodexHandcrafted}.java "$P/spell/"
echo "package net.minecraft.world.item; public class Item {}" > "$W/stubs/net/minecraft/world/item/Item.java"
{ echo "package net.minecraft.world.item; public class Items {"
  grep -o 'Items\.[A-Z_]*' "$S/rune/Runes.java" | sort -u | sed 's/Items\.//' | while read -r n; do echo "public static final Item $n = new Item();"; done
  echo "}"; } > "$W/stubs/net/minecraft/world/item/Items.java"
cat > "$P/data/PrayerData.java" <<'JAVA'
package cn.blockforge.generated.modb22b5730.data;
import java.util.*;
public final class PrayerData { public static List<String> parse(String s){ List<String> o=new ArrayList<>(); if(s==null)return o; for(String p:s.split("[·|,]")) if(!p.isBlank()) o.add(p.trim()); return o; } }
JAVA
find "$W/src" "$W/stubs" -name '*.java' > "$W/files.txt"
javac -nowarn -encoding UTF-8 -d "$W/out" @"$W/files.txt" "$ROOT/tools/logic-selftest/Test.java"
java -Dfile.encoding=UTF-8 -cp "$W/out" Test
