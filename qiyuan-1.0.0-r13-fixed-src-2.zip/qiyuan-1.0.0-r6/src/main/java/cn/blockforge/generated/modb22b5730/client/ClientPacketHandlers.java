package cn.blockforge.generated.modb22b5730.client;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

/**
 * 客户端网络包处理入口。只能通过 DistExecutor 在 Dist.CLIENT 调用，
 * 这样公共类 PrayerNet 不会直接引用 net.minecraft.client.*，专用服务器不会因类缺失而加载失败。
 */
public final class ClientPacketHandlers {
    public static void applySync(CompoundTag tag) { PrayerState.apply(tag); }

    public static void openBook() { Minecraft.getInstance().setScreen(new BookScreen()); }

    public static void castPulse(int color) {
        Minecraft mc = Minecraft.getInstance();
        PrayerState.castPulseTick = mc.level == null ? 0 : mc.level.getGameTime();
        PrayerState.castPulseColor = color;
    }

    private ClientPacketHandlers() {}
}
