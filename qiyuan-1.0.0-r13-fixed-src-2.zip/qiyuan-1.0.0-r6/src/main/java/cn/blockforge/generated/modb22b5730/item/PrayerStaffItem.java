package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

/** 祈愿法杖：保留标准左键近战，右键施法，潜行右键打开编阵/图鉴。 */
public class PrayerStaffItem extends SwordItem {
    public PrayerStaffItem(Properties properties) {
        super(Tiers.IRON, 1, -2.4f, properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (player.isShiftKeyDown()) PrayerNet.openBook(serverPlayer);
            else SpellCaster.tryCast(serverPlayer);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override public Component getName(ItemStack stack) {
        return Component.literal("祈愿法杖").withStyle(ChatFormatting.AQUA);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("左键：近战攻击 · 右键：施放刻印术式").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("潜行右键：打开法阵台、图鉴和预制").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("滚轮 / Alt+Q、Alt+E：切换最近三种术式").withStyle(ChatFormatting.DARK_GRAY));
    }
}
