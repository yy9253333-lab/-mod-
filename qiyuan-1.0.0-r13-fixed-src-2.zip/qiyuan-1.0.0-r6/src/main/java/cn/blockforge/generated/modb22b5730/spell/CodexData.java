package cn.blockforge.generated.modb22b5730.spell;

import cn.blockforge.generated.modb22b5730.rune.Runes;
import java.util.*;

/**
 * 法术图鉴：手写条目（CodexHandcrafted，与原 HTML 一致）+ 与网页相同的组合扩展算法。
 */
public final class CodexData {
    public record Spell(String name, String rune, String tier, String elem, String effect, boolean generated) {}
    public record Match(Spell spell, boolean exact) {}

    public static final List<Spell> SPELLS = new ArrayList<>();
    public static final Map<String, Spell> BY_RUNE = new HashMap<>();

    private static final Map<String, String> TARGET_NAMES = pairs("己","自身","触","触式","视","视线","指","定点","域","领域","群","群体","灵","灵魂","物","物体");
    private static final Map<String, String> ELEM_NAMES = pairs("火","炎","水","潮","风","岚","土","岩","雷","霆","冰","霜","木","藤","金","锋","光","辉","暗","影");
    private static final Map<String, String> EFFECT_NAMES = pairs("创","构造","灭","破坏","缚","束缚","解","净化","愈","治愈","蚀","侵蚀","传","跃迁","封","封印","引","牵引","斥","震退","幻","幻象","真","显真");
    private static final Map<String, String> FORM_NAMES = pairs("弹","弹","刃","刃","壁","壁","环","环","柱","柱","网","网","链","链","雨","雨","雾","雾","刺","刺","涡","涡","潮","潮");
    private static final Map<String, String> MODIFIER_NAMES = pairs("疾","疾速","缓","延迟","续","持续","瞬","瞬发","隐","隐匿","倍","增幅","微","微缩","裂","分裂","锁","追锁","转","转化");
    private static final Map<String, String> EFFECT_TEXT = pairs(
        "创","构建或召集对应元素，形成实体或临时结构",
        "灭","集中对应元素，对目标造成直接冲击或破坏",
        "缚","限制目标行动，并在一定时间内维持束缚效果",
        "解","消解异常状态、削弱效果或对应属性的能量结构",
        "愈","将对应元素转化为修复、恢复或稳定生命的力量",
        "蚀","持续削弱目标，并逐步侵蚀其防护或结构",
        "传","借助对应元素完成传递、移动或转移",
        "封","隔绝目标与外界的联系，或暂时封存指定对象",
        "引","牵引目标、物体或周围能量向指定位置汇聚",
        "斥","释放排斥力，将目标推离中心或打断行动",
        "幻","扰乱感知，制造与真实环境相混淆的幻象",
        "真","强化观察与辨识，显露隐藏痕迹或虚假效果");
    private static final String[] MODIFIERS = {"疾","缓","续","瞬","隐","倍","微","裂","锁","转"};

    static {
        Set<String> existingRunes = new HashSet<>();
        Set<String> existingNames = new HashSet<>();
        // 注册重建：手写条目逐条校验，字段缺失补占位，符文串为空/重复的条目不进入图鉴，
        // 从源头避免空条目在渲染与推演时引发连锁异常（第 23 页闪退的数据侧修复）。
        for (String[] row : CodexHandcrafted.DATA) {
            if (row == null || row.length < 5) continue;
            String rune = safe(row[1], "");
            if (rune.isEmpty() || existingRunes.contains(rune)) continue;
            Spell s = new Spell(safe(row[0], "未名术式"), rune, safe(row[2], "一阶"),
                safe(row[3], "无"), safe(row[4], "记载缺失"), false);
            SPELLS.add(s); existingRunes.add(s.rune()); existingNames.add(s.name());
        }
        List<String> targets = Runes.BY_GROUP.getOrDefault("target", List.of());
        List<String> elements = Runes.BY_GROUP.getOrDefault("element", List.of());
        List<String> effects = Runes.BY_GROUP.getOrDefault("effect", List.of());
        List<String> forms = Runes.BY_GROUP.getOrDefault("form", List.of());
        int[] serial = {1};
        for (String target : targets) for (String elem : elements) for (String effect : effects) for (String form : forms)
            addSpell(existingRunes, existingNames, serial, target, elem, effect, form, null);
        List<Spell> baseSnapshot = new ArrayList<>();
        for (Spell s : SPELLS) if (s.generated() && s.rune().split("·").length == 4) baseSnapshot.add(s);
        int index = 0;
        for (Spell spell : baseSnapshot) {
            String[] parts = spell.rune().split("·");
            addSpell(existingRunes, existingNames, serial, parts[0], parts[1], parts[2], parts[3], MODIFIERS[index % MODIFIERS.length]);
            index++;
        }
        Set<String> seen = new HashSet<>();
        for (Spell s : SPELLS) if (seen.add(s.rune())) BY_RUNE.put(s.rune(), s);
    }

    private static void addSpell(Set<String> runes, Set<String> names, int[] serial, String target, String elem, String effect, String form, String modifier) {
        String rune = (modifier == null)
            ? String.join("·", target, elem, effect, form)
            : String.join("·", target, elem, effect, form, modifier);
        if (runes.contains(rune)) return;
        runes.add(rune);
        // 名称字段全部走查表兜底：未知符文不再拼出 "null"，避免脏数据进入图鉴。
        String name = nm(TARGET_NAMES, target, target) + nm(ELEM_NAMES, elem, elem) + nm(EFFECT_NAMES, effect, effect)
            + nm(FORM_NAMES, form, form) + (modifier == null ? "" : nm(MODIFIER_NAMES, modifier, modifier));
        if (names.contains(name)) name += "·" + String.format("%05d", serial[0]);
        names.add(name);
        String tier = tierFor(target, effect, form, modifier != null);
        StringBuilder desc = new StringBuilder();
        desc.append(nm(TARGET_NAMES, target, target)).append("为作用对象，凝聚").append(elem).append("元素，以")
            .append(nm(EFFECT_NAMES, effect, effect)).append("方式形成").append(nm(FORM_NAMES, form, form)).append("形态。")
            .append(nm(EFFECT_TEXT, effect, "依符文组合产生对应效果")).append("。");
        if (modifier != null) desc.append(" 附加「").append(MODIFIER_NAMES.get(modifier)).append("」修饰，改变术式的释放或持续特性。");
        if (effect.equals("愈") && !List.of("水","木","光").contains(elem)) desc.append(" 此组合的治疗效率较低，可能更适合辅助稳定而非直接治疗。");
        SPELLS.add(new Spell(name, rune, tier, elem, desc.toString(), true));
        serial[0]++;
    }

    private static String tierFor(String target, String effect, String form, boolean hasModifier) {
        if (target.equals("灵") && List.of("灭","封","幻").contains(effect)) return "四阶";
        if (List.of("域","群").contains(target) && List.of("雨","潮","涡").contains(form)) return "四阶";
        if (List.of("域","群").contains(target) || List.of("涡","潮","雨").contains(form) || hasModifier) return "三阶";
        if (List.of("传","真","创","封").contains(effect) || List.of("网","链").contains(form)) return "二阶";
        return "一阶";
    }

    /** 与网页 collectCodexMatches 相同的匹配候选顺序。 */
    public static List<Match> collectMatches(List<String> targets, List<String> elements, List<String> ancient, List<String> effects, List<String> forms, List<String> modifiers) {
        List<Match> matches = new ArrayList<>();
        Set<String> seenRunes = new HashSet<>();
        Set<String> seenKeys = new HashSet<>();
        String target = targets.isEmpty() ? null : targets.get(0);
        String form = forms.isEmpty() ? null : forms.get(0);
        String elem = elements.isEmpty() ? null : elements.get(0);
        String effect = effects.isEmpty() ? null : effects.get(0);
        List<String> fullSeq = new ArrayList<>(); fullSeq.addAll(targets); fullSeq.addAll(elements); fullSeq.addAll(ancient); fullSeq.addAll(effects); fullSeq.addAll(forms); fullSeq.addAll(modifiers);
        String fullRune = String.join("·", fullSeq);
        List<String> candidates = new ArrayList<>();
        candidates.add(fullRune);
        List<String> core = new ArrayList<>(); core.add(target); core.addAll(elements); core.addAll(ancient); core.addAll(effects); core.add(form); core.addAll(modifiers);
        candidates.add(join(core));
        if (elements.size() > 1 || effects.size() > 1) {
            List<String> main = new ArrayList<>(); main.add(target); main.add(elem); main.addAll(ancient); main.add(effect); main.add(form); main.addAll(modifiers);
            candidates.add(join(main));
        }
        candidates.add(join(nullable(target, elem, effect, form)));
        if (!modifiers.isEmpty()) candidates.add(join(nullable(target, elem, effect, form, modifiers.get(0))));
        for (String t : targets) for (String f : forms) {
            candidates.add(join(nullable(t, elem, effect, f)));
            if (!modifiers.isEmpty()) candidates.add(join(nullable(t, elem, effect, f, modifiers.get(0))));
        }
        candidates.add(join(nullable(elem, effect, form)));
        candidates.add(join(nullable(elem, effect)));
        for (String rune : candidates) {
            if (rune == null || rune.contains("null") || !seenRunes.add(rune)) continue;
            Spell spell = BY_RUNE.get(rune);
            if (spell == null) continue;
            String key = spell.name() + "|" + spell.rune();
            if (!seenKeys.add(key)) continue;
            matches.add(new Match(spell, spell.rune().equals(fullRune)));
        }
        matches.sort((a, b) -> {
            if (a.exact() != b.exact()) return a.exact() ? -1 : 1;
            if (a.spell().generated() != b.spell().generated()) return a.spell().generated() ? 1 : -1;
            return a.spell().rune().length() - b.spell().rune().length();
        });
        return matches;
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) { if (p == null) return null; if (sb.length() > 0) sb.append('·'); sb.append(p); }
        return sb.toString();
    }

    /** 允许 null 元素的候选构造（List.of 遇 null 会抛 NPE，正是图鉴第 23 页崩溃的根因）。 */
    private static List<String> nullable(String... parts) {
        List<String> out = new ArrayList<>(parts.length);
        for (String p : parts) out.add(p);
        return out;
    }

    /** 字段兜底：null/空白一律替换为占位值（公开给渲染层做空值防御）。 */
    public static String safe(String v, String fallback) { return v == null || v.isBlank() ? fallback : v; }

    /** 查表兜底：未知键回退为符文原文，绝不拼出 "null"。 */
    private static String nm(Map<String, String> map, String key, String fallback) {
        if (key == null) return "";
        String v = map.get(key);
        return v != null ? v : (fallback != null ? fallback : key);
    }

    public static Spell findByRune(String rune) { return BY_RUNE.get(rune); }
    @SuppressWarnings("unchecked")
    private static <V> Map<String, V> pairs(Object... values) {
        Map<String, V> out = new HashMap<>();
        for (int i = 0; i + 1 < values.length; i += 2) out.put((String) values[i], (V) values[i + 1]);
        return out;
    }

    private CodexData() {}
}
