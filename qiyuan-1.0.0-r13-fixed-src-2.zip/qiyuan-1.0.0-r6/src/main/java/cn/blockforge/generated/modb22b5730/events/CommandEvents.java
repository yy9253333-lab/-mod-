package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.CodexData;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import java.util.HashSet;
import java.util.Set;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.List;

/**
 * /qiyuan 命令族（多端兼容与构建验证的「可运行测试」部分）：
 *   /qiyuan selftest —— 图鉴全量自检：对每一条注册术式走一遍
 *         点击图鉴详情页的完整代码路径（parse → calculate → collectMatches），
 *         任何一条抛异常或产出空名称都会计数并打印——第 23 页闪退的回归测试。
 *   /qiyuan aim      —— 服务端瞄准复核快照：验证「客户端预演、服务端重算锁定」链路。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommandEvents {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("qiyuan")
            .requires(s -> s.hasPermission(1))
            .then(Commands.literal("selftest").executes(ctx -> selftest(ctx.getSource())))
            .then(Commands.literal("aim").executes(ctx -> aim(ctx.getSource())))
            .then(Commands.literal("give_all_runes")
                .requires(s -> s.hasPermission(2))
                .executes(ctx -> giveAllRunes(ctx.getSource()))));
    }

    private static int selftest(CommandSourceStack src) {
        int total = 0, failed = 0;
        for (CodexData.Spell s : CodexData.SPELLS) {
            total++;
            try {
                SpellStats st = SpellCalculator.calculate(PrayerData.parse(s.rune()));
                if (st == null || st.name == null || st.tier == null) {
                    failed++;
                    src.sendSystemMessage(Component.literal("产出空字段: [" + CodexData.safe(s.name(), "?") + "] " + s.rune()));
                }
            } catch (Throwable t) {
                failed++;
                src.sendSystemMessage(Component.literal("条目推演异常: [" + CodexData.safe(s == null ? null : s.name(), "?") + "] → " + t));
            }
        }
        // 崩溃路径专项：全空分组调用 collectMatches（旧版 List.of 遇 null 直接 NPE）
        try {
            CodexData.collectMatches(List.of(), List.of(), List.of(), List.of(), List.of(), List.of());
        } catch (Throwable t) {
            failed++;
            src.sendSystemMessage(Component.literal("空分组匹配异常 → " + t));
        }
        final int f = failed, tt = total;
        src.sendSuccess(() -> Component.literal("《祈愿》图鉴自检：共 " + tt + " 条，异常 " + f + " 条"
            + (f == 0 ? " —— 通过，图鉴任何一页都不会再触发该崩溃" : " —— 请把异常条目名反馈给模组维护者")), true);
        return f == 0 ? 1 : 0;
    }


    /** 仅向创造模式玩家发放每种已注册符文各一枚；按实际注册物品去重。 */
    private static int giveAllRunes(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer player)) {
            src.sendFailure(Component.literal("该命令只能由玩家执行。"));
            return 0;
        }
        if (!player.getAbilities().instabuild) {
            src.sendFailure(Component.literal("该命令仅限创造模式玩家使用。"));
            return 0;
        }

        Set<Item> seen = new HashSet<>();
        int granted = 0;
        for (Item item : ForgeRegistries.ITEMS.getValues()) {
            if (!(item instanceof RuneItem) || !seen.add(item)) continue;
            ItemStack stack = new ItemStack(item, 1);
            if (!player.getInventory().add(stack)) {
                player.drop(stack, false);
            }
            granted++;
        }
        final int count = granted;
        src.sendSuccess(() -> Component.literal("《祈愿》：已发放 " + count + " 种已注册符文，每种 1 枚；背包已满的物品掉落在脚边。"), true);
        return granted;
    }

    private static int aim(CommandSourceStack src) {
        if (!(src.getEntity() instanceof ServerPlayer sp)) {
            src.sendFailure(Component.literal("需要玩家执行者"));
            return 0;
        }
        SpellCaster.AimResolution res = SpellCaster.resolveAim(sp, PrayerData.parse(PrayerData.active(sp)));
        String target = res.direct() == null ? "无（命中点 "
            + String.format(java.util.Locale.ROOT, "%.1f, %.1f, %.1f", res.pos().x, res.pos().y, res.pos().z) + "）"
            : res.direct().getDisplayName().getString();
        src.sendSuccess(() -> Component.literal("准星复核：目标 " + target
            + (res.clientLocked() ? "（客户端预演锁定 ✓）" : "（纯服务端射线）")), true);
        return 1;
    }

    private CommandEvents() {}
}
