package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.rune.RuneDef;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

/** 符文物品：一个类承载七大类 72 枚符文（与原网页分类一一对应）。 */
public class RuneItem extends Item {
    private final Runes.Def def;

    public RuneItem(Runes.Def def, Properties properties) {
        super(properties);
        this.def = def;
    }

    public Runes.Def def() { return def; }

    public static ItemStack stack(String rune) {
        Runes.Def d = Runes.get(rune);
        if (d == null) return ItemStack.EMPTY;
        for (Item item : net.minecraftforge.registries.ForgeRegistries.ITEMS.getValues()) {
            if (item instanceof RuneItem ri && ri.def == d) return new ItemStack(ri);
        }
        return ItemStack.EMPTY;
    }

    @Override public Component getName(ItemStack stack) { return Component.literal("符文·" + def.rune); }

    @Override public Rarity getRarity(ItemStack stack) {
        return switch (def.rarity) { case 4 -> Rarity.EPIC; case 3 -> Rarity.RARE; case 2 -> Rarity.UNCOMMON; default -> Rarity.COMMON; };
    }

    @Override public void appendHoverText(ItemStack stack, Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal(def.group.label + "符文").withStyle(ChatFormatting.GRAY));
        tips.add(Component.literal(def.desc).withStyle(ChatFormatting.DARK_GRAY));
        if (def.group != cn.blockforge.generated.modb22b5730.rune.RuneGroup.RESISTANCE) {
            tips.add(Component.literal("魔力 " + def.mana + " · 伤害贡献 " + def.damage + (def.sustain > 0 ? " · 持续 " + def.sustain + "/秒" : "")).withStyle(ChatFormatting.AQUA));
        } else {
            tips.add(Component.literal("魔力 " + def.mana + "（每种抗性独立计价）").withStyle(ChatFormatting.AQUA));
        }
        if (!def.dmgLabel.isEmpty()) tips.add(Component.literal("伤害标签：" + def.dmgLabel).withStyle(ChatFormatting.GRAY));
        tips.add(Component.literal("合成：魔素结晶 + 对应材料").withStyle(ChatFormatting.DARK_GRAY));
    }
}
