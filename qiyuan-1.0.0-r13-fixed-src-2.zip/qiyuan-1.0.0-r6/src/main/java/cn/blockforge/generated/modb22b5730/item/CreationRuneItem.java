package cn.blockforge.generated.modb22b5730.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;

/** 特殊创造符文：首次被玩家持有时永久解锁魔法书创造模式。 */
public final class CreationRuneItem extends Item {
    public CreationRuneItem(Properties properties) { super(properties); }
    @Override public Component getName(ItemStack stack) { return Component.literal("创造符文"); }
    @Override public Rarity getRarity(ItemStack stack) { return Rarity.EPIC; }
    @Override public void appendHoverText(ItemStack stack, Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal("获得后永久解锁全部符文与创造模式").withStyle(ChatFormatting.LIGHT_PURPLE));
        tips.add(Component.literal("创造模式下施法不消耗魔力").withStyle(ChatFormatting.AQUA));
    }
}
