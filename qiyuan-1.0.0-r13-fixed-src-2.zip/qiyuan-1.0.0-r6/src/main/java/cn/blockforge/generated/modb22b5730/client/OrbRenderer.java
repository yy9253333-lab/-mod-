package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.entity.SpellOrbEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/**
 * 法术飞弹：自发光贴图广告牌。
 *
 * 局部 XY 平面上的单个四边形（QUADS，4 顶点一批提交），随 cameraOrientation 朝向玩家。
 * 顶点通过 RenderUtil.entityVertex 按 NEW_ENTITY 完整顺序写入（含 UV1 与 Normal），
 * 否则 1.20.1 Forge 的 BufferBuilder 会在 endVertex() 抛
 * "Not filled all elements of the vertex"。混合/深度由 RenderType 管理，
 * PoseStack 用 try/finally 保证恢复。
 */
public class OrbRenderer extends EntityRenderer<SpellOrbEntity> {
    public static final ResourceLocation TEX = GeneratedMod.rl("textures/item/spell_orb.png");

    /** 广告牌四角：(x, y, u, v)。 */
    private static final float[][] CORNERS = {
        {-0.5f, -0.5f, 0f, 1f},
        { 0.5f, -0.5f, 1f, 1f},
        { 0.5f,  0.5f, 1f, 0f},
        {-0.5f,  0.5f, 0f, 0f},
    };

    public OrbRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public void render(SpellOrbEntity entity, float yaw, float partialTicks, PoseStack pose, MultiBufferSource buffer, int light) {
        pose.pushPose();
        try {
            pose.translate(0.0, entity.getBbHeight() * 0.5, 0.0);
            pose.mulPose(this.entityRenderDispatcher.cameraOrientation());
            pose.scale(0.55f, 0.55f, 0.55f);

            // 同一帧只取一次 sheet，顶点写完由 MultiBufferSource 统一提交。
            VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucentEmissive(TEX));
            int c = entity.color();
            int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            PoseStack.Pose p = pose.last();
            for (float[] q : CORNERS) {
                // 广告牌在局部 XY 平面，法线恒为 +Z。
                RenderUtil.entityVertex(vc, p, q[0], q[1], 0f, r, g, b, 255, q[2], q[3], 0f, 0f, 1f);
            }
        } finally {
            pose.popPose();
        }
        super.render(entity, yaw, partialTicks, pose, buffer, light);
    }

    @Override public ResourceLocation getTextureLocation(SpellOrbEntity entity) { return TEX; }
}
