package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.events.FamiliarEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** 残魂：怪物死亡时偶尔掉落。右键空气召唤一个永久跟随的友好使魔。 */
public class SoulFragmentItem extends Item {
    public SoulFragmentItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            boolean ok = FamiliarEvents.summonFamiliar(sl, player, player.position().add(player.getLookAngle().scale(2.0)));
            if (ok) {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.PLAYERS, 0.9f, 0.7f);
            } else {
                player.displayClientMessage(Component.literal("召唤失败：附近没有安全位置。"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override public Component getName(ItemStack stack) {
        return Component.literal("残魂").withStyle(ChatFormatting.DARK_PURPLE);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键空气：召唤一个永久跟随的使魔").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("使魔死亡后会重新掉出残魂。").withStyle(ChatFormatting.DARK_GRAY));
    }
}
