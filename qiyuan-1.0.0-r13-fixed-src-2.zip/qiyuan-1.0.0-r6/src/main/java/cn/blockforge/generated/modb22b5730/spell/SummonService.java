package cn.blockforge.generated.modb22b5730.spell;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * 基于原版生物的临时召唤系统。只由「创」触发，持续区域的重复结算不会重复召唤。
 * 不添加自定义生物模型或客户端专属 API，PC 与 FCL 使用相同原版实体。
 */
public final class SummonService {
    public static final String EXPIRES_AT = "mod_b22b5730_summon_expires_at";
    public static final String OWNER_UUID = "mod_b22b5730_summon_owner";
    private static final int MAX_SUMMONS_PER_CAST = 3;

    private enum SummonKind { IRON_GOLEM, SNOW_GOLEM, WOLF }

    private SummonService() {}

    /**
     * 召唤规则：
     * 土/金 + 创 -> 铁傀儡；冰/水 + 创 -> 雪傀儡；木或灵/魂 + 创 -> 驯服狼。
     * 其他组合不强行生成不匹配的生物，避免「创」把任意法术都变成召唤术。
     */
    public static int summon(ServerLevel level, Entity owner, List<String> runes, SpellStats stats, Vec3 impact) {
        if (level == null || owner == null || runes == null || impact == null || !runes.contains("创")) return 0;
        SummonKind kind = chooseKind(runes);
        if (kind == null) return 0;

        int tier = tierIndex(stats == null ? "" : stats.tier);
        int count = Math.min(MAX_SUMMONS_PER_CAST, tier <= 1 ? 1 : tier <= 3 ? 2 : 3);
        int lifetimeTicks = Math.min(20 * 90, 20 * (30 + tier * 10));
        List<Vec3> positions = candidatePositions(impact, count);
        int spawned = 0;
        for (Vec3 pos : positions) {
            if (spawned >= count) break;
            Mob mob = create(kind, level);
            if (mob == null) continue;
            mob.moveTo(pos.x, pos.y, pos.z, level.random.nextFloat() * 360f, 0);
            if (!level.noCollision(mob) || !level.isUnobstructed(mob)) {
                mob.discard();
                continue;
            }
            mob.getPersistentData().putLong(EXPIRES_AT, level.getGameTime() + lifetimeTicks);
            if (owner instanceof LivingEntity living) mob.getPersistentData().putUUID(OWNER_UUID, living.getUUID());
            if (mob instanceof IronGolem golem) {
                golem.setPlayerCreated(true);
            } else if (mob instanceof Wolf wolf && owner instanceof Player player) {
                wolf.tame(player);
                wolf.setOrderedToSit(false);
                wolf.setTarget(null);
            }
            if (level.addFreshEntity(mob)) {
                spawned++;
                level.sendParticles(ParticleTypes.ENCHANT, pos.x, pos.y + 0.7, pos.z, 18, 0.45, 0.6, 0.45, 0.5);
            } else {
                mob.discard();
            }
        }
        if (spawned > 0) {
            level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.EVOKER_PREPARE_SUMMON,
                SoundSource.PLAYERS, 0.8f, 0.9f + level.random.nextFloat() * 0.2f);
        }
        return spawned;
    }

    private static SummonKind chooseKind(List<String> runes) {
        if (runes.contains("土") || runes.contains("金")) return SummonKind.IRON_GOLEM;
        if (runes.contains("冰") || runes.contains("水")) return SummonKind.SNOW_GOLEM;
        if (runes.contains("木") || runes.contains("灵") || runes.contains("魂")) return SummonKind.WOLF;
        return null;
    }

    private static Mob create(SummonKind kind, ServerLevel level) {
        return switch (kind) {
            case IRON_GOLEM -> EntityType.IRON_GOLEM.create(level);
            case SNOW_GOLEM -> EntityType.SNOW_GOLEM.create(level);
            case WOLF -> EntityType.WOLF.create(level);
        };
    }

    private static List<Vec3> candidatePositions(Vec3 center, int count) {
        List<Vec3> positions = new ArrayList<>();
        positions.add(new Vec3(center.x + 1.5, center.y, center.z));
        positions.add(new Vec3(center.x - 1.5, center.y, center.z));
        positions.add(new Vec3(center.x, center.y, center.z + 1.5));
        positions.add(new Vec3(center.x, center.y, center.z - 1.5));
        positions.add(new Vec3(center.x + 1.1, center.y, center.z + 1.1));
        positions.add(new Vec3(center.x - 1.1, center.y, center.z - 1.1));
        return positions;
    }

    public static boolean isTemporarySummon(Entity entity) {
        return entity != null && entity.getPersistentData().contains(EXPIRES_AT);
    }

    /** 识别施法者自己的临时召唤物，避免召唤法术的范围结算误伤新召唤的单位。 */
    public static boolean isOwnedBy(Entity entity, Entity owner) {
        if (entity == null || owner == null || !isTemporarySummon(entity)) return false;
        var data = entity.getPersistentData();
        return data.hasUUID(OWNER_UUID) && data.getUUID(OWNER_UUID).equals(owner.getUUID());
    }

    /** 在服务端实体 tick 中调用；超时后以原版粒子淡出，不留下永久召唤物。 */
    public static void tickTemporarySummon(LivingEntity entity) {
        if (entity.level().isClientSide || !(entity.level() instanceof ServerLevel level)) return;
        var data = entity.getPersistentData();
        if (!data.contains(EXPIRES_AT)) return;
        if (level.getGameTime() < data.getLong(EXPIRES_AT)) return;
        level.sendParticles(ParticleTypes.POOF, entity.getX(), entity.getY() + entity.getBbHeight() * 0.5,
            entity.getZ(), 14, 0.35, 0.45, 0.35, 0.04);
        level.playSound(null, entity.getX(), entity.getY(), entity.getZ(), SoundEvents.FIRE_EXTINGUISH,
            SoundSource.NEUTRAL, 0.5f, 1.2f);
        entity.discard();
    }

    private static int tierIndex(String tier) {
        if (tier == null) return 1;
        if (tier.contains("禁忌")) return 6;
        if (tier.contains("五阶")) return 5;
        if (tier.contains("四阶")) return 4;
        if (tier.contains("三阶")) return 3;
        if (tier.contains("二阶")) return 2;
        return 1;
    }
}
