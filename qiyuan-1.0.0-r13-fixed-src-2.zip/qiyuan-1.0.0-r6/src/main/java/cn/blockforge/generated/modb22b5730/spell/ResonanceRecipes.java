package cn.blockforge.generated.modb22b5730.spell;

import java.util.Map;
import java.util.TreeMap;

/**
 * 共鸣配方：两个已解锁符文在共鸣台上做实验，有概率"悟"出隐藏术式。
 * key 按字母序排序后拼接，所以 火+风 和 风+火 是同一个配方。
 */
public final class ResonanceRecipes {
    public record Recipe(String displayName, String runeString) {}

    private static final Map<String, Recipe> TABLE = new TreeMap<>();

    static {
        put("火", "风",   "焰刃风暴", "视·火·风·灭·刃");
        put("水", "冰",   "冰墓",     "视·水·冰·缚·雾");
        put("雷", "金",   "连锁闪电", "视·雷·金·灭·链");
        put("暗", "魂",   "怨魂弹",   "视·暗·魂·蚀·弹");
        put("光", "愈",   "自愈光环", "己·光·愈·续");
        put("火", "灭",   "天降火雨", "视·火·灭·雨");
        put("风", "引",   "引力漩涡", "视·风·引·涡");
        put("土", "创",   "岩柱天降", "视·土·创·柱");
        put("木", "愈",   "生长领域", "域·木·愈·续");
        put("时", "瞬",   "时空折跃", "己·传·门·瞬");
    }

    private static void put(String a, String b, String name, String runes) {
        String key = key(a, b);
        TABLE.put(key, new Recipe(name, runes));
    }

    private static String key(String a, String b) {
        return a.compareTo(b) <= 0 ? a + "·" + b : b + "·" + a;
    }

    /** 查配方；没命中返回 null。 */
    public static Recipe lookup(String a, String b) {
        return TABLE.get(key(a, b));
    }

    public static int totalRecipes() { return TABLE.size(); }

    private ResonanceRecipes() {}
}
