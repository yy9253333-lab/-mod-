package cn.blockforge.generated.modb22b5730.data;

import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/**
 * 玩家自身的《祈愿》数据：魔力、已收集符文、当前刻印术式、10 个预制槽、冷却与引导进度。
 * 全部写入玩家的 persistent data（随玩家存档保存，不依赖外部存储）。
 */
public final class PrayerData {
    public static final String TAG = "prayer";
    public static final int PRESET_SLOTS = 10;
    public static final int RECENT_SLOTS = 3;

    public static CompoundTag of(Player player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(TAG, Tag.TAG_COMPOUND)) root.put(TAG, new CompoundTag());
        CompoundTag t = root.getCompound(TAG);
        if (!t.contains("mana")) t.putInt("mana", 150);
        return t;
    }

    public static int mana(Player player) { return of(player).getInt("mana"); }
    /** 创造符文只需获得一次，解锁状态保存在玩家数据中。 */
    public static boolean creativeUnlocked(Player player) { return of(player).getBoolean("creative_unlocked"); }
    public static void unlockCreative(Player player) {
        CompoundTag t = of(player);
        t.putBoolean("creative_unlocked", true);
        Set<String> all = new LinkedHashSet<>(everHadStored(player));
        all.addAll(Runes.DATA.keySet());
        StringBuilder sb = new StringBuilder();
        for (String r : all) { if (sb.length() > 0) sb.append('|'); sb.append(r); }
        t.putString("ever", sb.toString());
    }
    private static Set<String> everHadStored(Player player) {
        Set<String> out = new LinkedHashSet<>();
        for (String r : of(player).getString("ever").split("\\|")) if (Runes.contains(r)) out.add(r);
        return out;
    }
    public static int maxMana(Player player) { return Math.min(1000, 150 + 25 * Math.min(34, player.experienceLevel)); }
    public static void addMana(Player player, int amount) {
        CompoundTag t = of(player);
        t.putInt("mana", Math.max(0, Math.min(maxMana(player), t.getInt("mana") + amount)));
    }
    public static boolean spendMana(Player player, int amount) {
        if (creativeUnlocked(player)) return true;
        if (mana(player) < amount) return false;
        addMana(player, -amount);
        return true;
    }

    /** 已收集（曾经拥有过）的符文，用于解锁组阵界面。 */
    public static Set<String> everHad(Player player) {
        if (creativeUnlocked(player)) return new LinkedHashSet<>(Runes.DATA.keySet());
        String s = of(player).getString("ever");
        Set<String> out = new LinkedHashSet<>();
        for (String r : s.split("\\|")) if (Runes.contains(r)) out.add(r);
        return out;
    }

    public static boolean scanInventory(Player player) {
        if (!creativeUnlocked(player)) {
            for (ItemStack stack : player.getInventory().items) {
                if (!stack.isEmpty() && stack.is(cn.blockforge.generated.modb22b5730.GeneratedMod.CREATION_RUNE.get())) {
                    unlockCreative(player);
                    return true;
                }
            }
        }
        Set<String> ever = everHad(player);
        boolean changed = false;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() instanceof RuneItem ri) {
                if (ever.add(ri.def().rune)) changed = true;
            }
        }
        if (changed && !creativeUnlocked(player)) {
            StringBuilder sb = new StringBuilder();
            for (String r : ever) { if (sb.length() > 0) sb.append('|'); sb.append(r); }
            of(player).putString("ever", sb.toString());
        }
        return changed;
    }

    public static String active(Player player) { return of(player).getString("active"); }
    public static void setActive(Player player, String runes) { of(player).putString("active", runes == null ? "" : runes); }

    /** 最近一次成功刻印的符文组合；独立于最近施放历史与当前编辑状态保存。 */
    public static String lastEngraved(Player player) {
        CompoundTag data = of(player);
        String saved = data.getString("last_engraved");
        // 旧存档没有独立字段时，使用当前刻印作为兼容回退。
        return saved.isEmpty() ? data.getString("active") : saved;
    }
    public static void setLastEngraved(Player player, String runes) {
        List<String> parsed = parse(runes);
        if (parsed.isEmpty()) return;
        of(player).putString("last_engraved", String.join("·", parsed));
    }

    public static long cooldownEnd(Player player) { return of(player).getLong("cooldown"); }
    public static void setCooldownEnd(Player player, long v) { of(player).putLong("cooldown", v); }

    /** 最近成功施放的三个术式，最新的在索引 0；只返回仍可解析的符文串。 */
    public static List<String> recent(Player player) {
        List<String> out = new ArrayList<>();
        ListTag stored = of(player).getList("recent", Tag.TAG_STRING);
        for (int i = 0; i < stored.size() && out.size() < RECENT_SLOTS; i++) {
            List<String> parsed = parse(stored.getString(i));
            if (parsed.isEmpty()) continue;
            String canonical = String.join("·", parsed);
            if (!out.contains(canonical)) out.add(canonical);
        }
        return out;
    }

    public static void rememberRecent(Player player, String runeString) {
        List<String> parsed = parse(runeString);
        if (parsed.isEmpty()) return;
        String canonical = String.join("·", parsed);
        List<String> values = recent(player);
        values.remove(canonical);
        values.add(0, canonical);
        ListTag stored = new ListTag();
        for (int i = 0; i < Math.min(RECENT_SLOTS, values.size()); i++)
            stored.add(StringTag.valueOf(values.get(i)));
        of(player).put("recent", stored);
    }

    public static boolean guideDone(Player player) { return of(player).getBoolean("guide"); }
    public static void setGuideDone(Player player) { of(player).putBoolean("guide", true); }

    public static List<String[]> presets(Player player) {
        ListTag list = of(player).getList("presets", Tag.TAG_COMPOUND);
        List<String[]> out = new ArrayList<>();
        for (int i = 0; i < PRESET_SLOTS; i++) out.add(new String[]{"", ""});
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            int slot = c.getInt("slot");
            if (slot >= 0 && slot < PRESET_SLOTS) out.set(slot, new String[]{c.getString("name"), c.getString("runes")});
        }
        return out;
    }

    public static void savePreset(Player player, int slot, String name, String runes) {
        List<String[]> all = presets(player);
        all.set(slot, new String[]{name, runes});
        writePresets(player, all);
    }

    public static void deletePreset(Player player, int slot) {
        List<String[]> all = presets(player);
        all.set(slot, new String[]{"", ""});
        writePresets(player, all);
    }

    private static void writePresets(Player player, List<String[]> all) {
        ListTag list = new ListTag();
        for (int i = 0; i < PRESET_SLOTS; i++) {
            if (all.get(i)[1].isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putInt("slot", i);
            c.putString("name", all.get(i)[0]);
            c.putString("runes", all.get(i)[1]);
            list.add(c);
        }
        of(player).put("presets", list);
    }

    /** 发给客户端的同步包内容。 */
    public static CompoundTag syncTag(Player player) {
        CompoundTag t = new CompoundTag();
        t.putInt("mana", mana(player));
        t.putInt("max", maxMana(player));
        t.putBoolean("creative", creativeUnlocked(player));
        t.putString("ever", of(player).getString("ever"));
        t.putString("active", active(player));
        t.putString("last_engraved", lastEngraved(player));
        t.putLong("cooldown", cooldownEnd(player));
        t.putBoolean("guide", guideDone(player));
        t.putLong("gameTime", player.level().getGameTime());
        ListTag recent = new ListTag();
        for (String rune : recent(player)) recent.add(StringTag.valueOf(rune));
        t.put("recent", recent);
        ListTag presets = new ListTag();
        List<String[]> all = presets(player);
        for (int i = 0; i < PRESET_SLOTS; i++) {
            CompoundTag c = new CompoundTag();
            c.putInt("slot", i);
            c.putString("name", all.get(i)[0]);
            c.putString("runes", all.get(i)[1]);
            presets.add(c);
        }
        t.put("presets", presets);
        return t;
    }

    public static List<String> parse(String runeString) {
        List<String> out = new ArrayList<>();
        if (runeString == null || runeString.isEmpty() || runeString.length() > 1024) return out;
        String[] tokens = runeString.split("·", -1);
        if (tokens.length > 64) return out;
        for (String r : tokens) {
            if (!Runes.contains(r)) return new ArrayList<>(); // 未知符文整串拒绝，避免静默变成另一种法术
            out.add(r);
        }
        return out;
    }

    private PrayerData() {}
}
