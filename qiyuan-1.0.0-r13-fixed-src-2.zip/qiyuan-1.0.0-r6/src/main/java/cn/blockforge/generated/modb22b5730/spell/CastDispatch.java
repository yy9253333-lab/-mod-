package cn.blockforge.generated.modb22b5730.spell;

import java.util.*;

/**
 * 术式类型分派系统（符文驱动分派表）。
 *
 * 施法方式不再由 SpellCaster 里一长串 if/else 决定，而是查这张表：
 * 按 目标符文 + 效果符文 + 形态符文 组合映射到施法方式（CastMode）。
 * 扩展新玩法 = 往 TABLE 里加一行表项，不需要动施法流程代码。
 *
 * 表项匹配规则：从上到下，第一个「所有已声明条件都被当前符文组合满足」的表项生效；
 * 未声明（空集）的条件视为通配。表尾有兜底项，任何合法术式必有分派结果。
 */
public final class CastDispatch {

    /** 施法方式。 */
    public enum Mode {
        /** 自身系：法阵在脚下生成，效果直接作用于施法者（“己”目标白名单专属）。 */
        SELF_GROUND,
        /** 闪现：自身 + 传，向视线方向瞬移。 */
        BLINK,
        /** 接触式：准星命中点即结算（触）。 */
        TOUCH,
        /** 投射物：发射法术飞弹（弹/刃/刺/链/涡/潮 等飞行形态）。 */
        PROJECTILE,
        /** 定点式：准星射线命中处直接结算（壁/环/柱/网/雨/雾 与领域/群体）。 */
        POINT
    }

    /** 一条分派规则：三个条件集各自"空=通配"，非空=命中任一即可。 */
    private static final class Rule {
        final Set<String> anyTargets, anyEffects, anyForms;
        final Mode mode;
        Rule(Set<String> targets, Set<String> effects, Set<String> forms, Mode mode) {
            this.anyTargets = targets; this.anyEffects = effects; this.anyForms = forms; this.mode = mode;
        }
        boolean matches(Set<String> targets, Set<String> effects, Set<String> forms) {
            return hit(anyTargets, targets) && hit(anyEffects, effects) && hit(anyForms, forms);
        }
        private static boolean hit(Set<String> want, Set<String> have) {
            if (want.isEmpty()) return true;
            for (String w : want) if (have.contains(w)) return true;
            return false;
        }
    }

    /** 投射类形态：与网页生成器口径一致的"会飞出去"的形态符文。 */
    public static final Set<String> PROJECTILE_FORMS = Set.of("弹", "刃", "刺", "链", "涡", "潮");

    /**
     * 分派表（顺序即优先级）。想加新分派：在这张表里插一行。
     * 例：以后要做"群体+传=群体传送"，就加
     * new Rule(Set.of("群"), Set.of("传"), Set.of(), Mode.GROUP_BLINK)。
     */
    private static final List<Rule> TABLE = List.of(
        new Rule(Set.of("己"), Set.of("传"), Set.of(), Mode.BLINK),          // 自身 + 传 → 闪现
        new Rule(Set.of("己"), Set.of(), Set.of(), Mode.SELF_GROUND),        // “己”目标 → 脚下法阵（白名单）
        new Rule(Set.of("触"), Set.of(), Set.of(), Mode.TOUCH),              // 接触式 → 命中点即结算
        new Rule(Set.of(), Set.of(), PROJECTILE_FORMS, Mode.PROJECTILE),     // 飞行形态 → 投射物
        new Rule(Set.of(), Set.of(), Set.of(), Mode.POINT)                   // 兜底：定点射线结算
    );

    /**
     * “己”目标符文判定白名单：仅当术式以自身为目标（或没写目标，默认自身）时，
     * 才允许在脚下生成地面法阵；含“视”的术式按准星命中位置生成世界法阵。
     */
    public static boolean isSelfTarget(List<String> targets) {
        if (targets == null || targets.isEmpty()) return true;
        // “视”优先于“己”，避免“己 + 视”被误判为自身法阵。
        return !targets.contains("视") && targets.contains("己");
    }

    /** 查表分派：输入已分好组的符文，输出施法方式。 */
    public static Mode decide(List<String> targets, List<String> effects, List<String> forms) {
        Set<String> t = new HashSet<>(targets), e = new HashSet<>(effects), f = new HashSet<>(forms);
        // 没写目标符文的术式按“己”处理（与旧版施法语义保持一致）。
        // 若同时选择“己”和“视”，以“视”为准：法阵与结算位置必须跟随准星命中点，
        // 不能被 SELF_GROUND 规则抢先分派到玩家脚下。投射形态仍保留 PROJECTILE 分派。
        if (t.contains("视")) t.remove("己");
        if (t.isEmpty()) t.add("己");
        for (Rule r : TABLE) if (r.matches(t, e, f)) return r.mode;
        return Mode.POINT; // 理论上到不了：表尾有全通配兜底
    }

    private CastDispatch() {}
}
