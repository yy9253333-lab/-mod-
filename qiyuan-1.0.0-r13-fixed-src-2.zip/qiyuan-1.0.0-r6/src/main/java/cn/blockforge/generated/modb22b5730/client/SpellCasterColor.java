package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;

final class SpellCasterColor {
    static int current() {
        return SpellCaster.primaryColor(PrayerData.parse(PrayerState.active));
    }
    private SpellCasterColor() {}
}
