package cn.blockforge.generated.modb22b5730.client;

/**
 * 施法前不渲染常驻视野法阵。法阵只能由 SpellCaster 在实际施法成功后创建为
 * SpellCircleEntity，避免仅拿出法杖/法书或打开界面时出现凭空法阵。
 */
public final class ViewCircleRenderer {
    private ViewCircleRenderer() {}
}
