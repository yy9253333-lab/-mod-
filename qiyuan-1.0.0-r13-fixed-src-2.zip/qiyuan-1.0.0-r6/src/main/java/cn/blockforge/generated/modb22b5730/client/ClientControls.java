package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 键盘与滚轮只发请求；当前术式始终由服务器校验并同步。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientControls {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.screen != null || !AimTracker.holdsCastingFocus(mc.player)) {
            while (ClientKeyMappings.PREVIOUS.consumeClick()) { }
            while (ClientKeyMappings.NEXT.consumeClick()) { }
            return;
        }
        if (ClientKeyMappings.PREVIOUS.consumeClick()) PrayerNet.sendCycleRecent(-1);
        if (ClientKeyMappings.NEXT.consumeClick()) PrayerNet.sendCycleRecent(1);
    }

    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !AimTracker.holdsCastingFocus(mc.player)) return;
        double amount = event.getScrollDelta();
        if (amount == 0) return;
        PrayerNet.sendCycleRecent(amount > 0 ? -1 : 1);
        event.setCanceled(true); // 手持法杖/魔导书时用于换术式，不切换物品栏格子
    }

    private ClientControls() {}
}
