package cn.blockforge.generated.modb22b5730.array;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.rune.RuneGroup;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import java.util.ArrayList;
import java.util.List;

/** 把模组中文符文转换为附加法阵贴图包使用的资源路径。 */
public final class RuneArrayLayout {
    private RuneArrayLayout() {}

    public static ArrayParameters build(String runeString, double radius, int buildTicks) {
        List<String> core = new ArrayList<>();
        List<String> elements = new ArrayList<>();
        List<String> forms = new ArrayList<>();
        List<String> resists = new ArrayList<>();
        for (String rune : PrayerData.parse(runeString)) {
            Runes.Def def = Runes.get(rune);
            if (def == null) continue;
            String id = switch (def.group) {
                case ELEMENT -> elementId(rune);
                case ANCIENT -> "ancient/" + ancientId(rune);
                case EFFECT -> "effect/" + effectId(rune);
                case FORM -> "form/" + formId(rune);
                case RESISTANCE -> "resistance/" + resistanceId(rune);
                default -> null;
            };
            if (id == null) continue;
            switch (def.group) {
                case ELEMENT -> elements.add(id);
                case ANCIENT, EFFECT -> core.add(id);
                case FORM -> forms.add(id);
                case RESISTANCE -> resists.add(id);
                default -> { }
            }
        }
        return ArrayParameters.build(CastAnchor.DEFAULT, Math.max(0.25, radius), Math.max(1, buildTicks),
            core, elements, forms, resists);
    }

    private static String elementId(String rune) {
        return switch (rune) {
            case "火" -> "element/fire"; case "水" -> "element/water"; case "风" -> "element/wind";
            case "土" -> "element/earth"; case "雷" -> "element/thunder"; case "冰" -> "element/ice";
            case "木" -> "element/wood"; case "金" -> "element/metal"; case "光" -> "element/light";
            case "暗" -> "element/dark"; default -> null;
        };
    }
    private static String ancientId(String rune) {
        return switch (rune) {
            case "源" -> "source"; case "空" -> "void"; case "时" -> "time"; case "界" -> "realm";
            case "魂" -> "soul"; case "契" -> "pact"; case "忆" -> "memory"; case "门" -> "gate";
            default -> "source";
        };
    }
    private static String effectId(String rune) {
        return switch (rune) {
            case "创" -> "create"; case "灭" -> "destroy"; case "缚" -> "bind"; case "解" -> "release";
            case "愈" -> "heal"; case "蚀" -> "corrode"; case "传" -> "transfer"; case "封" -> "seal";
            case "引" -> "attract"; case "斥" -> "repel"; case "幻" -> "illusion"; case "真" -> "truth";
            default -> "truth";
        };
    }
    private static String formId(String rune) {
        return switch (rune) {
            case "弹" -> "bolt"; case "刃" -> "blade"; case "壁" -> "wall"; case "环" -> "ring";
            case "柱" -> "pillar"; case "网" -> "net"; case "链" -> "chain"; case "雨" -> "rain";
            case "雾" -> "mist"; case "刺" -> "spike"; case "涡" -> "vortex"; case "潮" -> "tide";
            default -> "ring";
        };
    }
    private static String resistanceId(String rune) {
        return switch (rune) {
            case "物抗" -> "physical"; case "法抗" -> "magic"; case "火抗" -> "fire";
            case "水抗" -> "water"; case "风抗" -> "wind"; case "土抗" -> "earth";
            case "雷抗" -> "thunder"; case "冰抗" -> "ice"; case "木抗" -> "wood";
            case "金抗" -> "metal"; case "光抗" -> "light"; case "暗抗" -> "dark";
            default -> "magic";
        };
    }
}
