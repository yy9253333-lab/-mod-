package cn.blockforge.generated.modb22b5730.rune;

public record RuneDef(String rune, RuneGroup group, String description, int damage, int mana, int sustain, int rarity, int color) {}
