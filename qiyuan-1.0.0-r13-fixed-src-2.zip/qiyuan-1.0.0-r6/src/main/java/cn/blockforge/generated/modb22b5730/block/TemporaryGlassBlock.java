package cn.blockforge.generated.modb22b5730.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** 限时魔法屏障：沿用原版玻璃外观，无法被正常破坏，到期后自动消失。 */
public final class TemporaryGlassBlock extends GlassBlock {
    public TemporaryGlassBlock() {
        super(BlockBehaviour.Properties.copy(Blocks.GLASS).strength(-1.0F, 3600000.0F));
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // 屏障只会放入原本为空气的位置，因此到期后安全恢复为空气，不会覆盖原有方块。
        if (level.getBlockState(pos).is(this)) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
    }
}
