package cn.blockforge.generated.modb22b5730.array;

/** 法阵公式：角度、节点坐标、旋转、构建进度。全部是纯函数。 */
public final class ArrayMath {
    private ArrayMath() {}

    /** 第 i 个节点（共 n 个）的罗盘角（度，正北 0 顺时针）。θ = θ0 + 360·i/n */
    public static double nodeCompassDeg(double theta0Deg, int i, int n) {
        return normalizeDeg(theta0Deg + 360.0 * i / Math.max(1, n));
    }

    /** 罗盘角 + 半径(格) -> 相对法阵中心的世界偏移。MC：北 = -Z，东 = +X。返回 {dx, dz}。 */
    public static double[] nodeOffset(double compassDeg, double radiusBlocks) {
        double a = Math.toRadians(compassDeg);
        return new double[]{radiusBlocks * Math.sin(a), -radiusBlocks * Math.cos(a)};
    }

    /** 贴图像素半径 -> 世界格半径。 */
    public static double pxToBlocks(double px, ArrayParameters p) {
        return px * p.worldRadius() / ArrayParameters.FRAME_RADIUS;
    }

    /** 构建进度 0..1。age 单位 tick，partial 为渲染插值。 */
    public static double progress(double ageTicks, int buildTicks) {
        return clamp(ageTicks / Math.max(1, buildTicks), 0, 1);
    }

    /**
     * 构建期转速倍率：刚开始转得快，完成后回到 1。（默认设计，可按需替换）
     * speed = 1 + boost · (1 - p)²
     */
    public static double buildSpeedMultiplier(double progress, double boost) {
        double q = 1 - clamp(progress, 0, 1);
        return 1 + boost * q * q;
    }

    /**
     * 某层当前旋转角（度）。转速 s(p)=1+boost·(1-p)²，对时间积分得闭式解，
     * 这样倍率随进度变化时角度连续，不会在构建完成瞬间跳变：
     * 构建期 seconds = t_b·(p + boost·(1-(1-p)³)/3)；构建完成后每秒增加 1 秒。
     */
    public static double layerAngleDeg(ArrayLayer layer, double ageTicks, int buildTicks, double boost) {
        double tb = buildTicks / 20.0;
        double p = progress(ageTicks, buildTicks);
        double seconds;
        if (ageTicks <= buildTicks) {
            seconds = tb * (p + boost * (1 - Math.pow(1 - p, 3)) / 3.0);
        } else {
            seconds = tb * (1 + boost / 3.0) + (ageTicks - buildTicks) / 20.0;
        }
        return normalizeDeg(layer.direction() * layer.baseSpeed() * seconds);
    }

    /** 环层显现度：第 i 层（共 n 层）在 [i/n, (i+1)/n] 区间内淡入。 */
    public static double layerReveal(int i, int n, double progress) {
        double lo = (double) i / n, hi = (double) (i + 1) / n;
        return smoothstep(clamp((progress - lo) / (hi - lo), 0, 1));
    }

    public static double smoothstep(double t) { return t * t * (3 - 2 * t); }
    public static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    public static double normalizeDeg(double d) { d %= 360.0; return d < 0 ? d + 360.0 : d; }
}
