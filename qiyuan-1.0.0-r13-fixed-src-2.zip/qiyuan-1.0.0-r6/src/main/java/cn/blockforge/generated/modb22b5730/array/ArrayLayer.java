package cn.blockforge.generated.modb22b5730.array;

import java.util.List;

/**
 * 法阵环层。所有层共用同一块 600×600 画布，因此贴图中心天然对齐。
 *
 * @param type        层类型
 * @param ringRadius  骨架环半径（单位：贴图画布像素，原点在画布中心，最大 280）
 * @param skin        用哪张贴图当这一层的「皮肤」，如 "element/fire"
 * @param direction   +1 顺时针 / -1 逆时针
 * @param baseSpeed   基础角速度（度/秒，未乘构建倍率）
 * @param nodeSlots   该层最多容纳多少个符文/节点
 * @param runes       占据本层的符文（同类多符文共用这一层，占不同节点）
 */
public record ArrayLayer(Type type, double ringRadius, String skin, int direction,
                         double baseSpeed, int nodeSlots, List<String> runes) {
    public enum Type { CORE, ELEMENT, FORM, RESIST }
}
