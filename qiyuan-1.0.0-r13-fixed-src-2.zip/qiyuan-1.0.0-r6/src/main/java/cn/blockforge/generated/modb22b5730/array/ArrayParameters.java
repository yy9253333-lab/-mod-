package cn.blockforge.generated.modb22b5730.array;

import java.util.ArrayList;
import java.util.List;

/**
 * 一座法阵的全部参数。多个符文共用这一份参数，只有一套环层，
 * 符文按顺序占据各层的不同节点——不会「每个符文各画一套完整法阵」。
 */
public final class ArrayParameters {
    /** 画布半径（px）。贴图 600×600，中心 300。 */
    public static final double CANVAS_HALF = 300.0;
    /** 外框环半径（px）：对应世界半径 worldRadius。 */
    public static final double FRAME_RADIUS = 280.0;

    private final CastAnchor anchor;
    private final double worldRadius;      // 外框环的世界半径（格）
    private final int buildTicks;          // 构建时间（tick）
    private final List<ArrayLayer> layers;
    private final List<ArrayNode> nodes;

    public ArrayParameters(CastAnchor anchor, double worldRadius, int buildTicks,
                           List<ArrayLayer> layers, List<ArrayNode> nodes) {
        this.anchor = anchor;
        this.worldRadius = worldRadius;
        this.buildTicks = Math.max(1, buildTicks);
        this.layers = List.copyOf(layers);
        this.nodes = List.copyOf(nodes);
    }

    public CastAnchor anchor() { return anchor; }
    public double worldRadius() { return worldRadius; }
    public int buildTicks() { return buildTicks; }
    public List<ArrayLayer> layers() { return layers; }
    public List<ArrayNode> nodes() { return nodes; }

    /** 贴图四边形的世界半边长：让外框环（280px）恰好等于 worldRadius。 */
    public double quadHalfSize() { return worldRadius * CANVAS_HALF / FRAME_RADIUS; }

    /**
     * 由符文选择构建参数。同一类别的多个符文共用一个环层。
     *
     * 各列表里的符文用「类别/英文id」表示，如 "element/fire"、"effect/destroy"、"ancient/time"，
     * 与贴图路径 textures/magic/array/&lt;类别&gt;/&lt;id&gt;.png 一一对应。core 里可同时放效果与远古符文。
     */
    public static ArrayParameters build(CastAnchor anchor, double worldRadius, int buildTicks,
                                        List<String> core, List<String> elements,
                                        List<String> forms, List<String> resists) {
        List<ArrayLayer> layers = new ArrayList<>();
        List<ArrayNode> nodes = new ArrayList<>();
        // 内慢外快、奇偶反向。半径取自素材库：核心 60 / 元素 140 / 形态 210 / 抗性 258
        addLayer(layers, nodes, ArrayLayer.Type.CORE,    60,  core,     +1,  6, 6);
        addLayer(layers, nodes, ArrayLayer.Type.ELEMENT, 140, elements, -1, 10, 8);
        addLayer(layers, nodes, ArrayLayer.Type.FORM,    210, forms,    +1, 15, 12);
        addLayer(layers, nodes, ArrayLayer.Type.RESIST,  258, resists,  -1, 22, 12);
        return new ArrayParameters(anchor, worldRadius, buildTicks, layers, nodes);
    }

    private static void addLayer(List<ArrayLayer> layers, List<ArrayNode> nodes, ArrayLayer.Type type,
                                 double radius, List<String> runes,
                                 int dir, double speed, int slots) {
        if (runes == null || runes.isEmpty()) return;
        int idx = layers.size();
        int n = Math.min(runes.size(), slots);
        List<String> used = runes.subList(0, n);
        layers.add(new ArrayLayer(type, radius, used.get(0), dir, speed, slots, List.copyOf(used)));
        for (int i = 0; i < n; i++) {
            // 第 1 个符文用整环贴图当骨架；其余符文占节点。节点角度等分：θ = θ0 + 360·i/n
            nodes.add(new ArrayNode(idx, ArrayMath.nodeCompassDeg(0, i, n), ArrayNode.Kind.RUNE, used.get(i)));
        }
    }
}
