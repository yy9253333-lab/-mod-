package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** 魔素结晶：右键食用恢复 100 魔力，也是所有符文合成的基底材料。 */
public class ManaCrystalItem extends Item {
    public ManaCrystalItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int before = PrayerData.mana(player);
            PrayerData.addMana(player, 100);
            int gained = PrayerData.mana(player) - before;
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
            player.displayClientMessage(Component.literal("魔素结晶融入体内，魔力 +" + gained), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override public Component getName(ItemStack stack) { return Component.literal("魔素结晶"); }
}
