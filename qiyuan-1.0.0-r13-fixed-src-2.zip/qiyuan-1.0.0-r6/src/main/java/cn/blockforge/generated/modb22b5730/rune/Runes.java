package cn.blockforge.generated.modb22b5730.rune;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import java.util.*;

/**
 * 符文库：与《祈愿》魔法生成器网页一一对应的七大类符文。
 * 数值表（RUNE_DMG / RUNE_MANA / RUNE_SUSTAIN_MANA / 描述 / 伤害标签）全部移植自原 HTML。
 */
public final class Runes {
    public static final List<String> ORDER = List.of("target", "element", "ancient", "effect", "form", "modifier", "resistance");

    public static final class Def {
        public final String rune, itemId, desc, dmgLabel;
        public final RuneGroup group;
        public final int damage, mana, sustain, rarity, color;
        public final Item material;
        Def(String rune, String itemId, RuneGroup group, String desc, String dmgLabel, int damage, int mana, int sustain, int rarity, Item material, int color) {
            this.rune = rune; this.itemId = itemId; this.group = group; this.desc = desc; this.dmgLabel = dmgLabel;
            this.damage = damage; this.mana = mana; this.sustain = sustain; this.rarity = rarity; this.material = material; this.color = color;
        }
    }

    public static final Map<String, Def> DATA = new LinkedHashMap<>();
    public static final Map<String, List<String>> BY_GROUP = new LinkedHashMap<>();

    private static final Map<String, String> DMG = new HashMap<>();
    private static final Map<String, Integer> DMG_VAL = new HashMap<>();
    private static final Map<String, Integer> MANA = new HashMap<>();
    private static final Map<String, Integer> SUSTAIN = new HashMap<>();

    private static final Map<String, Integer> RUNE_COLORS = pairs(
        "己", 0x3D6B7C, "触", 0x5B8C9E, "视", 0x7FB6C9, "指", 0x4A7A8C, "域", 0x2E5666, "群", 0x6FA8B8, "灵", 0x9FD8E8, "物", 0x7C8B87,
        "火", 0xE2574C, "水", 0x3D9CB8, "风", 0x9FD8CB, "土", 0xB08968, "雷", 0xF2D14E, "冰", 0xA8E6FF, "木", 0x6FBF73, "金", 0xC9CDD2, "光", 0xFFE9A8, "暗", 0x5D4778,
        "源", 0xFFF0C8, "空", 0x8B2A1A, "时", 0xD4AF37, "界", 0xB08A3E, "魂", 0xC89FE2, "契", 0xE8D48A, "忆", 0xA890C8, "门", 0xFFD700,
        "创", 0xE8E4DA, "灭", 0xB04D2F, "缚", 0x7C5BA6, "解", 0x9FD8CB, "愈", 0x7ED49A, "蚀", 0x6B8E4E, "传", 0x6FB8FF, "封", 0x4A5568, "引", 0xFF9E6B, "斥", 0xFF6B6B, "幻", 0xC89FE2, "真", 0xFFF3C4,
        "弹", 0x7C9BB5, "刃", 0xD8DEE3, "壁", 0x9AA7B0, "环", 0xB8C8D8, "柱", 0x8FA9C9, "网", 0xC9D8E8, "链", 0xA8B8C8, "雨", 0x6FA8DC, "雾", 0xBFCBD4, "刺", 0xE0E8EF, "涡", 0x5D8FB0, "潮", 0x4A90A8,
        "疾", 0x7ED4FF, "缓", 0x9AA7B0, "续", 0xB08A3E, "瞬", 0x7FFFD4, "隐", 0x8899AA, "倍", 0xFF5555, "微", 0xBBBBBB, "裂", 0xFF9E6B, "锁", 0xC9CDD2, "转", 0xC89FE2, "枢", 0xB78CFF,
        "物抗", 0xB8C0C8, "法抗", 0x9B7FD4, "火抗", 0xE07A55, "水抗", 0x55A8D4, "风抗", 0x8FD4C0, "土抗", 0xB09070, "雷抗", 0xE8D060, "冰抗", 0x90D8F0, "木抗", 0x80C070, "金抗", 0xD0D4D8, "光抗", 0xFFEFA0, "暗抗", 0x7060A0);

    static {
        // ── 伤害数值表 RUNE_DMG ──
        DMG_VAL.putAll(pairs("己",4,"触",4,"视",5,"指",5,"域",8,"群",7,"灵",10,"物",4));
        DMG_VAL.putAll(pairs("火",12,"水",8,"风",10,"土",9,"雷",14,"冰",11,"木",6,"金",12,"光",10,"暗",13));
        DMG_VAL.putAll(pairs("源",0,"空",70,"时",55,"界",50,"魂",65,"契",42,"忆",35,"门",55));
        DMG_VAL.putAll(pairs("创",8,"灭",22,"缚",0,"解",0,"愈",0,"蚀",15,"传",0,"封",0,"引",7,"斥",8,"幻",0,"真",0));
        DMG_VAL.putAll(pairs("弹",7,"刃",10,"壁",0,"环",4,"柱",10,"网",3,"链",6,"雨",9,"雾",3,"刺",11,"涡",9,"潮",12));
        // ── 魔力表 RUNE_MANA ──
        MANA.putAll(pairs("己",25,"触",30,"视",35,"指",40,"域",70,"群",65,"灵",80,"物",25));
        MANA.putAll(pairs("火",45,"水",35,"风",40,"土",40,"雷",55,"冰",50,"木",35,"金",45,"光",45,"暗",50));
        MANA.putAll(pairs("源",0,"空",180,"时",160,"界",150,"魂",170,"契",130,"忆",120,"门",150));
        MANA.putAll(pairs("创",45,"灭",90,"缚",55,"解",45,"愈",50,"蚀",65,"传",70,"封",60,"引",50,"斥",50,"幻",45,"真",40));
        MANA.putAll(pairs("弹",20,"刃",25,"壁",35,"环",30,"柱",35,"网",40,"链",35,"雨",50,"雾",45,"刺",30,"涡",45,"潮",50));
        MANA.putAll(pairs("疾",15,"缓",10,"续",20,"瞬",25,"隐",15,"倍",50,"微",5,"裂",40,"锁",20,"转",20,"枢",15));
        // ── 持续消耗 RUNE_SUSTAIN_MANA ──
        SUSTAIN.putAll(pairs("域",4,"群",3,"灵",5));
        SUSTAIN.putAll(pairs("水",2,"冰",2,"木",3,"光",2,"暗",3));
        SUSTAIN.putAll(pairs("时",5,"界",4,"魂",4,"契",3,"忆",3,"门",4));
        SUSTAIN.putAll(pairs("创",4,"缚",12,"解",0,"愈",18,"蚀",15,"传",0,"封",14,"幻",12,"真",8,"灭",5,"引",10,"斥",8));
        SUSTAIN.putAll(pairs("壁",6,"环",8,"网",9,"链",8,"雨",12,"雾",10,"涡",10,"潮",9));
        // ── 伤害标签 RUNE_DMG_LABEL ──
        DMG.putAll(pairs("己","自身强化","触","接触强化","视","视线投射","指","定点强化","域","领域覆盖","群","多目标强化","灵","灵魂层强化","物","物体作用"));
        DMG.putAll(pairs("火","火焰伤害","水","水流伤害","风","风刃伤害","土","土压伤害","雷","雷击伤害","冰","冰霜伤害","木","木系伤害","金","金属伤害","光","光属性伤害","暗","暗属性伤害"));
        DMG.putAll(pairs("源","源能强化","空","虚空否定","时","时间强化","界","空间强化","魂","灵魂强化","契","契约强化","忆","记忆强化","门","空间通道"));
        DMG.putAll(pairs("创","创造伤害","灭","毁灭伤害","缚","束缚效果","解","解除效果","愈","治疗恢复","蚀","侵蚀伤害","传","传送位移","封","封锁效果","引","牵引冲击","斥","排斥冲击","幻","幻象干扰","真","显形效果"));
        DMG.putAll(pairs("弹","投射强化","刃","切割强化","壁","屏障强化","环","环形强化","柱","贯穿强化","网","范围捕捉","链","连续传导","雨","范围落击","雾","持续场","刺","穿透强化","涡","卷入冲击","潮","扩散冲击"));
        DMG.putAll(pairs("疾","施法加速","缓","延迟强化","续","持续强化","瞬","瞬发修正","隐","隐蔽修正","倍","威力强化","微","威力缩减","裂","分裂强化","锁","锁定强化","转","属性转换","枢","枢纽开阵"));

        build(RuneGroup.TARGET, "t",
            new String[]{"己","触","视","指","域","群","灵","物"},
            new String[]{"以自身为作用对象","通过接触目标","向视线方向投射","在指定坐标点","覆盖一片区域","同时作用于多个目标","作用于目标的灵魂层面","作用于无生命的物体"},
            new String[]{"ji","chu","shi","zhi","yu","qun","ling","wu"},
            new Item[]{Items.LEATHER,Items.STICK,Items.GLASS,Items.REDSTONE,Items.LAPIS_LAZULI,Items.AMETHYST_SHARD,Items.ENDER_PEARL,Items.COBBLESTONE},
            new int[]{1,1,1,1,2,2,2,1});
        build(RuneGroup.ELEMENT, "e",
            new String[]{"火","水","风","土","雷","冰","木","金","光","暗"},
            new String[]{"燃烧与热能","流动与净化与渗透","迅捷与切割与传导","承载与防御与沉重","爆裂与麻痹与贯穿","凝滞与封存与脆裂","生长与缠绕与愈合","锐利与坚硬与导电","照耀与净化与显现","吞噬与隐匿与侵蚀"},
            new String[]{"huo","shui","feng","tu","lei","bing","mu","jin","guang","an"},
            new Item[]{Items.BLAZE_POWDER,Items.PRISMARINE_SHARD,Items.FEATHER,Items.CLAY_BALL,Items.GLOWSTONE_DUST,Items.SNOWBALL,Items.OAK_SAPLING,Items.IRON_NUGGET,Items.QUARTZ,Items.INK_SAC},
            new int[]{1,1,1,1,1,1,1,1,1,1});
        build(RuneGroup.ANCIENT, "a",
            new String[]{"源","空","时","界","魂","契","忆","门"},
            new String[]{"直接调用天地间的源","否定一切术式","时间刻度·延缓/加速","空间边界·划分内外","灵魂印记·封魂/唤魂","契约约束·强制履行","记忆存储·读取/抹除","遗迹开启·通往上古"},
            new String[]{"yuan","kong","shi","jie","hun","qi","yi","men"},
            new Item[]{Items.HEART_OF_THE_SEA,Items.WITHER_SKELETON_SKULL,Items.CLOCK,Items.OBSIDIAN,Items.SOUL_SAND,Items.PAPER,Items.BOOK,Items.ENDER_EYE},
            new int[]{4,4,4,4,4,4,4,4});
        build(RuneGroup.EFFECT, "f",
            new String[]{"创","灭","缚","解","愈","蚀","传","封","引","斥","幻","真"},
            new String[]{"从无到有地构建实体","以纯粹毁灭瓦解结构","束缚并锁定","解除并净化","修复并再生","腐蚀并削弱","位移并传送","封印并隔绝","吸引并牵引","排斥并推开","制造幻象","显形并破妄"},
            new String[]{"chuang","mie","fu","jie","yu","shi","chuan","feng","yin","chi","huan","zhen"},
            new Item[]{Items.DIAMOND,Items.GUNPOWDER,Items.CHAIN,Items.BONE,Items.GOLDEN_CARROT,Items.FERMENTED_SPIDER_EYE,Items.CHORUS_FRUIT,Items.IRON_BARS,Items.TRIPWIRE_HOOK,Items.PISTON,Items.POPPY,Items.SPYGLASS},
            new int[]{1,1,1,1,1,2,2,2,1,1,1,1});
        build(RuneGroup.FORM, "m",
            new String[]{"弹","刃","壁","环","柱","网","链","雨","雾","刺","涡","潮"},
            new String[]{"球体投射·直线飞行","切割线·锋面","平面屏障·阻隔","圆形环绕·持续区域","垂直能量柱·贯穿","网状覆盖·捕捉","连续链节·传导","范围下落·密集","弥散场·持续存在","突刺·定点穿透","螺旋·吸附卷入","冲击波·扩散推压"},
            new String[]{"dan","ren","bi","huan2","zhu","wang","lian","yu2","wu2","ci","wo","chao"},
            new Item[]{Items.ARROW,Items.FLINT,Items.COBBLESTONE_WALL,Items.STRING,Items.SMOOTH_STONE_SLAB,Items.COBWEB,Items.LEAD,Items.SLIME_BALL,Items.SUGAR,Items.BAMBOO,Items.NAUTILUS_SHELL,Items.SPONGE},
            new int[]{1,1,1,1,1,1,1,2,2,2,2,2});
        build(RuneGroup.MODIFIER, "x",
            new String[]{"疾","缓","续","瞬","隐","倍","微","裂","锁","转","枢"},
            new String[]{"加速·缩短构建时间","延迟·设置触发条件","持续·延长作用时间","瞬发·无需蓄力（模组规则：无视冷却，但魔力消耗×1.6）","隐蔽·降低魔力波动","放大·威力×2消耗×3","缩减·消耗减半威力减半","分裂·术式一分为多","锁定·追踪指定目标","转换·属性相互转化","枢纽·法阵在面前升起，术式自阵中发出"},
            new String[]{"ji2","huan","xu","shun","yin","bei","wei","lie","suo","zhuan","shu"},
            new Item[]{Items.RABBIT_FOOT,Items.MOSS_BLOCK,Items.REDSTONE_BLOCK,Items.SPECTRAL_ARROW,Items.NETHER_WART,Items.GLOWSTONE,Items.PHANTOM_MEMBRANE,Items.TUFF,Items.IRON_DOOR,Items.REPEATER,Items.LODESTONE},
            new int[]{3,3,3,3,3,3,3,3,3,3,3});
        build(RuneGroup.RESISTANCE, "r",
            new String[]{"物抗","法抗","火抗","水抗","风抗","土抗","雷抗","冰抗","木抗","金抗","光抗","暗抗"},
            new String[]{"抵抗物理伤害","抵抗法术伤害","抵抗火属性伤害","抵抗水属性伤害","抵抗风属性伤害","抵抗土属性伤害","抵抗雷属性伤害","抵抗冰属性伤害","抵抗木属性伤害","抵抗金属性伤害","抵抗光属性伤害","抵抗暗属性伤害"},
            new String[]{"phys","magic","fire","water","wind","earth","thunder","ice","wood","metal","light","dark"},
            new Item[]{Items.IRON_INGOT,Items.AMETHYST_BLOCK,Items.MAGMA_CREAM,Items.DRIED_KELP_BLOCK,Items.SLIME_BLOCK,Items.TERRACOTTA,Items.LIGHTNING_ROD,Items.PACKED_ICE,Items.APPLE,Items.IRON_BLOCK,Items.SEA_LANTERN,Items.BLACKSTONE},
            new int[]{3,3,3,3,3,3,3,3,3,3,3,3});
    }

    private static void build(RuneGroup group, String prefix, String[] runes, String[] descs, String[] pinyin, Item[] mats, int[] rarities) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < runes.length; i++) {
            String r = runes[i];
            String itemId = "rune_" + prefix + "_" + pinyin[i];
            DATA.put(r, new Def(r, itemId, group, descs[i], DMG.getOrDefault(r, ""),
                DMG_VAL.getOrDefault(r, 0), MANA.getOrDefault(r, 0), SUSTAIN.getOrDefault(r, 0), rarities[i], mats[i],
                RUNE_COLORS.getOrDefault(r, 0x3D9CB8)));
            list.add(r);
        }
        BY_GROUP.put(group.id, list);
    }

    public static Def get(String rune) { return DATA.get(rune); }
    public static String groupOf(String rune) { Def d = DATA.get(rune); return d == null ? "" : d.group.id; }
    public static boolean contains(String rune) { return DATA.containsKey(rune); }
    public static List<String> all() { return new ArrayList<>(DATA.keySet()); }
    @SuppressWarnings("unchecked")
    private static <V> Map<String, V> pairs(Object... values) {
        Map<String, V> out = new HashMap<>();
        for (int i = 0; i + 1 < values.length; i += 2) out.put((String) values[i], (V) values[i + 1]);
        return out;
    }

    private Runes() {}
}
