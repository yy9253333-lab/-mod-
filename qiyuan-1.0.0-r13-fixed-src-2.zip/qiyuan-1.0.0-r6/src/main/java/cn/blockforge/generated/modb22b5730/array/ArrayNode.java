package cn.blockforge.generated.modb22b5730.array;

/**
 * 法阵节点（稳定 S / 连接 C / 辅助 A）或符文占位。
 *
 * @param layerIndex  所在环层下标
 * @param compassDeg  罗盘角：正北 0°，顺时针（东 90°），和输出器里「正北/东北/正东…」一致
 * @param kind        节点种类
 * @param runeId      占据该节点的符文（可空，表示空节点）
 */
public record ArrayNode(int layerIndex, double compassDeg, Kind kind, String runeId) {
    public enum Kind { STABLE, LINK, AUX, RUNE }
}
