package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.array.ArrayLayer;
import cn.blockforge.generated.modb22b5730.array.ArrayMath;
import cn.blockforge.generated.modb22b5730.array.ArrayNode;
import cn.blockforge.generated.modb22b5730.array.ArrayParameters;
import cn.blockforge.generated.modb22b5730.array.RuneArrayLayout;
import cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import java.util.List;

/** 世界坐标中的分层法阵；顶点写入使用完整 NEW_ENTITY 格式，由引擎统一提交。 */
public class CircleRenderer extends EntityRenderer<SpellCircleEntity> {
    private static final ResourceLocation FRAME = GeneratedMod.rl("textures/magic/array/base/frame.png");
    private static final ResourceLocation CORE = GeneratedMod.rl("textures/magic/array/base/core.png");
    private static final float[][] CORNERS = {
        {-1f, -1f, 0f, 1f}, {-1f, 1f, 0f, 0f}, {1f, 1f, 1f, 0f}, {1f, -1f, 1f, 1f}
    };

    public CircleRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override
    public void render(SpellCircleEntity entity, float yaw, float partialTicks, PoseStack pose,
                       MultiBufferSource buffer, int light) {
        // 持续区域实体只处理效果周期，不应把法阵纹理留在世界里。
        if (entity.mode() != 0) return;
        float age = entity.tickCount + partialTicks;
        float life = Math.max(1f, entity.maxLife());
        float appear = (float) ArrayMath.smoothstep(ArrayMath.clamp(age / 8.0, 0, 1));
        float fadeStart = Math.max(1f, life - 5f);
        float fadeOut = age <= fadeStart ? 1f
            : (float) ArrayMath.clamp((life - age) / Math.max(1f, life - fadeStart), 0, 1);
        float fade = Math.min(appear, fadeOut);
        if (fade <= 0.001f) return;

        // 展开时由小到大；释放阶段短暂增强，再进入末段淡出。
        float scale = 0.30f + 0.70f * appear;
        float release = (float) Math.sin(Math.PI * ArrayMath.clamp((age - (life - 10f)) / 5.0, 0, 1));
        float glow = 1.0f + 0.22f * Math.max(0f, release);

        pose.pushPose();
        try {
            // 先把水平法阵转到命中面，再沿法线抬起少许以避免与方块表面 z-fighting。
            var normal = entity.normal();
            pose.mulPose(new Quaternionf().rotationTo(0.0f, 1.0f, 0.0f,
                (float) normal.x, (float) normal.y, (float) normal.z));
            pose.translate(0.0, 0.035, 0.0);
            float deg = age * 2.4f;
            pose.mulPose(new Quaternionf(new AxisAngle4f((float) Math.toRadians(deg), 0f, 1f, 0f)));
            float half = entity.radius() * 300f / 280f * scale;
            ArrayParameters params = RuneArrayLayout.build(entity.runeString(), entity.radius(), entity.buildTicks());
            draw(FRAME, pose, buffer, half, 255, 255, 255, Math.round(Math.min(255, 175 * fade * glow)));
            List<ArrayLayer> layers = params.layers();
            double progress = ArrayMath.progress(age, params.buildTicks());
            for (int i = 0; i < layers.size(); i++) {
                ArrayLayer layer = layers.get(i);
                float alpha = (float) (fade * ArrayMath.layerReveal(i, layers.size(), progress));
                if (alpha <= 0.001f) continue;
                int a = Math.max(0, Math.min(255, Math.round(230 * alpha * glow)));
                pose.pushPose();
                try {
                    pose.translate(0, 0.005 + (i + 1) * 0.004, 0);
                    double angle = ArrayMath.layerAngleDeg(layer, age, params.buildTicks(), 3.0);
                    pose.mulPose(new Quaternionf(new AxisAngle4f((float) Math.toRadians(-angle), 0f, 1f, 0f)));
                    draw(GeneratedMod.rl("textures/magic/array/" + layer.skin() + ".png"), pose, buffer,
                        half, 255, 255, 255, a);
                    for (ArrayNode node : params.nodes()) {
                        if (node.layerIndex() != i || node.runeId().equals(layer.skin())) continue;
                        double[] off = ArrayMath.nodeOffset(node.compassDeg(),
                            ArrayMath.pxToBlocks(layer.ringRadius(), params));
                        pose.pushPose();
                        try {
                            pose.translate(off[0], 0.002, off[1]);
                            float iconHalf = Math.max(0.08f, entity.radius() * 0.18f);
                            draw(GeneratedMod.rl("textures/magic/array/" + node.runeId() + ".png"),
                                pose, buffer, iconHalf, 255, 255, 255, a);
                        } finally { pose.popPose(); }
                    }
                } finally { pose.popPose(); }
            }
            draw(CORE, pose, buffer, half, 255, 255, 255, Math.round(Math.min(255, 210 * fade * glow)));
        } finally {
            pose.popPose();
        }
    }

    private static void draw(ResourceLocation texture, PoseStack pose, MultiBufferSource buffers,
                             float half, int r, int g, int b, int alpha) {
        if (alpha <= 0) return;
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(texture));
        PoseStack.Pose p = pose.last();
        int a = Math.min(255, alpha);
        for (float[] q : CORNERS) {
            RenderUtil.entityVertex(vc, p, q[0] * half, 0f, q[1] * half, r, g, b, a,
                q[2], q[3], 0f, 1f, 0f);
        }
    }

    @Override public ResourceLocation getTextureLocation(SpellCircleEntity entity) { return FRAME; }
}
