package cn.blockforge.generated.modb22b5730.spell;

import net.minecraft.world.phys.Vec3;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务端缓存的「客户端准星射线预演」结果。
 *
 * 沉浸化施法的流程：客户端每几 tick 用与服务端完全相同的射线公式做预演，
 * 把视线方向 / 宣称距离 / 锁定实体 id 发给服务器（PrayerNet.AimSync）。
 * 服务端施法时不直接信这些值，而是用同一公式复核（见 SpellCaster.cast），
 * 只有复核通过才把命中"锁定"到客户端预演的位置/实体上——客户端负责手感，服务端负责权威。
 */
public final class AimStore {

    /** 一次客户端瞄准预演。 */
    public record Aim(Vec3 dir, double reach, int targetId, long gameTime) {}

    /** 瞄准数据有效期（tick）：超时视为客户端停更，服务端回退纯服务端射线。 */
    public static final long TTL_TICKS = 20;

    private static final Map<UUID, Aim> AIM = new ConcurrentHashMap<>();

    public static void put(UUID player, Aim aim) { AIM.put(player, aim); }

    /** 取回并校验：方向必须是有限且接近单位向量，距离必须为正；否则视为无数据。 */
    public static Aim getValid(UUID player, long nowGameTime) {
        Aim a = AIM.get(player);
        if (a == null) return null;
        long age = nowGameTime - a.gameTime();
        if (age < 0 || age > TTL_TICKS) return null;
        Vec3 d = a.dir();
        if (d == null || !Double.isFinite(d.x) || !Double.isFinite(d.y) || !Double.isFinite(d.z)) return null;
        double len = d.length();
        if (len < 0.9 || len > 1.1) return null;
        if (!Double.isFinite(a.reach()) || a.reach() <= 0 || a.reach() > 64) return null;
        return a;
    }

    public static void clear(UUID player) { AIM.remove(player); }

    private AimStore() {}
}
