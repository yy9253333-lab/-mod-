package cn.blockforge.generated.modb22b5730.rune;

public enum RuneGroup {
    TARGET("目标", "target"), ELEMENT("元素", "element"), ANCIENT("远古", "ancient"), EFFECT("效果", "effect"), FORM("形态", "form"), MODIFIER("修饰", "modifier"), RESISTANCE("抗性", "resistance");
    public final String label;
    public final String id;
    RuneGroup(String label, String id) { this.label = label; this.id = id; }
    public static RuneGroup byId(String id) { for (RuneGroup g : values()) if (g.id.equals(id)) return g; return null; }
}
