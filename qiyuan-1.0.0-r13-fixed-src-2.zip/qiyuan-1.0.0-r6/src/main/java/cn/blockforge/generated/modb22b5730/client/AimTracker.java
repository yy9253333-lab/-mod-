package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.spell.CastDispatch;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 准星射线预演（客户端侧）。
 *
 * 手持魔导书或法杖且已刻印术式时，每 4 tick 用与服务端完全相同的射线公式
 * （SpellCaster#traceAim + SpellCaster#castReach）做一次预演：记录命中点、距离与
 * 锁定实体，并上报服务端缓存（PrayerNet.AimSync）。施法瞬间服务端会用
 * 同一条射线重算复核——预演只负责手感与 HUD，结算永远以服务端为准。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AimTracker {

    /** 预演结果快照（供 HUD 与视野前法阵渲染读取；渲染线程同一线程，直接读即可）。 */
    public static Vec3 hitPos = null;
    public static double distance = -1;
    public static LivingEntity locked = null;
    public static String lockedName = "";
    public static long lastUpdateTick = 0;

    /** 当前是否处于瞄准状态：手持魔导书/法杖且已刻印合法术式。 */
    public static boolean aiming() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return false;
        if (PrayerState.active.isEmpty()) return false;
        return holdsCastingFocus(mc.player);
    }

    /** 非自身系术式才需要"视野前法阵"（“己”白名单：自身术式仍在脚下渲染地面法阵）。 */
    public static boolean viewCircleMode() {
        if (!aiming()) return false;
        return !CastDispatch.isSelfTarget(PrayerData.parse(PrayerState.active));
    }

    public static boolean holdsCastingFocus(Player player) {
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        return main.is(GeneratedMod.PRAYER_BOOK.get()) || main.is(GeneratedMod.PRAYER_STAFF.get())
            || off.is(GeneratedMod.PRAYER_BOOK.get()) || off.is(GeneratedMod.PRAYER_STAFF.get());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        // 界面打开或非瞄准状态：清空预演，避免 HUD 显示过期锁定。
        if (!aiming() || mc.screen != null) { reset(); return; }
        if (mc.level.getGameTime() % 4 != 0) return; // 节流：4 tick 一次，避免刷屏网络

        Vec3 dir = mc.player.getLookAngle();
        double reach = SpellCaster.castReach(PrayerData.parse(PrayerState.active));
        HitResult hit = SpellCaster.traceAim(mc.player, reach); // 服务端施法复核也使用同一条实体+方块射线
        hitPos = hit.getLocation();
        distance = mc.player.getEyePosition().distanceTo(hitPos);
        int targetId = -1;
        if (hit.getType() == HitResult.Type.ENTITY && hit instanceof EntityHitResult ehr
            && ehr.getEntity() instanceof LivingEntity le) {
            locked = le; lockedName = le.getDisplayName().getString(); targetId = le.getId();
        } else {
            locked = null; lockedName = "";
        }
        lastUpdateTick = mc.level.getGameTime();
        PrayerNet.sendAim(dir, reach, targetId);
    }

    /** HUD 显示用：预演结果是否新鲜（超过 1 秒视为失效）。 */
    public static boolean fresh() {
        Minecraft mc = Minecraft.getInstance();
        return hitPos != null && mc.level != null && mc.level.getGameTime() - lastUpdateTick >= 0
            && mc.level.getGameTime() - lastUpdateTick <= 20;
    }

    private static void reset() {
        hitPos = null; distance = -1; locked = null; lockedName = "";
    }

    private AimTracker() {}
}
