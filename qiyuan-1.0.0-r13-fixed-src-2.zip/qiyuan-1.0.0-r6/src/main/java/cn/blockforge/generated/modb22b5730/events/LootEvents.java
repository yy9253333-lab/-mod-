package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.Map;
import java.util.Set;

/** 地牢与结构宝箱按稀有度掉落符文：普通地牢偏基础，末地城/古城偏稀有与禁忌。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LootEvents {
    private static final Set<String> BASIC = Set.of("chests/simple_dungeon", "chests/abandoned_mineshaft", "chests/monster_room", "chests/shipwreck_treasure", "chests/ruins_bundle");
    private static final Set<String> MID = Set.of("chests/stronghold_library", "chests/nether_bridge", "chests/desert_pyramid", "chests/jungle_temple", "chests/village/village_weaponsmith", "chests/igloo_chest");
    private static final Set<String> HIGH = Set.of("chests/end_city_treasure", "chests/ancient_city", "chests/bastion_treasure", "chests/fortress_chest");

    private static final Map<Integer, int[]> WEIGHTS = Map.of(
        1, new int[]{100, 30, 6, 1},   // 基础地牢：常见多、禁忌几乎不出
        2, new int[]{60, 60, 20, 4},   // 中型结构
        3, new int[]{20, 40, 45, 12}); // 高级结构

    @SubscribeEvent
    public static void onLootLoad(LootTableLoadEvent event) {
        String name = event.getName().toString();
        String key = name.substring(name.indexOf(':') + 1);
        int tier = BASIC.contains(key) ? 1 : MID.contains(key) ? 2 : HIGH.contains(key) ? 3 : 0;
        if (tier == 0) return;
        int[] weights = WEIGHTS.get(tier);
        LootPool.Builder pool = LootPool.lootPool()
            .name("prayer_runes")
            .setRolls(ConstantValue.exactly(1))
            .when(LootItemRandomChanceCondition.randomChance(tier == 1 ? 0.45f : tier == 2 ? 0.6f : 0.8f));
        for (Runes.Def def : Runes.DATA.values()) {
            int w = weights[def.rarity - 1];
            if (w <= 0) continue;
            pool.add(LootItem.lootTableItem(RuneItem.stack(def.rune).getItem()).setWeight(w).setQuality(w));
        }
        pool.add(LootItem.lootTableItem(cn.blockforge.generated.modb22b5730.GeneratedMod.MANA_CRYSTAL.get()).setWeight(120));
        event.getTable().addPool(pool.build());
    }

    private LootEvents() {}
}
