package cn.blockforge.generated.modb22b5730.spell;

/** 一次术式推演的完整结果，数值口径与原《祈愿》魔法生成器网页一致。 */
public final class SpellStats {
    public String runeString = "";
    public String name = "未命名术式";
    public String description = "";
    public String tier = "一阶 · 学徒";
    public String array = "单环阵";
    public String damageType = "none";
    public String codexMatch = null;
    public int runeCount;
    public int stabilizers;
    public int manaTotal;
    public int manaInitial;
    public int sustainPerSecond;
    public int duration;
    public int damage;
    public int effectTotal;
    public int healing;
    public int control;
    public int utility;
    public int cooldownTicks;
    public double buildTime;
    public double accuracyBonus;
    public double resistPenetration;
    public boolean forbidden;
    public boolean flash;
    public boolean hasSource;
    public boolean hasDamage;
    public boolean valid = true;
    public String error = null;
}
