package cn.blockforge.generated.modb22b5730.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * 统一顶点写入工具。
 *
 * 本模组所有实体渲染都走 RenderType 的实体系 sheet（entityTranslucentEmissive 等），
 * 其顶点格式为 DefaultVertexFormat.NEW_ENTITY，元素顺序为：
 *   Position -> Color -> UV0 -> UV1(overlay) -> UV2(lightmap) -> Normal -> Padding(引擎自动跳过)。
 *
 * 1.20.1 Forge(47.x) 的 BufferBuilder 要求严格按顺序填满全部可写元素：
 * 元素不匹配的调用可能被忽略，随后 endVertex() 会因顶点数据未填满而失败。
 * 因而此工具统一补齐覆盖层、光照与法线字段；用户提供的截断日志没有该异常堆栈，
 * 不能据此断言它就是设备崩溃的具体原因。
 */
final class RenderUtil {
    /** 满亮度光照（block 与 sky 都拉满），配合 emissive 渲染类型得到自发光效果。 */
    private static final int FULL_BRIGHT = LightTexture.FULL_BRIGHT;

    /**
     * 按 NEW_ENTITY 完整顺序写入一个顶点（位置、RGBA、主贴图 UV、覆盖层、光照、法线）。
     * 只依赖 VertexConsumer 接口方法，老/新 BufferBuilder 实现均兼容。
     */
    static void entityVertex(VertexConsumer vc, PoseStack.Pose pose,
                             float x, float y, float z,
                             int r, int g, int b, int a,
                             float u, float v,
                             float nx, float ny, float nz) {
        // 故意逐项调用，而非依赖链式返回值；NEW_ENTITY 要求这些字段全部写入后才能结束顶点。
        vc.vertex(pose.pose(), x, y, z);
        vc.color(r, g, b, a);
        vc.uv(u, v);
        vc.overlayCoords(OverlayTexture.NO_OVERLAY);
        vc.uv2(FULL_BRIGHT);
        vc.normal(pose.normal(), nx, ny, nz);
        vc.endVertex();
    }

    private RenderUtil() {}
}
