package cn.blockforge.generated.modb22b5730;

import cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity;
import cn.blockforge.generated.modb22b5730.entity.SpellOrbEntity;
import cn.blockforge.generated.modb22b5730.block.AnchorRuneBlock;
import cn.blockforge.generated.modb22b5730.block.InscribedRuneBlock;
import cn.blockforge.generated.modb22b5730.block.ResonanceTableBlock;
import cn.blockforge.generated.modb22b5730.block.TemporaryGlassBlock;
import cn.blockforge.generated.modb22b5730.block.entity.ModBlockEntities;
import cn.blockforge.generated.modb22b5730.item.CreationRuneItem;
import cn.blockforge.generated.modb22b5730.item.InscriptionStoneItem;
import cn.blockforge.generated.modb22b5730.item.ManaCrystalItem;
import cn.blockforge.generated.modb22b5730.item.PrayerBookItem;
import cn.blockforge.generated.modb22b5730.item.PrayerStaffItem;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.item.SoulFragmentItem;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(GeneratedMod.MOD_ID)
public final class GeneratedMod {
    public static final String MOD_ID = "mod_b22b5730";
    public static ResourceLocation rl(String path) { return new ResourceLocation(MOD_ID, path); }

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<Item> PRAYER_BOOK = ITEMS.register("prayer_book", () -> new PrayerBookItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> PRAYER_STAFF = ITEMS.register("prayer_staff", () -> new PrayerStaffItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MANA_CRYSTAL = ITEMS.register("mana_crystal", () -> new ManaCrystalItem(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> CREATION_RUNE = ITEMS.register("creation_rune", () -> new CreationRuneItem(new Item.Properties().stacksTo(1)));

    // ── r6 新增：残魂、铭刻石 ──
    public static final RegistryObject<Item> SOUL_FRAGMENT = ITEMS.register("soul_fragment", () -> new SoulFragmentItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> INSCRIPTION_STONE = ITEMS.register("inscription_stone", () -> new InscriptionStoneItem(new Item.Properties().stacksTo(16)));

    /** 施法生成的限时屏障：玻璃外观、不可破坏、无掉落。 */
    public static final RegistryObject<Block> TEMPORARY_GLASS = BLOCKS.register("temporary_glass", TemporaryGlassBlock::new);

    // ── r6 新增：三个新方块 ──
    public static final RegistryObject<Block> ANCHOR_RUNE_BLOCK = BLOCKS.register("anchor_rune", AnchorRuneBlock::new);
    public static final RegistryObject<Block> RESONANCE_TABLE_BLOCK = BLOCKS.register("resonance_table", ResonanceTableBlock::new);
    public static final RegistryObject<Block> INSCRIBED_RUNE_BLOCK = BLOCKS.register("inscribed_rune", InscribedRuneBlock::new);

    // 方块对应的 BlockItem（让玩家能在物品栏拿）
    public static final RegistryObject<Item> ANCHOR_RUNE_ITEM = ITEMS.register("anchor_rune", () -> new BlockItem(ANCHOR_RUNE_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> RESONANCE_TABLE_ITEM = ITEMS.register("resonance_table", () -> new BlockItem(RESONANCE_TABLE_BLOCK.get(), new Item.Properties()));

    public static final RegistryObject<EntityType<SpellOrbEntity>> SPELL_ORB = ENTITIES.register("spell_orb", () ->
        EntityType.Builder.<SpellOrbEntity>of(SpellOrbEntity::new, MobCategory.MISC).sized(0.4f, 0.4f).clientTrackingRange(4).updateInterval(10).build("spell_orb"));
    public static final RegistryObject<EntityType<SpellCircleEntity>> SPELL_CIRCLE = ENTITIES.register("spell_circle", () ->
        EntityType.Builder.<SpellCircleEntity>of(SpellCircleEntity::new, MobCategory.MISC).sized(1f, 0.1f).clientTrackingRange(8).updateInterval(5).build("spell_circle"));

    static {
        for (Runes.Def def : Runes.DATA.values()) {
            final Runes.Def d = def;
            ITEMS.register(d.itemId, () -> new RuneItem(d, new Item.Properties().stacksTo(64)));
        }
    }

    public GeneratedMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        BLOCKS.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        PrayerNet.register();
    }

    @SuppressWarnings("unused")
    public static final RegistryObject<CreativeModeTab> PRAYER_TAB = TABS.register("prayer_tab", () -> CreativeModeTab.builder()
        .title(Component.literal("《祈愿》魔法"))
        .icon(() -> new ItemStack(PRAYER_BOOK.get()))
        .displayItems((params, output) -> {
            output.accept(new ItemStack(PRAYER_BOOK.get()));
            output.accept(new ItemStack(PRAYER_STAFF.get()));
            output.accept(new ItemStack(MANA_CRYSTAL.get()));
            output.accept(new ItemStack(CREATION_RUNE.get()));
            // r6 新道具
            output.accept(new ItemStack(SOUL_FRAGMENT.get()));
            output.accept(new ItemStack(INSCRIPTION_STONE.get()));
            output.accept(new ItemStack(ANCHOR_RUNE_ITEM.get()));
            output.accept(new ItemStack(RESONANCE_TABLE_ITEM.get()));
            for (Runes.Def def : Runes.DATA.values()) output.accept(RuneItem.stack(def.rune));
        })
        .build());
}
