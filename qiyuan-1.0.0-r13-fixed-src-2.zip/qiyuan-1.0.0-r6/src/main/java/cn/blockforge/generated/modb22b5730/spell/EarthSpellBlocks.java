package cn.blockforge.generated.modb22b5730.spell;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

/**
 * 土系术式的保守方块生成器。只在坚实地面上的空气格放置普通方块；
 * 不替换任何已有方块，不碰方块实体/容器，不调用破坏和掉落逻辑。
 * 以每次命中为单位设数量上限，避免高频持续术式大规模堆积。
 */
public final class EarthSpellBlocks {
    private static final int MAX_BLOCKS_PER_IMPACT = 9;
    private EarthSpellBlocks() {}

    public static int create(ServerLevel level, List<String> runes, SpellStats stats, Vec3 impact) {
        if (level == null || runes == null || !runes.contains("土") || impact == null) return 0;
        // 只处理包含「创」的土系术式，避免普通土属性攻击凭空建造。
        if (!runes.contains("创")) return 0;
        Block block = blockForTier(stats == null ? "" : stats.tier);
        int count = countForTier(stats == null ? "" : stats.tier);
        count = Math.min(MAX_BLOCKS_PER_IMPACT, Math.max(1, count));

        BlockPos center = BlockPos.containing(impact.x, impact.y, impact.z);
        int[][] offsets = {
            {0, 0}, {0, -1}, {0, 1}, {-1, 0}, {1, 0},
            {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
        };
        List<BlockPos> candidates = new ArrayList<>();
        BlockState state = block.defaultBlockState();
        // 对每个位置向下寻找最近的安全自然地面，支持命中生物或空中目标；最多检查 8 格。
        for (int[] offset : offsets) {
            int x = center.getX() + offset[0];
            int z = center.getZ() + offset[1];
            for (int depth = 0; depth <= 8; depth++) {
                BlockPos candidate = new BlockPos(x, center.getY() + 1 - depth, z);
                if (!level.hasChunkAt(candidate) || !level.hasChunkAt(candidate.below())) break;
                BlockPos floorPos = candidate.below();
                BlockState target = level.getBlockState(candidate);
                BlockState above = level.getBlockState(candidate.above());
                BlockState floor = level.getBlockState(floorPos);
                boolean naturalGround = floor.is(BlockTags.DIRT)
                    || floor.is(BlockTags.BASE_STONE_OVERWORLD)
                    || floor.is(BlockTags.BASE_STONE_NETHER);
                if (!target.isAir() || !above.isAir()) continue;
                if (!naturalGround || !floor.isSolidRender(level, floorPos)) continue;
                if (level.getBlockEntity(floorPos) != null
                    || level.getBlockEntity(candidate) != null
                    || level.getBlockEntity(candidate.above()) != null) continue;
                if (!state.canSurvive(level, candidate)) continue;
                candidates.add(candidate);
                break;
            }
        }

        int placed = 0;
        for (BlockPos candidate : candidates) {
            if (placed >= count) break;
            // 二次检查，以免同一批的相邻更新使目标格不再为空。
            if (!level.getBlockState(candidate).isAir()
                || !level.getBlockState(candidate.above()).isAir()
                || level.getBlockEntity(candidate.below()) != null
                || level.getBlockEntity(candidate) != null
                || level.getBlockEntity(candidate.above()) != null) continue;
            if (level.setBlock(candidate, state, Block.UPDATE_CLIENTS | Block.UPDATE_NEIGHBORS)) placed++;
        }
        return placed;
    }

    private static Block blockForTier(String tier) {
        int t = tierIndex(tier);
        if (t <= 1) return Blocks.DIRT;
        if (t == 2) return Blocks.GRAVEL;
        if (t == 3) return Blocks.COBBLESTONE;
        if (t == 4) return Blocks.STONE;
        if (t == 5) return Blocks.COBBLED_DEEPSLATE;
        return Blocks.DEEPSLATE;
    }

    private static int countForTier(String tier) {
        return switch (tierIndex(tier)) {
            case 1 -> 1;
            case 2 -> 2;
            case 3 -> 3;
            case 4 -> 5;
            case 5 -> 7;
            default -> 9;
        };
    }

    private static int tierIndex(String tier) {
        if (tier == null) return 1;
        if (tier.contains("禁忌")) return 6;
        if (tier.contains("五阶")) return 5;
        if (tier.contains("四阶")) return 4;
        if (tier.contains("三阶")) return 3;
        if (tier.contains("二阶")) return 2;
        return 1;
    }
}
