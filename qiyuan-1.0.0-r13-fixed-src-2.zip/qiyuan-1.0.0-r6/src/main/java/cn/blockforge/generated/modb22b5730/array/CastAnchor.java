package cn.blockforge.generated.modb22b5730.array;

/** 法阵定位模式。一个术式只能使用一种定位行为。 */
public enum CastAnchor {
    /** 玩家脚下：目标符文「己」。 */
    FEET,
    /** 绑定玩家视角前方约两格：目标符文「指」。 */
    VIEW,
    /** 普通瞄准：固定在射线命中位置；未选择特殊定位符文时使用。 */
    AIMED,
    /** 兼容旧存档/旧调用的默认值。 */
    DEFAULT
}
