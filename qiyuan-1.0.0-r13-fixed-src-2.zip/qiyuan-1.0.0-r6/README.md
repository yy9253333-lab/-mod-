# 《祈愿》魔法 — 模组源码

Minecraft Forge 模组完整源码（修订版 1.0.0-r5）。

## 环境要求

| 项目 | 版本 |
|---|---|
| Minecraft | 1.20.1 |
| Forge | 47.4.0 |
| Java (编译与运行) | JDK 17 |
| Gradle | 8.x（本包不含 wrapper，见下方构建步骤） |
| 映射 | official（Mojang 官方映射） |

## 构建

本 ZIP 是修订后的源码工程；由于此交付环境无法联网下载 Gradle 发行包，源码修改尚未在此处完成 Gradle 编译验证。

包内没有附带 gradle wrapper，任选一种方式：

**方式一：命令行**

```bash
# 本机已装 Gradle 8.x 的话，先生成 wrapper
gradle wrapper --gradle-version 8.7
./gradlew build
# 产物: build/libs/mod_b22b5730-1.0.0-r4.jar
```

**方式二：IDE（推荐）**

用 IntelliJ IDEA 直接「Open」本目录，等它拉取 ForgeGradle 与 Minecraft 依赖后，
运行 Gradle 任务 `build` 即可。首次构建会下载 MC 与映射，需要几分钟。

额外任务：

- `buildDesktop` —— 桌面构建（完整 build + reobf 产物）
- `buildAndroid` —— 完整 Forge 构建 + Android 禁用 API 字节码静态扫描，
  报告在 `build/reports/android-compat-report.txt`。这不是 Android 原生构建，也不等于已在 FCL/MobileGlues 实机认证。

桌面与兼容启动器加载的是同一个通用 Forge jar；Android 运行仍需在目标设备实测。

## 操作

- **祈愿法杖**：左键近战攻击，右键施放当前刻印术式，潜行右键打开法阵台/图鉴。
- **切换术式**：持法杖或魔导书时滚轮切换；键盘可用 Alt+Q / Alt+E。
- **触屏**：打开法杖的法阵台，在组阵页点击「最近施放」按钮。
- **旧魔导书操作**：保持原有潜行右键施法与打开图鉴行为。

## 法阵显示

- 施法前预览按当前刻印符文组合绘制新素材，不再使用旧的单张 `spell_circle.png` 叠底。
- 施法后法阵锚定在世界坐标，约 4 tick（0.2 秒）内快速淡出；切换手持物品不会提前删除它。
- 持续区域法术保留服务器端效果计时与结算，但不再显示长时间驻留的法阵图形。
- 法阵/法球渲染顶点按 NEW_ENTITY 格式逐字段填写，使用原版 NO_OVERLAY 与 FULL_BRIGHT 常量。
- 火、冰、水、雷、风飞弹叠加对应原版粒子表现；飞弹由自己的实体年龄控制消失。
- 「土 + 创」按术式阶位最多生成 1–9 个普通岩土方块；只放在空气格，不覆盖原有方块，不触碰方块实体/容器。
- 新增 `/qiyuan give_all_runes`：需要命令权限等级 2 且玩家处于创造模式；按已注册 RuneItem 去重发放每种符文 1 枚。

## 目录结构

```
src/main/java/cn/blockforge/generated/modb22b5730/
├── GeneratedMod.java        # Mod 入口
├── client/                  # 客户端：图鉴界面、HUD、瞄准、各类渲染器
│   ├── BookScreen.java          # 祈愿之书（图鉴）界面
│   ├── AimTracker.java          # 准星射线追踪
│   ├── ViewCircleRenderer.java  # 第一人称视野前法阵
│   └── PrayerHud.java           # 施法 HUD
├── spell/                   # 施法核心
│   ├── CastDispatch.java        # 施法方式分派表
│   ├── SpellCaster.java         # 施法流程
│   ├── CodexData.java           # 图鉴数据注册与检索
│   └── CodexHandcrafted.java    # 手工术式条目
├── rune/                    # 符文定义与分组
├── entity/                  # 法阵实体、法球实体
├── item/                    # 祈愿之书、法力水晶、符文物品
├── net/                     # 自定网络包 (PrayerNet)
├── events/                  # 玩家/命令/战利表事件
└── data/                    # 玩家 Capability 数据

src/main/resources/
├── META-INF/mods.toml       # 模组元信息
└── assets|data/mod_b22b5730/  # 贴图、模型、语言、配方
```

## 安装

把构建出的 jar 放入 `.minecraft/mods/` 即可（仅服务端不需要额外客户端支持，
单人/联机均可）。
