package cn.blockforge.generated.modb22b5730.array;

import java.util.Collection;

/** 目标符文定位规则。目标符文允许组合，具体语义由施法分派和执行阶段决定。 */
public final class CastPositionResolver {
    public static final String RUNE_SELF = "己";
    public static final String RUNE_VIEW = "指";

    private CastPositionResolver() {}

    /** 目标符文允许组合；「己＋视」由「视」优先，按准星命中点执行。 */
    public static String validate(Collection<String> runes) {
        return null;
    }

    public static CastAnchor resolve(Collection<String> runes) {
        if (runes == null || runes.isEmpty()) return CastAnchor.AIMED;
        // 「视」代表准星射线命中点，优先级高于「己」；「指」保留视线前方定位。
        if (runes.contains("视")) return CastAnchor.AIMED;
        if (runes.contains(RUNE_SELF)) return CastAnchor.FEET;
        if (runes.contains(RUNE_VIEW)) return CastAnchor.VIEW;
        return CastAnchor.AIMED;
    }
}
