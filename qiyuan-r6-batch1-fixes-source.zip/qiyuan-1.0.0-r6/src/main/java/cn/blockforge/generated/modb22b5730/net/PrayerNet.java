package cn.blockforge.generated.modb22b5730.net;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.client.BookScreen;
import cn.blockforge.generated.modb22b5730.client.PrayerState;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.AimStore;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.List;
import java.util.function.Supplier;

/** 客户端 ↔ 服务器消息：数据同步、刻印、预制槽、引导进度。 */
public final class PrayerNet {
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        GeneratedMod.rl("main"), () -> "2", "2"::equals, "2"::equals);
    private static int id = 0;

    public static void register() {
        CHANNEL.messageBuilder(Sync.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT)
            .encoder((m, buf) -> buf.writeNbt(m.tag)).decoder(buf -> new Sync(buf.readNbt()))
            .consumerMainThread((m, ctx) -> handleClient(m, ctx)).add();
        CHANNEL.messageBuilder(OpenBook.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT)
            .encoder((m, buf) -> {}).decoder(buf -> new OpenBook())
            .consumerMainThread((m, ctx) -> handleClient(m, ctx)).add();
        CHANNEL.messageBuilder(Engrave.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER)
            .encoder((m, buf) -> buf.writeUtf(m.runes)).decoder(buf -> new Engrave(buf.readUtf(2048)))
            .consumerMainThread((m, ctx) -> handleServer(m, ctx)).add();
        CHANNEL.messageBuilder(PresetOp.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER)
            .encoder((m, buf) -> { buf.writeInt(m.slot); buf.writeUtf(m.name, 64); buf.writeUtf(m.runes, 2048); })
            .decoder(buf -> new PresetOp(buf.readInt(), buf.readUtf(64), buf.readUtf(2048)))
            .consumerMainThread((m, ctx) -> handleServer(m, ctx)).add();
        CHANNEL.messageBuilder(GuideDone.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER)
            .encoder((m, buf) -> {}).decoder(buf -> new GuideDone())
            .consumerMainThread((m, ctx) -> handleServer(m, ctx)).add();
        CHANNEL.messageBuilder(RecentSelect.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER)
            .encoder((m, buf) -> { buf.writeBoolean(m.cycle()); buf.writeInt(m.value()); })
            .decoder(buf -> new RecentSelect(buf.readBoolean(), buf.readInt()))
            .consumerMainThread((m, ctx) -> handleServer(m, ctx)).add();
        // 准星射线预演（客户端 → 服务端）：方向 + 宣称距离 + 锁定实体 id。
        // 服务端只把它当「提示」，施法时用相同公式重算复核（SpellCaster.resolveAim）。
        CHANNEL.messageBuilder(AimSync.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_SERVER)
            .encoder((m, buf) -> { buf.writeDouble(m.dir.x); buf.writeDouble(m.dir.y); buf.writeDouble(m.dir.z);
                buf.writeDouble(m.reach); buf.writeVarInt(Math.max(-1, m.targetId)); })
            .decoder(buf -> new AimSync(new net.minecraft.world.phys.Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
                buf.readDouble(), buf.readVarInt()))
            .consumerMainThread((m, ctx) -> handleServer(m, ctx)).add();
        // 旧版施法脉冲兼容消息；当前法阵由世界坐标实体渲染，不显示常驻第一人称法阵。
        CHANNEL.messageBuilder(CastFx.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT)
            .encoder((m, buf) -> buf.writeVarInt(m.color))
            .decoder(buf -> new CastFx(buf.readVarInt()))
            .consumerMainThread((m, ctx) -> handleClient(m, ctx)).add();
    }

    // ── 消息 ──
    public record Sync(CompoundTag tag) {
        public Sync(Tag t) { this(t instanceof CompoundTag c ? c : new CompoundTag()); }
    }
    public record OpenBook() {}
    public record Engrave(String runes) {}
    /** slot >= 0 保存（delete 时 runes 传空串）；slot == -1 表示仅删除。 */
    public record PresetOp(int slot, String name, String runes) {}
    public record GuideDone() {}
    /** cycle=true 时 value 为 -1/+1；否则 value 是最近术式索引 0..2。 */
    public record RecentSelect(boolean cycle, int value) {}
    /** 客户端准星预演：dir=视线方向（单位向量），reach=宣称命中距离，targetId=锁定实体（-1 表示无）。 */
    public record AimSync(net.minecraft.world.phys.Vec3 dir, double reach, int targetId) {}
    /** 施法特效脉冲：color=术式主色，客户端在视野前点亮法阵。 */
    public record CastFx(int color) {}

    // ── 发送 ──
    public static void sync(Player player) {
        if (player instanceof ServerPlayer sp) CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new Sync(PrayerData.syncTag(sp)));
    }
    public static void openBook(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenBook());
    }
    public static void sendEngrave(String runes) { CHANNEL.sendToServer(new Engrave(runes)); }
    public static void sendPreset(int slot, String name, String runes) { CHANNEL.sendToServer(new PresetOp(slot, name, runes)); }
    public static void sendGuideDone() { CHANNEL.sendToServer(new GuideDone()); }
    public static void sendRecentSlot(int index) { CHANNEL.sendToServer(new RecentSelect(false, index)); }
    public static void sendCycleRecent(int delta) { CHANNEL.sendToServer(new RecentSelect(true, Integer.signum(delta))); }
    /** 客户端准星预演上报（节流由 AimTracker 控制）。 */
    public static void sendAim(net.minecraft.world.phys.Vec3 dir, double reach, int targetId) { CHANNEL.sendToServer(new AimSync(dir, reach, targetId)); }
    /** 服务端施法成功 → 通知客户端点亮视野前法阵。 */
    public static void castFx(ServerPlayer player, int color) { CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new CastFx(color)); }

    // ── 处理 ──
    private static void handleClient(Sync m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().setPacketHandled(true);
        ctx.get().enqueueWork(() -> PrayerState.apply(m.tag()));
    }
    private static void handleClient(OpenBook m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().setPacketHandled(true);
        ctx.get().enqueueWork(() -> Minecraft.getInstance().setScreen(new BookScreen()));
    }
    private static void handleServer(Engrave m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.setPacketHandled(true);
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null) return;
            if (m.runes() == null || m.runes().isEmpty()) { PrayerData.setActive(player, ""); sync(player); return; }
            List<String> runes = PrayerData.parse(m.runes());
            if (runes.isEmpty()) return; // 符文串无效时不清除当前刻印
            var ever = PrayerData.everHad(player);
            for (String r : runes) if (!ever.contains(r)) return; // 未收集的符文拒绝刻印
            SpellStats st = SpellCalculator.calculate(runes);
            if (!st.valid) return;
            PrayerData.setActive(player, st.runeString);
            PrayerData.setLastEngraved(player, st.runeString);
            sync(player);
        });
    }
    private static void handleServer(PresetOp m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.setPacketHandled(true);
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null || m.slot() < 0 || m.slot() >= PrayerData.PRESET_SLOTS) return;
            if (m.runes().isEmpty()) PrayerData.deletePreset(player, m.slot());
            else {
                List<String> runes = PrayerData.parse(m.runes());
                SpellStats st = SpellCalculator.calculate(runes);
                if (!st.valid) return;
                PrayerData.savePreset(player, m.slot(), m.name(), st.runeString);
            }
            sync(player);
        });
    }
    private static void handleServer(GuideDone m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.setPacketHandled(true);
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null) return;
            PrayerData.setGuideDone(player);
            sync(player);
        });
    }
    private static void handleServer(RecentSelect m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.setPacketHandled(true);
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null) return;
            List<String> recent = PrayerData.recent(player);
            if (recent.isEmpty()) return;
            int slot;
            if (m.cycle()) {
                if (m.value() != -1 && m.value() != 1) return;
                int current = recent.indexOf(PrayerData.active(player));
                slot = current < 0
                    ? (m.value() > 0 ? 0 : recent.size() - 1)
                    : Math.floorMod(current + m.value(), recent.size());
            } else {
                if (m.value() < 0 || m.value() >= recent.size()) return;
                slot = m.value();
            }
            SpellStats stats = SpellCalculator.calculate(PrayerData.parse(recent.get(slot)));
            if (!stats.valid) return;
            PrayerData.setActive(player, stats.runeString);
            sync(player);
        });
    }

    private static void handleServer(AimSync m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.setPacketHandled(true);
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player == null) return;
            // 只缓存，不做信任；施法时由 SpellCaster.resolveAim 用相同射线公式复核。
            AimStore.put(player.getUUID(), new AimStore.Aim(
                m.dir(), m.reach(), m.targetId(), player.level().getGameTime()));
        });
    }
    private static void handleClient(CastFx m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().setPacketHandled(true);
        ctx.get().enqueueWork(() -> {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            cn.blockforge.generated.modb22b5730.client.PrayerState.castPulseTick =
                mc.level == null ? 0 : mc.level.getGameTime();
            cn.blockforge.generated.modb22b5730.client.PrayerState.castPulseColor = m.color();
        });
    }

    private PrayerNet() {}
}
