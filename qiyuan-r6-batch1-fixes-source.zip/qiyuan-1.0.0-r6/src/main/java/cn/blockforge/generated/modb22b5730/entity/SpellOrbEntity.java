package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/** 法术飞弹：承载术式符文串，命中后由 SpellCaster 结算。 */
public class SpellOrbEntity extends Projectile {
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private int age;

    public SpellOrbEntity(EntityType<? extends SpellOrbEntity> type, Level level) {
        super(type, level);
    }

    public static void launch(Level level, LivingEntity shooter, List<String> runes, Vec3 dir, int color) {
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), level);
        orb.setOwner(shooter);
        orb.setPos(shooter.getEyePosition().add(dir.scale(0.6)));
        orb.entityData.set(RUNES, String.join("·", runes));
        orb.entityData.set(COLOR, color);
        orb.shoot(dir.x, dir.y, dir.z, 0.85f, 0f);
        level.addFreshEntity(orb);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(RUNES, "");
        this.entityData.define(COLOR, 0x3D9CB8);
    }

    public String runeString() { return this.entityData.get(RUNES); }
    public int color() { return this.entityData.get(COLOR); }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (age > 100) { discard(); return; }
        if (level().isClientSide) {
            var rnd = level().getRandom();
            int c = color();
            double vx = (rnd.nextDouble() - 0.5) * 0.05;
            double vy = (rnd.nextDouble() - 0.5) * 0.05;
            double vz = (rnd.nextDouble() - 0.5) * 0.05;
            level().addParticle(cn.blockforge.generated.modb22b5730.spell.SpellCaster.dust(c, 0.9f),
                getX(), getY(), getZ(), vx, vy, vz);
            // 不同元素使用原版粒子形成可见区别，飞弹生命周期仍由此实体独立控制。
            String runes = runeString();
            if (runes.contains("火")) level().addParticle(net.minecraft.core.particles.ParticleTypes.FLAME, getX(), getY(), getZ(), vx * 1.7, vy * 1.7, vz * 1.7);
            if (runes.contains("冰")) level().addParticle(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, getX(), getY(), getZ(), vx, vy, vz);
            if (runes.contains("水")) level().addParticle(net.minecraft.core.particles.ParticleTypes.BUBBLE, getX(), getY(), getZ(), vx, vy, vz);
            if (runes.contains("雷")) level().addParticle(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), vx * 2, vy * 2, vz * 2);
            if (runes.contains("风")) level().addParticle(net.minecraft.core.particles.ParticleTypes.CLOUD, getX(), getY(), getZ(), vx, vy, vz);
        } else {
            Vec3 start = position();
            Vec3 move = getDeltaMovement();
            Vec3 end = start.add(move);
            EntityHitResult ehit = ProjectileUtil.getEntityHitResult(level(), this, start, end,
                new AABB(start, end).inflate(0.6), this::canHitEntity);
            HitResult bhit = level().clip(new net.minecraft.world.level.ClipContext(start, end,
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, this));
            if (ehit != null && (bhit.getType() == HitResult.Type.MISS
                || start.distanceToSqr(ehit.getLocation()) < start.distanceToSqr(bhit.getLocation()))) {
                onHitEntity(ehit);
            } else if (bhit.getType() != HitResult.Type.MISS) {
                onHitBlock((BlockHitResult) bhit);
            }
            setPos(end);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (!level().isClientSide) {
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(),
                getDeltaMovement().lengthSqr() > 1.0e-8 ? getDeltaMovement().normalize().scale(-1) : new Vec3(0, 1, 0));
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), result.getEntity());
            discard();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (!level().isClientSide) {
            Vec3 normal = new Vec3(result.getDirection().getStepX(), result.getDirection().getStepY(), result.getDirection().getStepZ());
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(), normal);
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), null);
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("prayer_runes", runeString());
        tag.putInt("prayer_color", color());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(RUNES, tag.getString("prayer_runes"));
        entityData.set(COLOR, tag.getInt("prayer_color"));
    }
}
