package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** 法术飞弹：承载术式符文串，命中后由 SpellCaster 结算。 */
public class SpellOrbEntity extends Projectile {
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private int age;

    public SpellOrbEntity(EntityType<? extends SpellOrbEntity> type, Level level) {
        super(type, level);
    }

    public static void launch(Level level, LivingEntity shooter, List<String> runes, Vec3 dir, int color) {
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), level);
        orb.setOwner(shooter);
        orb.setPos(shooter.getEyePosition().add(dir.scale(0.6)));
        orb.entityData.set(RUNES, String.join("·", runes));
        orb.entityData.set(COLOR, color);
        orb.shoot(dir.x, dir.y, dir.z, 0.85f, 0f);
        level.addFreshEntity(orb);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(RUNES, "");
        this.entityData.define(COLOR, 0x3D9CB8);
    }

    public String runeString() { return this.entityData.get(RUNES); }
    public int color() { return this.entityData.get(COLOR); }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (age > 100) { discard(); return; }
        if (level().isClientSide) {
            var rnd = level().getRandom();
            int c = color();
            double vx = (rnd.nextDouble() - 0.5) * 0.035;
            double vy = (rnd.nextDouble() - 0.5) * 0.035;
            double vz = (rnd.nextDouble() - 0.5) * 0.035;
            // 客户端按本 tick 的实际预测位移补间生成粒子，形成沿弹道延伸的连续拖尾。
            Vec3 start = position();
            Vec3 end = start.add(getDeltaMovement());
            setPos(end);
            level().addParticle(cn.blockforge.generated.modb22b5730.spell.SpellCaster.dust(c, 0.9f),
                end.x, end.y, end.z, vx, vy, vz);
            spawnElementTrail(start, end, vx, vy, vz);
        } else {
            Vec3 start = position();
            Vec3 move = getDeltaMovement();
            Vec3 end = start.add(move);
            EntityHitResult ehit = ProjectileUtil.getEntityHitResult(level(), this, start, end,
                new AABB(start, end).inflate(0.6), this::canHitEntity);
            HitResult bhit = level().clip(new net.minecraft.world.level.ClipContext(start, end,
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, this));
            if (ehit != null && (bhit.getType() == HitResult.Type.MISS
                || start.distanceToSqr(ehit.getLocation()) < start.distanceToSqr(bhit.getLocation()))) {
                setPos(ehit.getLocation());
                onHitEntity(ehit);
                return;
            } else if (bhit.getType() != HitResult.Type.MISS) {
                setPos(bhit.getLocation());
                onHitBlock((BlockHitResult) bhit);
                return;
            }
            setPos(end);
        }
    }

    /**
     * 根据弹体当前术式中的所有元素，在本 tick 的运动线段上生成原版粒子。
     * 每个属性独立判断，因此火+雷、土+火等组合会同时显示多种拖尾。
     */
    private void spawnElementTrail(Vec3 start, Vec3 end, double vx, double vy, double vz) {
        Set<String> runes = new HashSet<>(Arrays.asList(runeString().split("·")));
        double distance = start.distanceTo(end);
        int segments = Math.max(1, Math.min(4, (int) Math.ceil(distance / 0.2)));
        for (int i = 0; i <= segments; i++) {
            double t = (double) i / segments;
            double x = start.x + (end.x - start.x) * t;
            double y = start.y + (end.y - start.y) * t;
            double z = start.z + (end.z - start.z) * t;
            spawnIfPresent(runes, "火", ParticleTypes.FLAME, x, y, z, vx * 0.7, vy * 0.7, vz * 0.7);
            spawnIfPresent(runes, "水", ParticleTypes.SPLASH, x, y, z, vx, vy, vz);
            spawnIfPresent(runes, "风", ParticleTypes.CLOUD, x, y, z, vx, vy, vz);
            if (runes.contains("土")) {
                ParticleOptions dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
                level().addParticle(dirt, x, y, z, vx * 1.5, vy * 1.5, vz * 1.5);
            }
            spawnIfPresent(runes, "雷", ParticleTypes.ELECTRIC_SPARK, x, y, z, vx * 1.5, vy * 1.5, vz * 1.5);
            spawnIfPresent(runes, "冰", ParticleTypes.SNOWFLAKE, x, y, z, vx, vy, vz);
            spawnIfPresent(runes, "木", ParticleTypes.COMPOSTER, x, y, z, vx, vy, vz);
            spawnIfPresent(runes, "金", ParticleTypes.CRIT, x, y, z, vx, vy, vz);
            spawnIfPresent(runes, "光", ParticleTypes.END_ROD, x, y, z, vx, vy, vz);
            spawnIfPresent(runes, "暗", ParticleTypes.SOUL, x, y, z, vx, vy, vz);
        }
    }

    private void spawnIfPresent(Set<String> runes, String element, ParticleOptions particle,
                                double x, double y, double z, double vx, double vy, double vz) {
        if (runes.contains(element)) level().addParticle(particle, x, y, z, vx, vy, vz);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (!level().isClientSide) {
            // 命中实体：法阵朝向与飞行方向相反（面向来袭方向）。
            Vec3 travel = getDeltaMovement();
            Vec3 normal = travel.lengthSqr() > 1.0e-8 ? travel.scale(-1).normalize() : new Vec3(0.0, 1.0, 0.0);
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(), normal);
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), result.getEntity());
            discard();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (!level().isClientSide) {
            // 命中方块：按命中面的真实法线摆放法阵。
            net.minecraft.core.Direction face = result.getDirection();
            Vec3 normal = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(), normal);
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), null);
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("prayer_runes", runeString());
        tag.putInt("prayer_color", color());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(RUNES, tag.getString("prayer_runes"));
        entityData.set(COLOR, tag.getInt("prayer_color"));
    }
}
