# 《祈愿》R6 — A 系统：锚定式永久法阵实现记录

## 本次修改

- 加固现有阵基石交互：仅允许手持祈愿法杖并潜行右键来锚定当前术式；潜行空手右键清除。
- 增加刻阵者权限校验，其他玩家不能覆盖或清除已归属的法阵。
- 将运行周期调整为每 40 游戏刻（约 2 秒）一次。
- 法阵运行与粒子视觉保持分离；视觉粒子每 5 tick 更新，不以短暂 `SpellCircleEntity` 作为持续运行载体。
- 法阵每次触发前检查术式和魔力，按基础术式魔力的 20% 扣费；魔力不足时不执行该次效果。
- 刻阵者必须在线且位于同一维度，但不限制距离；刻阵者离线或跨维度时暂停，已锚定数据保留。
- 持久化符文组合、刻阵者 UUID 和下一次触发时间；触发调度更新时标记方块实体为 dirty。
- 修正阵基石及铭刻符文板方块实体中的 `worldPos` 坐标字段引用为 Forge 1.20.1 官方映射使用的 `worldPosition`。
- 增加阵基石合成配方和破坏掉落表。
- 将构建版本、JAR 文件名及 Gradle 项目名统一为 R6。

## 文件范围

主要修改：
- `block/AnchorRuneBlock.java`
- `block/entity/AnchorRuneBlockEntity.java`
- `block/entity/InscribedRuneBlockEntity.java`（坐标字段兼容修正）
- `build.gradle`
- `settings.gradle`

新增：
- `data/mod_b22b5730/recipes/anchor_rune.json`
- `data/mod_b22b5730/loot_tables/blocks/anchor_rune.json`

## 静态检查

- `src/main/resources` 中 166 个 JSON 文件全部通过 JSON 解析检查。
- 源码中不再发现 `worldPos` / `worldPositionition` 拼写残留。
- 本运行环境没有可用的 `gradle` 命令，也没有 Gradle Wrapper，因此本次未能实际执行 Forge 编译。不得将本次结果描述为“已编译通过”。

## 需要实机验证

1. 游戏启动时阵基石方块实体是否正常注册。
2. 潜行持法杖右键锚定，潜行空手清除及权限限制。
3. 每 40 tick 触发、魔力扣除和魔力不足暂停。
4. 保存、退出、重进及区块卸载/重载后法阵恢复。
5. PC 与 Android FCL/MobileGlues 实机表现。
