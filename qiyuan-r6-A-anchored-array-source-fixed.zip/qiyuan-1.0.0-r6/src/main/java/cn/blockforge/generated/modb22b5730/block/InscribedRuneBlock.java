package cn.blockforge.generated.modb22b5730.block;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.block.entity.InscribedRuneBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * 铭刻符文板：贴在地上的薄块，怪物踩到或红石充能就触发里面刻的术式。
 * 由铭刻石在地上写入；本身不接受直接刻印。
 */
public final class InscribedRuneBlock extends Block implements EntityBlock {
    private static final VoxelShape SHAPE = box(0, 0, 0, 16, 2, 16); // 0.125 格厚

    public InscribedRuneBlock() {
        super(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_CYAN)
            .strength(0.5f, 0.5f)
            .sound(SoundType.METAL)
            .lightLevel(s -> 8)
            .noLootTable()); // 被破坏时不掉落，避免复制
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public PushReaction getPistonPushReaction(BlockState state) { return PushReaction.DESTROY; }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof InscribedRuneBlockEntity be)) return InteractionResult.PASS;
        if (be.isEngraved()) {
            player.displayClientMessage(Component.literal("铭刻符文板：" + be.runes()), true);
        } else {
            player.displayClientMessage(Component.literal("空的铭刻板。"), true);
        }
        return InteractionResult.CONSUME;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new InscribedRuneBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return (lvl, pos, st, be) -> { if (be instanceof InscribedRuneBlockEntity inscribed) inscribed.serverTick(); };
    }

    @Override
    public void playerDestroy(Level level, Player player, BlockPos pos, BlockState state,
                              BlockEntity blockEntity, ItemStack tool) {
        super.playerDestroy(level, player, pos, state, blockEntity, tool);
        if (level instanceof ServerLevel server && blockEntity instanceof InscribedRuneBlockEntity be
                && be.isEngraved()) {
            ItemStack recovered = new ItemStack(GeneratedMod.INSCRIPTION_STONE.get());
            CompoundTag tag = recovered.getOrCreateTag();
            tag.putString("engraved_runes", be.runes());
            server.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(server,
                pos.getX() + 0.5, pos.getY() + 0.25, pos.getZ() + 0.5, recovered));
        }
    }

    @Override
    public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
}
