package cn.blockforge.generated.modb22b5730.block.entity;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/**
 * 铭刻方块：把术式"贴"在地上当触发器。
 * 两种触发方式：
 *   ① 怪物/生物踩到它 （AABB 1.5 格内有非玩家 LivingEntity）
 *   ② 旁边有红石充能
 * 触发前要求原刻阵者在线且在当前维度，并扣除该术式完整基础魔力；否则不施法。
 * 触发后（包括供能失败）冷却 10 秒，避免每 tick 重复检查或连炸。
 */
public class InscribedRuneBlockEntity extends BlockEntity {
    private static final int COOLDOWN_TICKS = 200; // 10 秒
    private static final double TRIGGER_RADIUS = 1.5;

    private String runes = "";
    private UUID ownerUuid;
    private long cooldownUntil;

    public InscribedRuneBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.INSCRIBED_RUNE.get(), pos, state);
    }

    public void engrave(Player owner, String runeString) {
        this.runes = runeString == null ? "" : runeString;
        this.ownerUuid = owner == null ? null : owner.getUUID();
        this.cooldownUntil = 0;
        setChanged();
    }

    public String runes() { return runes; }
    public boolean isEngraved() { return !runes.isEmpty(); }

    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        if (now < cooldownUntil) return;
        if (!isEngraved()) return;

        boolean triggered = false;
        // ① 生物踩
        AABB box = new AABB(worldPosition).inflate(TRIGGER_RADIUS, 0.5, TRIGGER_RADIUS);
        List<LivingEntity> nearby = sl.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != null && e.isAlive() && !(e instanceof Player));
        if (!nearby.isEmpty()) triggered = true;

        // ② 红石充能
        if (!triggered && sl.hasNeighborSignal(worldPosition)) triggered = true;

        if (!triggered) return;

        List<String> parsed = PrayerData.parse(runes);
        if (parsed.isEmpty()) {
            cooldownUntil = now + COOLDOWN_TICKS;
            setChanged();
            return;
        }

        // 机关始终归属于刻阵者：主人离线或不在当前维度时暂停，不使用 null 施法者绕过伤害归属/魔力规则。
        Player owner = resolveOwner(sl);
        if (owner == null) {
            cooldownUntil = now + COOLDOWN_TICKS;
            setChanged();
            return;
        }

        SpellStats stats = SpellCalculator.calculate(parsed);
        if (!stats.valid) {
            owner.displayClientMessage(net.minecraft.network.chat.Component.literal("铭刻机关术式无效，已暂停本次触发。"), true);
            cooldownUntil = now + COOLDOWN_TICKS;
            setChanged();
            return;
        }
        // 铭刻机关每次触发消耗完整基础施法魔力；供能不足时不执行任何术式效果。
        if (!PrayerData.spendMana(owner, stats.manaTotal)) {
            owner.displayClientMessage(net.minecraft.network.chat.Component.literal(
                "铭刻机关魔力不足：需要 " + stats.manaTotal + "，现有 " + PrayerData.mana(owner) + "。"), true);
            cooldownUntil = now + COOLDOWN_TICKS;
            setChanged();
            return;
        }

        Vec3 pos = new Vec3(worldPosition.getX() + 0.5, worldPosition.getY() + 0.1, worldPosition.getZ() + 0.5);
        SpellCaster.applyZone(sl, owner, parsed, pos, false);
        cooldownUntil = now + COOLDOWN_TICKS;
        setChanged();
    }

    private Player resolveOwner(ServerLevel sl) {
        if (ownerUuid == null) return null;
        return sl.getPlayers(p -> true).stream()
            .filter(p -> p.getUUID().equals(ownerUuid))
            .findFirst().orElse(null);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("prayer_runes", runes);
        tag.putLong("prayer_cd", cooldownUntil);
        if (ownerUuid != null) tag.putUUID("prayer_owner", ownerUuid);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        runes = tag.getString("prayer_runes");
        cooldownUntil = tag.getLong("prayer_cd");
        ownerUuid = tag.hasUUID("prayer_owner") ? tag.getUUID("prayer_owner") : null;
    }
}
