package cn.blockforge.generated.modb22b5730.block.entity;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/**
 * 阵基石 BlockEntity：把刻好的术式永久保存于世界。
 * 每 40 tick（2 秒）尝试从原刻阵者身上抽取魔力并结算一次法术。
 * 原刻阵者必须在线且位于同一维度；不限制距离。主人离线或跨维度时暂停，但保留锚定数据。
 * 每次触发消耗法术基础魔力的 20%；魔力不足时暂停本次触发。
 */
public class AnchorRuneBlockEntity extends BlockEntity {
    public static final int TRIGGER_INTERVAL = 40;          // 2 秒触发一次
    private static final double EFFECT_RADIUS = 4.0;        // 法阵视觉半径

    private String runes = "";
    private UUID ownerUuid;
    private long nextTriggerAt;

    public AnchorRuneBlockEntity(BlockPos pos, BlockState state) {
        super(cn.blockforge.generated.modb22b5730.block.entity.ModBlockEntities.ANCHOR_RUNE.get(), pos, state);
    }

    public void engrave(Player owner, String runeString) {
        this.runes = runeString == null ? "" : runeString;
        this.ownerUuid = owner == null ? null : owner.getUUID();
        this.nextTriggerAt = 0;
        setChanged();
        notifyBlockUpdate();
    }

    public void clear() {
        this.runes = "";
        this.ownerUuid = null;
        this.nextTriggerAt = 0;
        setChanged();
        notifyBlockUpdate();
    }

    public boolean canEdit(Player player) {
        return ownerUuid == null || (player != null && ownerUuid.equals(player.getUUID()));
    }

    private void notifyBlockUpdate() {
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public String runes() { return runes; }
    public boolean isEngraved() { return !runes.isEmpty(); }
    public UUID owner() { return ownerUuid; }

    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();

        // 视觉效果与运行逻辑分离：每 5 tick 绘制一次，不影响 40 tick 的施法周期。
        if (now % 5 == 0) {
            int color = isEngraved() ? SpellCaster.primaryColor(PrayerData.parse(runes)) : 0x3D9CB8;
            var dust = SpellCaster.dust(color, 1.0f);
            double cx = worldPosition.getX() + 0.5;
            double cy = worldPosition.getY() + 0.15;
            double cz = worldPosition.getZ() + 0.5;
            for (int i = 0; i < 16; i++) {
                double a = i * Math.PI * 2 / 16 + now * 0.02;
                sl.sendParticles(dust, cx + Math.cos(a) * EFFECT_RADIUS, cy, cz + Math.sin(a) * EFFECT_RADIUS, 1, 0, 0, 0, 0);
            }
        }

        if (!isEngraved()) return;
        if (now < nextTriggerAt) return;

        List<String> parsed = PrayerData.parse(runes);
        if (parsed.isEmpty()) { nextTriggerAt = now + TRIGGER_INTERVAL; setChanged(); return; }

        // 只允许原刻阵者供能。主人离线时暂停，但法阵数据仍保存在方块实体中。
        Player owner = findOwner();
        if (owner == null) { nextTriggerAt = now + TRIGGER_INTERVAL; setChanged(); return; }

        SpellStats st = SpellCalculator.calculate(parsed);
        if (!st.valid) { nextTriggerAt = now + TRIGGER_INTERVAL; setChanged(); return; }

        // 扣魔力：每次触发按法术基础消耗的 20% 抽（持续法阵比单发便宜）
        int cost = Math.max(1, st.manaTotal / 5);
        if (!PrayerData.spendMana(owner, cost)) {
            // 魔力不足：粒子红一下，不触发
            if (now % 40 == 0) {
                sl.sendParticles(ParticleTypes.ANGRY_VILLAGER,
                    worldPosition.getX() + 0.5, worldPosition.getY() + 1.0, worldPosition.getZ() + 0.5, 1, 0.2, 0.3, 0.2, 0);
            }
            nextTriggerAt = now + TRIGGER_INTERVAL;
            setChanged();
            return;
        }

        // 触发法术（repeat=true，伤害衰减到 35%，适合持续场）
        Vec3 pos = new Vec3(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5);
        SpellCaster.applyAnchorZone(sl, owner, parsed, pos);
        nextTriggerAt = now + TRIGGER_INTERVAL;
        setChanged();
    }

    private Player findOwner() {
        if (!(level instanceof ServerLevel sl) || ownerUuid == null) return null;
        // 从服务器玩家列表按 UUID 查找，不限制距离；同维度限制可避免跨维度实体参与伤害归属。
        Player owner = sl.getServer().getPlayerList().getPlayer(ownerUuid);
        return owner != null && owner.level() == sl ? owner : null;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("prayer_runes", runes);
        tag.putLong("prayer_next_trigger", nextTriggerAt);
        if (ownerUuid != null) tag.putUUID("prayer_owner", ownerUuid);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        runes = tag.getString("prayer_runes");
        nextTriggerAt = tag.getLong("prayer_next_trigger");
        ownerUuid = tag.hasUUID("prayer_owner") ? tag.getUUID("prayer_owner") : null;
    }
}
