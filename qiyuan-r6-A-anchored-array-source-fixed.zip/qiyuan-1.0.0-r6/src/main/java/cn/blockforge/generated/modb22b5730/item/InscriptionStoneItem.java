package cn.blockforge.generated.modb22b5730.item;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.block.entity.InscribedRuneBlockEntity;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/** 铭刻石：拿着它右键任意方块地面，会在那块地面上放一个铭符文板，写入你当前刻印的术式。 */
public class InscriptionStoneItem extends Item {
    public InscriptionStoneItem(Properties props) { super(props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (player == null) return InteractionResult.PASS;
        BlockPos target = ctx.getClickedPos().above();

        if (!level.isClientSide) {
            String savedRunes = ctx.getItemInHand().hasTag() ? ctx.getItemInHand().getTag().getString("engraved_runes") : "";
            String active = savedRunes.isEmpty() ? PrayerData.active(player) : savedRunes;
            if (active.isEmpty()) {
                player.displayClientMessage(Component.literal("先在魔导书里刻印一个术式再来铭刻。"), true);
                return InteractionResult.FAIL;
            }
            BlockState here = level.getBlockState(target);
            if (!here.canBeReplaced()) {
                player.displayClientMessage(Component.literal("那里放不下符文板。"), true);
                return InteractionResult.FAIL;
            }
            level.setBlock(target, GeneratedMod.INSCRIBED_RUNE_BLOCK.get().defaultBlockState(), 3);
            if (level.getBlockEntity(target) instanceof InscribedRuneBlockEntity be) {
                be.engrave(player, active);
            }
            if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
            level.playSound(null, target, SoundEvents.ENCHANTMENT_TABLE_USE,
                SoundSource.PLAYERS, 0.7f, 1.3f);
            player.displayClientMessage(Component.literal("已铭刻：" + active + "（怪物踩到或红石充能触发）"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override public Component getName(ItemStack stack) {
        return Component.literal("铭刻石").withStyle(ChatFormatting.AQUA);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键方块顶面：在那里放一个符文板").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("符文板自动触发你当前刻印的术式").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("触发条件：怪物踩到 / 红石充能，冷却 10 秒").withStyle(ChatFormatting.DARK_GRAY));
    }
}
