package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 使魔系统：怪物掉残魂 → 残魂召唤永久友好使魔。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FamiliarEvents {
    /** 写在实体 persistentData 上的标记：永久使魔。 */
    public static final String FAMILIAR_OWNER = "mod_b22b5730_familiar_owner";
    private static final double DROP_CHANCE_FROM_MONSTER = 0.10;   // 普通怪 10%
    private static final double DROP_CHANCE_FROM_FAMILIAR = 0.50;  // 使魔死亡 50%
    public static final int MAX_FAMILIARS_PER_PLAYER = 5;

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead.level().isClientSide) return;
        ServerLevel sl = (ServerLevel) dead.level();

        // 使魔死亡：50% 掉残魂
        if (dead.getPersistentData().hasUUID(FAMILIAR_OWNER)) {
            if (sl.getRandom().nextDouble() < DROP_CHANCE_FROM_FAMILIAR) {
                dead.spawnAtLocation(new ItemStack(GeneratedMod.SOUL_FRAGMENT.get()));
            }
            return;
        }

        // 普通敌对怪物死亡：10% 掉残魂
        if (dead instanceof Monster && sl.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            if (sl.getRandom().nextDouble() < DROP_CHANCE_FROM_MONSTER) {
                dead.spawnAtLocation(new ItemStack(GeneratedMod.SOUL_FRAGMENT.get()));
            }
        }
    }

    /** 在 pos 召唤一个随机永久使魔；返回是否成功。 */
    public static boolean summonFamiliar(ServerLevel level, Player owner, Vec3 pos) {
        if (level == null || owner == null) return false;
        int owned = 0;
        for (net.minecraft.world.entity.Entity entity : level.getAllEntities()) {
            if (entity instanceof Mob && entity.getPersistentData().hasUUID(FAMILIAR_OWNER)
                    && owner.getUUID().equals(entity.getPersistentData().getUUID(FAMILIAR_OWNER))) owned++;
        }
        if (owned >= MAX_FAMILIARS_PER_PLAYER) {
            owner.displayClientMessage(net.minecraft.network.chat.Component.literal(
                "每位玩家最多拥有 " + MAX_FAMILIARS_PER_PLAYER + " 个使魔，请先处理已有使魔。"), true);
            return false;
        }
        int roll = level.getRandom().nextInt(4);
        Mob mob = switch (roll) {
            case 0 -> EntityType.WOLF.create(level);
            case 1 -> EntityType.CAT.create(level);
            case 2 -> EntityType.SNOW_GOLEM.create(level);
            default -> EntityType.IRON_GOLEM.create(level);
        };
        if (mob == null) return false;
        mob.moveTo(pos.x, pos.y, pos.z, level.random.nextFloat() * 360f, 0);
        if (!level.noCollision(mob)) { mob.discard(); return false; }

        mob.getPersistentData().putUUID(FAMILIAR_OWNER, owner.getUUID());
        if (mob instanceof Wolf wolf) {
            wolf.tame(owner);
            wolf.setOrderedToSit(false);
            wolf.setTarget(null);
        } else if (mob instanceof Cat cat) {
            cat.tame(owner);
            cat.setOrderedToSit(false);
        } else if (mob instanceof SnowGolem) {
            mob.goalSelector.addGoal(2, new FollowOwnerGoal(mob, owner.getUUID(), 1.1D, 3.0F, 12.0F));
        } else if (mob instanceof IronGolem golem) {
            golem.setPlayerCreated(true);
            golem.goalSelector.addGoal(2, new FollowOwnerGoal(golem, owner.getUUID(), 1.0D, 3.0F, 12.0F));
        }
        // 命名提示玩家这是谁的使魔
        mob.setCustomName(net.minecraft.network.chat.Component.literal(owner.getName().getString() + "的使魔"));

        if (level.addFreshEntity(mob)) {
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.SOUL_FIRE_FLAME,
                pos.x, pos.y + 1, pos.z, 20, 0.5, 0.7, 0.5, 0.02);
            level.playSound(null, pos.x, pos.y, pos.z,
                SoundEvents.SOUL_ESCAPE, SoundSource.NEUTRAL, 1.0f, 0.8f);
            return true;
        }
        mob.discard();
        return false;
    }

    /** 为非驯服型傀儡提供简单的主人跟随行为；主人不在线或距离过远时停止追踪。 */
    private static final class FollowOwnerGoal extends Goal {
        private final Mob mob;
        private final UUID ownerId;
        private final double speed;
        private final float startDistance;
        private final float stopDistance;
        private Player owner;

        private FollowOwnerGoal(Mob mob, UUID ownerId, double speed, float startDistance, float stopDistance) {
            this.mob = mob; this.ownerId = ownerId; this.speed = speed;
            this.startDistance = startDistance; this.stopDistance = stopDistance;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }
        @Override public boolean canUse() {
            if (!(mob.level() instanceof ServerLevel sl)) return false;
            owner = sl.getPlayerByUUID(ownerId);
            return owner != null && owner.isAlive() && mob.distanceToSqr(owner) > startDistance * startDistance
                && mob.distanceToSqr(owner) <= stopDistance * stopDistance;
        }
        @Override public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && mob.distanceToSqr(owner) > 2.25D
                && mob.distanceToSqr(owner) <= stopDistance * stopDistance;
        }
        @Override public void tick() {
            if (owner != null) {
                mob.getLookControl().setLookAt(owner, 10.0F, mob.getMaxHeadXRot());
                if (mob.tickCount % 10 == 0) mob.getNavigation().moveTo(owner, speed);
            }
        }
        @Override public void stop() { owner = null; mob.getNavigation().stop(); }
    }

    private FamiliarEvents() {}
}
