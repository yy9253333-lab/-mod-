package cn.blockforge.generated.modb22b5730.block;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.block.entity.AnchorRuneBlockEntity;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/**
 * 阵基石：把刻好的术式永久锚定在地上。
 * 潜行+法杖右键 = 把当前刻印术式刻进去（开始持续运转）
 * 潜行+空手右键 = 清除刻印（停止运转）
 * 普通右键 = 查看当前刻的是什么
 * 破坏 = 直接拿掉
 */
public final class AnchorRuneBlock extends Block implements EntityBlock {
    public AnchorRuneBlock() {
        super(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_PURPLE)
            .strength(1.5f, 6.0f)
            .sound(SoundType.STONE)
            .lightLevel(s -> 7)
            .requiresCorrectToolForDrops());
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof AnchorRuneBlockEntity be)) return InteractionResult.PASS;

        if (player.isShiftKeyDown()) {
            ItemStack held = player.getItemInHand(hand);
            if (held.isEmpty()) {
                if (!be.canEdit(player)) {
                    player.displayClientMessage(Component.literal("只有刻阵者才能清除这座法阵。"), true);
                    return InteractionResult.CONSUME;
                }
                be.clear();
                player.displayClientMessage(Component.literal("阵基石已清空。"), true);
                return InteractionResult.CONSUME;
            }
            if (!held.is(GeneratedMod.PRAYER_STAFF.get())) {
                player.displayClientMessage(Component.literal("请手持祈愿法杖，潜行右键阵基石以锚定术式；潜行空手右键可清除。"), true);
                return InteractionResult.CONSUME;
            }
            if (!be.canEdit(player)) {
                player.displayClientMessage(Component.literal("这座法阵属于其他刻阵者，无法修改。"), true);
                return InteractionResult.CONSUME;
            }
            String active = PrayerData.active(player);
            if (active.isEmpty()) {
                player.displayClientMessage(Component.literal("你还没有刻印术式：先打开魔导书组阵并刻印。"), true);
                return InteractionResult.CONSUME;
            }
            be.engrave(player, active);
            player.displayClientMessage(Component.literal("术式已锚定：" + active + "（每 2 秒尝试运行一次；刻阵者在线且同维度时从其魔力中扣除费用，离线或跨维度时暂停但保留法阵）"), true);
            level.playSound(null, pos, net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE,
                net.minecraft.sounds.SoundSource.BLOCKS, 0.8f, 0.8f);
            return InteractionResult.CONSUME;
        }

        if (be.isEngraved()) {
            player.displayClientMessage(Component.literal("阵基石：" + be.runes()), true);
        } else {
            player.displayClientMessage(Component.literal("空的阵基石。潜行+法杖右键刻印术式。"), true);
        }
        return InteractionResult.CONSUME;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AnchorRuneBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return (lvl, pos, st, be) -> { if (be instanceof AnchorRuneBlockEntity anchor) anchor.serverTick(); };
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state) { return true; }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof AnchorRuneBlockEntity be && be.isEngraved() ? 15 : 0;
    }
}
