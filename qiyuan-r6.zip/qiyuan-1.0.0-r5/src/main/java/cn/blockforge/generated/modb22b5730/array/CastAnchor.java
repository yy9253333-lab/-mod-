package cn.blockforge.generated.modb22b5730.array;

/** 施法锚点：法阵最终落在哪里。 */
public enum CastAnchor {
    /** 玩家脚下（含「己」且不含「视」） */
    FEET,
    /** 玩家视线方向前方（含「视」；「视」优先于「己」） */
    LOOK,
    /** 两者都不含：沿用现有系统的默认施法位置 */
    DEFAULT
}
