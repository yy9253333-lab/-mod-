package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 开局送书（含 5 枚基础符文）、魔力恢复、符文收集扫描与数据同步。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlayerEvents {
    public static final String[] STARTER_RUNES = {"己", "视", "火", "灭", "弹"};

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        giveStarterKit(player);
        PrayerNet.sync(player);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        PrayerNet.sync(event.getEntity());
    }

    /** 登出时清掉服务端的瞄准预演缓存，避免残留过期数据。 */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        cn.blockforge.generated.modb22b5730.spell.AimStore.clear(event.getEntity().getUUID());
    }

    public static void giveStarterKit(Player player) {
        if (player.getPersistentData().getBoolean("prayer_granted")) return;
        player.getInventory().add(new ItemStack(GeneratedMod.PRAYER_BOOK.get()));
        for (String rune : STARTER_RUNES) player.getInventory().add(RuneItem.stack(rune));
        player.getPersistentData().putBoolean("prayer_granted", true);
        if (!player.level().isClientSide)
            player.displayClientMessage(Component.literal("《祈愿》苏醒了：物品栏里多了一本魔导书和 5 枚基础符文，右键打开看看吧。"), false);
    }

    /** 临时召唤物到期自动消散，避免召唤生物永久留在世界里。 */
    @SubscribeEvent
    public static void onSummonedMobTick(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide) return;
        cn.blockforge.generated.modb22b5730.spell.SummonService.tickTemporarySummon(event.getEntity());
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player player = event.player;
        if (player.tickCount % 10 == 0 && !player.getAbilities().instabuild) PrayerData.addMana(player, 1);
        if (player.tickCount % 40 == 0) {
            boolean changed = PrayerData.scanInventory(player);
            if (changed || player.tickCount % 200 == 0) PrayerNet.sync(player);
        }
    }

    private PlayerEvents() {}
}
