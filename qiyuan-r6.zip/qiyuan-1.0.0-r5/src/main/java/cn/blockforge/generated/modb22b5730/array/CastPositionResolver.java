package cn.blockforge.generated.modb22b5730.array;

import java.util.Collection;

/**
 * 符文组合 -> 施法锚点。纯逻辑，不依赖 Minecraft，便于单元测试。
 *
 * <pre>
 *  含「视」            -> LOOK   （含「己」+「视」也是 LOOK）
 *  只含「己」          -> FEET
 *  两者都不含          -> DEFAULT
 * </pre>
 */
public final class CastPositionResolver {
    public static final String RUNE_SELF = "己";
    public static final String RUNE_SIGHT = "视";

    private CastPositionResolver() {}

    public static CastAnchor resolve(Collection<String> runes) {
        if (runes == null || runes.isEmpty()) return CastAnchor.DEFAULT;
        boolean sight = runes.contains(RUNE_SIGHT);
        boolean self = runes.contains(RUNE_SELF);
        if (sight) return CastAnchor.LOOK;   // 视 优先于 己
        if (self) return CastAnchor.FEET;
        return CastAnchor.DEFAULT;
    }
}
