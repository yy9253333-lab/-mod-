package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.array.ArrayLayer;
import cn.blockforge.generated.modb22b5730.array.ArrayMath;
import cn.blockforge.generated.modb22b5730.array.ArrayNode;
import cn.blockforge.generated.modb22b5730.array.ArrayParameters;
import cn.blockforge.generated.modb22b5730.array.RuneArrayLayout;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;
import java.util.List;

/** 施法前的相机前方动态预览；施法后的法阵由世界坐标实体显示，不依赖手持物品。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ViewCircleRenderer {
    private static final double FORWARD = 1.2, DOWN = 0.35;
    private static final float FOLLOW_LERP = 0.35f;
    private static final float PREVIEW_HALF = 0.46f;
    /**
     * 手持魔导书/法杖时是否常驻显示视野前预览。关闭：拿起道具不再预演法阵，
     * 只有施法瞬间才在世界坐标生成法阵闪光（SpellCircleEntity）。
     */
    private static final boolean IDLE_PREVIEW = false;
    private static final int BUILD_TICKS = 12;
    private static final ResourceLocation FRAME = GeneratedMod.rl("textures/magic/array/base/frame.png");
    private static final ResourceLocation CORE = GeneratedMod.rl("textures/magic/array/base/core.png");
    private static final float[][] CORNERS = {
        {-1f, -1f, 0f, 1f}, {-1f, 1f, 0f, 0f}, {1f, 1f, 1f, 0f}, {1f, -1f, 1f, 1f}
    };
    private static final MultiBufferSource.BufferSource PREVIEW_BUFFER =
        MultiBufferSource.immediate(new BufferBuilder(512));
    private static Vec3 smoothDir;
    private static Vec3 smoothUp;
    private static float animationAge;

    @SubscribeEvent
    public static void onLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        Minecraft mc = Minecraft.getInstance();
        if (!IDLE_PREVIEW || mc.player == null || mc.level == null || mc.screen != null || !AimTracker.viewCircleMode()) {
            smoothDir = null;
            smoothUp = null;
            animationAge = 0;
            return;
        }
        Vector3f look = event.getCamera().getLookVector();
        Vector3f up = event.getCamera().getUpVector();
        Vec3 wantedDir = new Vec3(look.x, look.y, look.z).normalize();
        Vec3 wantedUp = new Vec3(up.x, up.y, up.z).normalize();
        if (smoothDir == null || smoothUp == null) {
            smoothDir = wantedDir;
            smoothUp = wantedUp;
        } else {
            smoothDir = smoothDir.lerp(wantedDir, FOLLOW_LERP).normalize();
            smoothUp = smoothUp.lerp(wantedUp, FOLLOW_LERP).normalize();
        }
        Vec3 right = smoothDir.cross(smoothUp);
        if (right.lengthSqr() < 1.0e-8) {
            Vec3 fallbackAxis = Math.abs(smoothDir.y) < 0.9 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
            right = smoothDir.cross(fallbackAxis);
        }
        right = right.normalize();
        Vec3 up2 = right.cross(smoothDir).normalize();
        if (!Double.isFinite(right.x) || !Double.isFinite(up2.y)) return;

        Vec3 camera = event.getCamera().getPosition();
        Vec3 center = camera.add(smoothDir.scale(FORWARD)).subtract(smoothUp.scale(DOWN));
        animationAge = (animationAge + 0.2f) % 100000f;
        double age = BUILD_TICKS + animationAge;
        int color = SpellCasterColor.current();
        int r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        try {
            PoseStack.Pose p = pose.last();
            Vec3 faceNormal = smoothDir.scale(-1);
            double radius = PREVIEW_HALF * 280.0 / 300.0;
            ArrayParameters params = RuneArrayLayout.build(PrayerState.active, radius, BUILD_TICKS);
            drawBillboard(FRAME, p, camera, center, right, up2, faceNormal,
                PREVIEW_HALF, 0, 0, 0, 0.001, 170, r, g, b);

            List<ArrayLayer> layers = params.layers();
            double progress = ArrayMath.progress(age, params.buildTicks());
            for (int i = 0; i < layers.size(); i++) {
                ArrayLayer layer = layers.get(i);
                float alpha = (float) ArrayMath.layerReveal(i, layers.size(), progress);
                int a = Math.max(0, Math.min(255, Math.round(235 * alpha)));
                if (a == 0) continue;
                double angle = ArrayMath.layerAngleDeg(layer, age, params.buildTicks(), 2.0);
                double depth = 0.004 + (i + 1) * 0.003;
                drawBillboard(GeneratedMod.rl("textures/magic/array/" + layer.skin() + ".png"),
                    p, camera, center, right, up2, faceNormal, PREVIEW_HALF,
                    0, 0, angle, depth, a, 255, 255, 255);
                for (ArrayNode node : params.nodes()) {
                    if (node.layerIndex() != i || node.runeId().equals(layer.skin())) continue;
                    double[] offset = ArrayMath.nodeOffset(node.compassDeg(),
                        ArrayMath.pxToBlocks(layer.ringRadius(), params));
                    float iconHalf = PREVIEW_HALF * 0.18f;
                    drawBillboard(GeneratedMod.rl("textures/magic/array/" + node.runeId() + ".png"),
                        p, camera, center, right, up2, faceNormal, iconHalf,
                        offset[0], offset[1], angle, depth + 0.002, a, 255, 255, 255);
                }
            }
            drawBillboard(CORE, p, camera, center, right, up2, faceNormal,
                PREVIEW_HALF, 0, 0, 0, 0.03, 220, r, g, b);
        } finally {
            PREVIEW_BUFFER.endBatch();
            pose.popPose();
        }
    }

    private static void drawBillboard(ResourceLocation texture, PoseStack.Pose pose, Vec3 camera,
                                      Vec3 center, Vec3 axisX, Vec3 axisY, Vec3 normal,
                                      float half, double centerX, double centerY, double angleDeg,
                                      double depth, int alpha, int red, int green, int blue) {
        if (alpha <= 0) return;
        VertexConsumer vc = PREVIEW_BUFFER.getBuffer(RenderType.entityTranslucentEmissive(texture));
        double angle = Math.toRadians(angleDeg);
        double cos = Math.cos(angle), sin = Math.sin(angle);
        for (float[] q : CORNERS) {
            double localX = centerX + q[0] * half;
            double localY = centerY + q[1] * half;
            double rotatedX = localX * cos - localY * sin;
            double rotatedY = localX * sin + localY * cos;
            Vec3 point = center.add(axisX.scale(rotatedX)).add(axisY.scale(rotatedY)).add(normal.scale(depth));
            RenderUtil.entityVertex(vc, pose,
                (float) (point.x - camera.x), (float) (point.y - camera.y), (float) (point.z - camera.z),
                red, green, blue, Math.min(255, alpha), q[2], q[3],
                (float) normal.x, (float) normal.y, (float) normal.z);
        }
    }

    private ViewCircleRenderer() {}
}
