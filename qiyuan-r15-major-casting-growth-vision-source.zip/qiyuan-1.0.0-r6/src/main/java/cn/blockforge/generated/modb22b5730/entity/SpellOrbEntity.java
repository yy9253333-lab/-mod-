package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/** 法术飞弹：承载术式符文串，命中后由 SpellCaster 结算。 */
public class SpellOrbEntity extends Projectile {
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TARGET_ID = SynchedEntityData.defineId(SpellOrbEntity.class, EntityDataSerializers.INT);
    private int age;

    public SpellOrbEntity(EntityType<? extends SpellOrbEntity> type, Level level) {
        super(type, level);
    }

    public static void launch(Level level, LivingEntity shooter, List<String> runes, Vec3 dir, int color) {
        launch(level, shooter, runes, dir, color, null);
    }

    /** 服务端生成投射物；存在锁定目标时以 45° 仰角起射，再由服务端逐 tick 收敛至目标。 */
    public static void launch(Level level, LivingEntity shooter, List<String> runes, Vec3 dir, int color, LivingEntity target) {
        SpellOrbEntity orb = new SpellOrbEntity(GeneratedMod.SPELL_ORB.get(), level);
        orb.setOwner(shooter);
        // 投射物统一从施法者上方区域生成；偏移幅度由服务端持久化的魔力不稳定度决定。
        orb.setPos(shooter.position().add(0.0, shooter.getBbHeight() + 0.25, 0.0).add(dir.scale(0.25)));
        orb.entityData.set(RUNES, String.join("·", runes));
        orb.entityData.set(COLOR, color);
        orb.entityData.set(TARGET_ID, target == null ? -1 : target.getId());
        Vec3 launchDir = dir.normalize();
        if (target != null) {
            Vec3 toward = target.getBoundingBox().getCenter().subtract(orb.position());
            Vec3 horizontal = new Vec3(toward.x, 0.0, toward.z);
            if (horizontal.lengthSqr() > 1.0e-8) {
                horizontal = horizontal.normalize();
                // 45°仰角：水平与垂直分量相等；后续由服务端引导收敛至目标。
                double component = Math.sqrt(0.5);
                launchDir = new Vec3(horizontal.x * component, component, horizontal.z * component);
            }
        }
        if (shooter instanceof net.minecraft.world.entity.player.Player player) {
            float instability = cn.blockforge.generated.modb22b5730.data.PrayerData.instability(player);
            if (instability > 0.001F) {
                double spread = instability * cn.blockforge.generated.modb22b5730.PrayerConfig.INSTABILITY_MAX_DEVIATION.get();
                launchDir = launchDir.add((level.random.nextDouble() - 0.5) * spread,
                    (level.random.nextDouble() - 0.5) * spread, (level.random.nextDouble() - 0.5) * spread).normalize();
            }
        }
        orb.shoot(launchDir.x, launchDir.y, launchDir.z, 0.85f, 0f);
        level.addFreshEntity(orb);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(RUNES, "");
        this.entityData.define(COLOR, 0x3D9CB8);
        this.entityData.define(TARGET_ID, -1);
    }

    public String runeString() { return this.entityData.get(RUNES); }
    public int color() { return this.entityData.get(COLOR); }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (age > 100) { discard(); return; }
        if (level().isClientSide) {
            var rnd = level().getRandom();
            int c = color();
            double vx = (rnd.nextDouble() - 0.5) * 0.05;
            double vy = (rnd.nextDouble() - 0.5) * 0.05;
            double vz = (rnd.nextDouble() - 0.5) * 0.05;
            // 服务端每 10 tick 才同步一次位置；客户端沿同步下来的速度预测，飞弹才不会一顿一顿。
            setPos(getX() + getDeltaMovement().x, getY() + getDeltaMovement().y, getZ() + getDeltaMovement().z);
            level().addParticle(cn.blockforge.generated.modb22b5730.spell.SpellCaster.dust(c, 0.9f),
                getX(), getY(), getZ(), vx, vy, vz);
            // 不同元素使用原版粒子形成可见区别，飞弹生命周期仍由此实体独立控制。
            String runes = runeString();
            if (runes.contains("火")) level().addParticle(net.minecraft.core.particles.ParticleTypes.FLAME, getX(), getY(), getZ(), vx * 1.7, vy * 1.7, vz * 1.7);
            if (runes.contains("冰")) level().addParticle(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, getX(), getY(), getZ(), vx, vy, vz);
            if (runes.contains("水")) level().addParticle(net.minecraft.core.particles.ParticleTypes.BUBBLE, getX(), getY(), getZ(), vx, vy, vz);
            if (runes.contains("雷")) level().addParticle(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), vx * 2, vy * 2, vz * 2);
            if (runes.contains("风")) level().addParticle(net.minecraft.core.particles.ParticleTypes.CLOUD, getX(), getY(), getZ(), vx, vy, vz);
            // 土属性使用原版方块破坏碎屑，而不是 CRIT/POOF 等不相关粒子。
            if (runes.contains("土")) level().addParticle(new net.minecraft.core.particles.BlockParticleOption(
                net.minecraft.core.particles.ParticleTypes.BLOCK, net.minecraft.world.level.block.Blocks.DIRT.defaultBlockState()),
                getX(), getY(), getZ(), vx * 0.8, Math.abs(vy) + 0.015, vz * 0.8);
        } else {
            // 仅服务端执行制导。客户端不能指定目标或修改轨迹；目标死亡/离开世界后回退为自由弹道。
            int targetId = entityData.get(TARGET_ID);
            if (targetId >= 0 && level() instanceof net.minecraft.server.level.ServerLevel server) {
                net.minecraft.world.entity.Entity candidate = server.getEntity(targetId);
                if (candidate instanceof LivingEntity target && target.isAlive() && target != getOwner()) {
                    Vec3 desired = target.getBoundingBox().getCenter().subtract(position());
                    if (desired.lengthSqr() > 1.0e-6) {
                        Vec3 current = getDeltaMovement();
                        double speed = Math.max(0.45, current.length());
                        Vec3 steered = current.normalize().scale(0.84).add(desired.normalize().scale(0.16));
                        if (steered.lengthSqr() > 1.0e-8) setDeltaMovement(steered.normalize().scale(speed));
                    }
                } else entityData.set(TARGET_ID, -1);
            }
            Vec3 start = position();
            Vec3 move = getDeltaMovement();
            Vec3 end = start.add(move);
            EntityHitResult ehit = ProjectileUtil.getEntityHitResult(level(), this, start, end,
                new AABB(start, end).inflate(0.6), this::canHitEntity);
            HitResult bhit = level().clip(new net.minecraft.world.level.ClipContext(start, end,
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, this));
            if (ehit != null && (bhit.getType() == HitResult.Type.MISS
                || start.distanceToSqr(ehit.getLocation()) < start.distanceToSqr(bhit.getLocation()))) {
                onHitEntity(ehit);
            } else if (bhit.getType() != HitResult.Type.MISS) {
                onHitBlock((BlockHitResult) bhit);
            }
            setPos(end);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (!level().isClientSide) {
            // 命中实体：法阵朝向与飞行方向相反（面向来袭方向）。
            Vec3 travel = getDeltaMovement();
            Vec3 normal = travel.lengthSqr() > 1.0e-8 ? travel.scale(-1).normalize() : new Vec3(0.0, 1.0, 0.0);
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(), normal);
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), result.getEntity());
            discard();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (!level().isClientSide) {
            // 命中方块：按命中面的真实法线摆放法阵。
            net.minecraft.core.Direction face = result.getDirection();
            Vec3 normal = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
            SpellCaster.spawnProjectileImpactCircle(level(), getOwner(), runeString(), result.getLocation(), normal);
            SpellCaster.applyImpact(level(), getOwner(), runeString(), result.getLocation(), null);
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("prayer_runes", runeString());
        tag.putInt("prayer_color", color());
        tag.putInt("prayer_target_id", entityData.get(TARGET_ID));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(RUNES, tag.getString("prayer_runes"));
        entityData.set(COLOR, tag.getInt("prayer_color"));
        entityData.set(TARGET_ID, tag.contains("prayer_target_id") ? tag.getInt("prayer_target_id") : -1);
    }
}
