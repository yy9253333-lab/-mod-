package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 开局送书（含 5 枚基础符文）、魔力恢复、符文收集扫描与数据同步。 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlayerEvents {
    public static final String[] STARTER_RUNES = {"己", "视", "火", "灭", "弹"};

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        giveStarterKit(player);
        if (!player.level().isClientSide && PrayerData.of(player).getLong("growth_start") < 0)
            PrayerData.of(player).putLong("growth_start", player.level().getGameTime());
        PrayerNet.sync(player);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        PrayerNet.sync(event.getEntity());
    }

    /** 登出时清掉服务端的瞄准预演缓存，避免残留过期数据。 */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        cn.blockforge.generated.modb22b5730.spell.AimStore.clear(event.getEntity().getUUID());
    }

    public static void giveStarterKit(Player player) {
        if (player.getPersistentData().getBoolean("prayer_granted")) return;
        player.getInventory().add(new ItemStack(GeneratedMod.PRAYER_BOOK.get()));
        for (String rune : STARTER_RUNES) player.getInventory().add(RuneItem.stack(rune));
        player.getPersistentData().putBoolean("prayer_granted", true);
        if (!player.level().isClientSide)
            player.displayClientMessage(Component.literal("《祈愿》苏醒了：物品栏里多了一本魔导书和 5 枚基础符文，右键打开看看吧。"), false);
    }

    /** 临时召唤物到期自动消散，避免召唤生物永久留在世界里。 */
    @SubscribeEvent
    public static void onSummonedMobTick(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide) return;
        cn.blockforge.generated.modb22b5730.spell.SummonService.tickTemporarySummon(event.getEntity());
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player player = event.player;
        PrayerData.tickGrowthWindow(player);
        PrayerData.exerciseTick(player);
        boolean exhausted = !PrayerData.creativeUnlocked(player) && PrayerData.consumeExhaustion(player);
        boolean exhaustionApplied = PrayerData.of(player).getBoolean("exhaustion_applied");
        if (PrayerData.charging(player) && PrayerData.active(player).contains("视") && !exhausted
            && !cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity.hasCameraAnchoredCircle(player.level(), player)) {
            var runes = PrayerData.parse(PrayerData.active(player));
            if (!runes.isEmpty()) cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity.spawnCameraAnchored(
                player.level(), player, PrayerData.active(player), cn.blockforge.generated.modb22b5730.spell.SpellCaster.primaryColor(runes),
                cn.blockforge.generated.modb22b5730.spell.SpellCaster.castCircleRadius(runes));
        }
        if (exhausted && !exhaustionApplied) {
            player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.CONFUSION, cn.blockforge.generated.modb22b5730.PrayerConfig.EXHAUSTION_NAUSEA_TICKS.get(), 0, false, true, true));
            PrayerData.of(player).putBoolean("exhaustion_applied", true);
            PrayerData.clearCharge(player);
            cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity.discardOwnedCircles(player);
            PrayerData.setCooldownEnd(player, Math.max(PrayerData.cooldownEnd(player), player.level().getGameTime() + 100));
        } else if (!exhausted && exhaustionApplied) PrayerData.of(player).putBoolean("exhaustion_applied", false);
        if (exhausted) {
            if (PrayerData.charging(player)) PrayerData.clearCharge(player);
            cn.blockforge.generated.modb22b5730.entity.SpellCircleEntity.discardOwnedCircles(player);
        }
        // 枯竭惩罚包含恢复减速：正常每 10 tick 恢复 1 点，枯竭期间每 100 tick 恢复 1 点。
        int regenInterval = exhausted ? cn.blockforge.generated.modb22b5730.PrayerConfig.EXHAUSTION_RECOVERY_INTERVAL.get() : 10;
        if (player.tickCount % regenInterval == 0 && !player.getAbilities().instabuild) PrayerData.addMana(player, 1);
        if (player.tickCount % 10 == 0) {
            boolean changed = PrayerData.scanInventory(player);
            if (changed || player.tickCount % 200 == 0) PrayerNet.sync(player);
        }
    }

    private PlayerEvents() {}
}
