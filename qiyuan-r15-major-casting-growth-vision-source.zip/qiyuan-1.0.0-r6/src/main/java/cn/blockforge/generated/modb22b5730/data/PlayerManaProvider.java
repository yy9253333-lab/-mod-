package cn.blockforge.generated.modb22b5730.data;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import javax.annotation.Nullable;

public final class PlayerManaProvider implements ICapabilitySerializable<CompoundTag> {
    private final PlayerManaData data = new PlayerManaData();
    private final LazyOptional<PlayerManaData> optional = LazyOptional.of(() -> data);
    @Override public <T> LazyOptional<T> getCapability(Capability<T> cap, @Nullable Direction side) {
        return PlayerManaData.CAPABILITY.orEmpty(cap, optional);
    }
    @Override public CompoundTag serializeNBT() { return data.serializeNBT(); }
    @Override public void deserializeNBT(CompoundTag tag) { data.deserializeNBT(tag); }
    public void invalidate() { optional.invalidate(); }
}
