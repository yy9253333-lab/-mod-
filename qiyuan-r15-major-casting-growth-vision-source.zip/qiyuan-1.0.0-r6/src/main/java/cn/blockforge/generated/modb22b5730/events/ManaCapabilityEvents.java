package cn.blockforge.generated.modb22b5730.events;

import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PlayerManaData;
import cn.blockforge.generated.modb22b5730.data.PlayerManaProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ManaCapabilityEvents {
    private static final ResourceLocation KEY = GeneratedMod.rl("player_mana");
    @SubscribeEvent public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            PlayerManaProvider provider = new PlayerManaProvider();
            event.addCapability(KEY, provider);
            event.addListener(provider::invalidate);
        }
    }
    @SubscribeEvent public static void clone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(PlayerManaData.CAPABILITY).ifPresent(oldData ->
            event.getEntity().getCapability(PlayerManaData.CAPABILITY).ifPresent(newData -> newData.copyFrom(oldData)));
        event.getOriginal().invalidateCaps();
    }
    private ManaCapabilityEvents() {}
}
