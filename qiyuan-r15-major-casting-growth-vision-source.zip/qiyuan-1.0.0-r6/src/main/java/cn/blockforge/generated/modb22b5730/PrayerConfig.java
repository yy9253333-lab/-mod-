package cn.blockforge.generated.modb22b5730;

import net.minecraftforge.common.ForgeConfigSpec;

/** 《祈愿》服务端权威数值配置；多人游戏中以服务端配置为准。 */
public final class PrayerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue INITIAL_CAPACITY;
    public static final ForgeConfigSpec.IntValue MAX_CAPACITY;
    public static final ForgeConfigSpec.IntValue NO_FOCUS_UNLOCK_CAPACITY;
    public static final ForgeConfigSpec.DoubleValue COMPREHENSION_UNLOCK;
    public static final ForgeConfigSpec.IntValue GROWTH_WINDOW_TICKS;
    public static final ForgeConfigSpec.IntValue CASTS_PER_CAPACITY;
    public static final ForgeConfigSpec.IntValue CRYSTAL_CAPACITY_GAIN;
    public static final ForgeConfigSpec.IntValue EXHAUSTION_NAUSEA_TICKS;
    public static final ForgeConfigSpec.DoubleValue EXHAUSTION_RATIO;
    public static final ForgeConfigSpec.IntValue MAX_DUPLICATES;
    public static final ForgeConfigSpec.IntValue MAX_CHARGE_TICKS;
    public static final ForgeConfigSpec.DoubleValue VISION_ANCHOR_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue INSTABILITY_MAX_DEVIATION;
    public static final ForgeConfigSpec.DoubleValue CHARGE_DAMAGE_PER_TICK;
    public static final ForgeConfigSpec.IntValue CHARGE_MANA_PER_TICK;
    public static final ForgeConfigSpec.DoubleValue DUPLICATE_MANA_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue EXERCISE_TICKS_PER_CAPACITY;
    public static final ForgeConfigSpec.IntValue EXHAUSTION_RECOVERY_INTERVAL;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("mana");
        INITIAL_CAPACITY = b.comment("新玩家初始魔力上限").defineInRange("initialCapacity", 200, 1, 2000);
        MAX_CAPACITY = b.comment("魔力上限硬上限").defineInRange("maxCapacity", 2000, 200, 2000);
        NO_FOCUS_UNLOCK_CAPACITY = b.comment("无法器施法所需魔力上限").defineInRange("noFocusUnlockCapacity", 1000, 200, 2000);
        COMPREHENSION_UNLOCK = b.comment("无法器施法所需魔法领悟值").defineInRange("comprehensionUnlock", 10.0, 0.0, 10000.0);
        GROWTH_WINDOW_TICKS = b.comment("新手快速成长窗口，默认 3600 秒（20 TPS）").defineInRange("growthWindowTicks", 72000, 1, 7200000);
        CASTS_PER_CAPACITY = b.comment("窗口期内每成功施法多少次增加 1 点魔力上限").defineInRange("castsPerCapacity", 5, 1, 10000);
        CRYSTAL_CAPACITY_GAIN = b.comment("每枚魔力晶石增加的魔力上限").defineInRange("crystalCapacityGain", 5, 0, 1000);
        EXHAUSTION_RATIO = b.comment("魔力枯竭阈值占魔力上限的比例").defineInRange("exhaustionRatio", 0.05, 0.0, 0.5);
        EXHAUSTION_NAUSEA_TICKS = b.comment("魔力枯竭恶心效果时长（tick）").defineInRange("exhaustionNauseaTicks", 100, 1, 72000);
        b.pop();
        b.push("casting");
        MAX_DUPLICATES = b.comment("多重施法数量硬上限").defineInRange("maxDuplicates", 8, 1, 64);
        MAX_CHARGE_TICKS = b.comment("蓄力计入伤害与消耗计算的最大 tick 数").defineInRange("maxChargeTicks", 100, 1, 1200);
        CHARGE_DAMAGE_PER_TICK = b.comment("每 tick 蓄力增加的伤害比例，0.01 表示每 tick +1%").defineInRange("chargeDamagePerTick", 0.01, 0.0, 1.0);
        CHARGE_MANA_PER_TICK = b.comment("每 tick 蓄力额外消耗的魔力").defineInRange("chargeManaPerTick", 1, 0, 1000);
        DUPLICATE_MANA_MULTIPLIER = b.comment("每增加一个复制体，额外增加的基础魔力消耗倍数；1.0 为线性成本").defineInRange("duplicateManaMultiplier", 1.0, 0.0, 20.0);
        COOLDOWN_MULTIPLIER = b.comment("全局冷却倍率").defineInRange("cooldownMultiplier", 1.0, 0.0, 20.0);
        EXERCISE_TICKS_PER_CAPACITY = b.comment("新手窗口结束后，每完成多少 tick 有效冲刺锻炼增加 1 点上限").defineInRange("exerciseTicksPerCapacity", 1200, 1, 72000);
        EXHAUSTION_RECOVERY_INTERVAL = b.comment("魔力枯竭期间每多少 tick 恢复 1 点魔力").defineInRange("exhaustionRecoveryInterval", 100, 20, 72000);
        b.pop();
        b.push("visionRune");
        VISION_ANCHOR_DISTANCE = b.comment("视符文法阵相对摄像机的锚定距离").defineInRange("anchorDistance", 2.0, 0.25, 16.0);
        b.pop();
        SPEC = b.build();
    }

    private PrayerConfig() {}
}
