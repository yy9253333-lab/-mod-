package cn.blockforge.generated.modb22b5730.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;

/** 服务端权威的玩家魔力属性 Capability；PrayerData 负责旧存档迁移与网络快照。 */
public final class PlayerManaData {
    public static final Capability<PlayerManaData> CAPABILITY = CapabilityManager.get(new CapabilityToken<>() {});
    private int manaPool = 200;
    private int manaCapacity = 200;
    private float manaInstability = 1.0F;
    private float spellProficiency;
    private float magicComprehension;
    private boolean noFocusUnlockFlag;
    private long growthWindowStart = -1L;
    private int growthWindowTimer;
    private int growthCasts;
    private int exerciseTicks;
    private boolean initialized;

    public static void register(RegisterCapabilitiesEvent event) { event.register(PlayerManaData.class); }
    public int manaPool() { return manaPool; }
    public int manaCapacity() { return manaCapacity; }
    public float instability() { return manaInstability; }
    public float proficiency() { return spellProficiency; }
    public float comprehension() { return magicComprehension; }
    public boolean noFocusUnlockFlag() { return noFocusUnlockFlag; }
    public long growthWindowStart() { return growthWindowStart; }
    public int growthWindowTimer() { return growthWindowTimer; }
    public int growthCasts() { return growthCasts; }
    public int exerciseTicks() { return exerciseTicks; }
    public boolean initialized() { return initialized; }
    public void setManaPool(int v) { manaPool = Math.max(0, v); }
    public void setManaCapacity(int v) { manaCapacity = Math.max(1, Math.min(2000, v)); }
    public void setInstability(float v) { manaInstability = Math.max(0.0F, Math.min(1.0F, v)); }
    public void setProficiency(float v) { spellProficiency = Math.max(0.0F, v); }
    public void setComprehension(float v) { magicComprehension = Math.max(0.0F, v); }
    public void setNoFocusUnlockFlag(boolean v) { noFocusUnlockFlag = v; }
    public void setGrowthWindowStart(long v) { growthWindowStart = v; }
    public void setGrowthWindowTimer(int v) { growthWindowTimer = Math.max(0, Math.min(7200000, v)); }
    public void tickGrowthWindowTimer(int maxTicks) { if (growthWindowTimer < maxTicks) growthWindowTimer++; }
    public void setGrowthCasts(int v) { growthCasts = Math.max(0, v); }
    public void setExerciseTicks(int v) { exerciseTicks = Math.max(0, v); }
    public void markInitialized() { initialized = true; }
    public void loadLegacy(CompoundTag t) {
        manaPool = Math.max(0, t.getInt("mana"));
        manaCapacity = Math.max(1, Math.min(2000, t.getInt("mana_capacity")));
        manaPool = Math.min(manaPool, manaCapacity);
        manaInstability = Math.max(0, Math.min(1, t.getFloat("instability")));
        spellProficiency = Math.max(0, t.getFloat("proficiency"));
        magicComprehension = Math.max(0, t.getFloat("comprehension"));
        noFocusUnlockFlag = t.getBoolean("no_focus_unlock_flag");
        growthWindowStart = t.getLong("growth_start");
        growthWindowTimer = Math.max(0, t.getInt("growth_elapsed_ticks"));
        growthCasts = Math.max(0, t.getInt("growth_casts"));
        exerciseTicks = Math.max(0, t.getInt("exercise_ticks"));
        initialized = true;
    }
    public void writeLegacy(CompoundTag t) {
        t.putInt("mana", manaPool); t.putInt("mana_capacity", manaCapacity);
        t.putFloat("instability", manaInstability); t.putFloat("proficiency", spellProficiency);
        t.putFloat("comprehension", magicComprehension); t.putBoolean("no_focus_unlock_flag", noFocusUnlockFlag);
        t.putLong("growth_start", growthWindowStart); t.putInt("growth_elapsed_ticks", growthWindowTimer); t.putInt("growth_casts", growthCasts);
        t.putInt("exercise_ticks", exerciseTicks);
    }
    public CompoundTag serializeNBT() {
        CompoundTag t = new CompoundTag(); writeLegacy(t); t.putBoolean("initialized", initialized); return t;
    }
    public void deserializeNBT(CompoundTag t) { loadLegacy(t); initialized = t.getBoolean("initialized") || t.contains("mana_capacity"); }
    public void copyFrom(PlayerManaData other) { deserializeNBT(other.serializeNBT()); }
}
