package cn.blockforge.generated.modb22b5730.entity;

import cn.blockforge.generated.modb22b5730.spell.SpellCaster;
import cn.blockforge.generated.modb22b5730.GeneratedMod;
import cn.blockforge.generated.modb22b5730.data.PrayerData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.util.UUID;

/** 法阵实体：mode=0 是短暂、世界坐标固定的施法闪光；mode=1 仅承载持续区域逻辑。 */
public class SpellCircleEntity extends Entity {
    /** 世界法阵动画总时长：约 1.2 秒；不依赖持有法杖的状态。 */
    public static final int CAST_VISUAL_LIFE_TICKS = 24;
    /** 展开与符文依次显现阶段，约 0.5 秒。 */
    public static final int CAST_VISUAL_BUILD_TICKS = 10;
    private static final EntityDataAccessor<String> RUNES = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RADIUS = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> MODE = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MAX_LIFE = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BUILD_TICKS = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.INT);
    // 法阵法线：地面目标朝上，墙面目标沿命中面法线，实体/空中目标面向施法者。
    private static final EntityDataAccessor<Float> NORMAL_X = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> NORMAL_Y = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> NORMAL_Z = SynchedEntityData.defineId(SpellCircleEntity.class, EntityDataSerializers.FLOAT);
    private int life = CAST_VISUAL_LIFE_TICKS;
    private UUID ownerUuid;

    public SpellCircleEntity(EntityType<? extends SpellCircleEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
        noPhysics = true;
    }

    public static SpellCircleEntity spawn(Level level, Entity owner, String runes, int color, float radius, int mode, int lifeTicks) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks,
            Math.min(Math.max(1, lifeTicks), 20), owner.position());
    }

    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, Vec3 pos) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks,
            Math.min(Math.max(1, lifeTicks), 20), pos);
    }

    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, int buildTicks, Vec3 pos) {
        return spawnAt(level, owner, runes, color, radius, mode, lifeTicks, buildTicks, pos,
            new Vec3(0.0, 1.0, 0.0));
    }

    /** 生成定点法阵；pos 与 normal 均在服务端确认后固定，不随玩家或视角变化。 */
    public static SpellCircleEntity spawnAt(Level level, Entity owner, String runes, int color, float radius,
                                            int mode, int lifeTicks, int buildTicks, Vec3 pos, Vec3 normal) {
        SpellCircleEntity circle = new SpellCircleEntity(GeneratedMod.SPELL_CIRCLE.get(), level);
        // 最终坐标与法线必须在 addFreshEntity 前设置，否则客户端会先收到旧坐标/默认朝向。
        circle.setPos(pos.x, pos.y, pos.z);
        Vec3 safeNormal = normal != null && normal.lengthSqr() > 1.0e-8
            ? normal.normalize() : new Vec3(0.0, 1.0, 0.0);
        circle.entityData.set(NORMAL_X, (float) safeNormal.x);
        circle.entityData.set(NORMAL_Y, (float) safeNormal.y);
        circle.entityData.set(NORMAL_Z, (float) safeNormal.z);
        circle.entityData.set(RUNES, runes == null ? "" : runes);
        circle.entityData.set(COLOR, color);
        circle.entityData.set(RADIUS, Math.max(0.1f, radius));
        circle.entityData.set(MODE, mode);
        circle.entityData.set(OWNER_ID, owner == null ? -1 : owner.getId());
        circle.ownerUuid = owner == null ? null : owner.getUUID();
        circle.life = mode == 0 ? CAST_VISUAL_LIFE_TICKS : Math.max(1, lifeTicks);
        circle.entityData.set(MAX_LIFE, circle.life);
        int resolvedBuildTicks = mode == 0 ? CAST_VISUAL_BUILD_TICKS : buildTicks;
        circle.entityData.set(BUILD_TICKS, Math.max(1, Math.min(resolvedBuildTicks, circle.life)));
        level.addFreshEntity(circle);
        return circle;
    }

    /** Camera-Anchored 法阵：服务端每 tick 以施法者眼位与视线重算锚点，客户端只渲染同步坐标。 */
    /** 蓄力阶段只允许同一施法者存在一个摄像机锚定预览法阵。 */
    public static boolean hasCameraAnchoredCircle(Level level, Entity owner) {
        if (owner == null) return false;
        return level.getEntitiesOfClass(SpellCircleEntity.class, owner.getBoundingBox().inflate(128.0),
            e -> e.mode() == 2 && e.findOwner() == owner).size() > 0;
    }

    /** 魔力枯竭时立即清除该玩家的所有法阵，避免锚定法阵在视野中残留。 */
    public static void discardOwnedCircles(Entity owner) {
        if (owner == null || owner.level().isClientSide) return;
        owner.level().getEntitiesOfClass(SpellCircleEntity.class, owner.getBoundingBox().inflate(128.0),
            e -> e.findOwner() == owner).forEach(Entity::discard);
    }

    public static SpellCircleEntity spawnCameraAnchored(Level level, Entity owner, String runes, int color, float radius) {
        if (owner == null) return null;
        Vec3 eye = owner.getEyePosition();
        Vec3 view = owner.getLookAngle().normalize();
        Vec3 anchor = eye.add(view.scale(cn.blockforge.generated.modb22b5730.PrayerConfig.VISION_ANCHOR_DISTANCE.get()));
        if (level instanceof ServerLevel server) {
            var hit = server.clip(new net.minecraft.world.level.ClipContext(eye, anchor,
                net.minecraft.world.level.ClipContext.Block.COLLIDER,
                net.minecraft.world.level.ClipContext.Fluid.NONE, owner));
            if (hit.getType() != net.minecraft.world.phys.HitResult.Type.MISS)
                anchor = hit.getLocation().subtract(view.scale(0.08));
        }
        SpellCircleEntity circle = new SpellCircleEntity(GeneratedMod.SPELL_CIRCLE.get(), level);
        circle.setPos(anchor.x, anchor.y, anchor.z);
        Vec3 normal = view.scale(-1.0);
        circle.entityData.set(NORMAL_X, (float)normal.x);
        circle.entityData.set(NORMAL_Y, (float)normal.y);
        circle.entityData.set(NORMAL_Z, (float)normal.z);
        circle.entityData.set(RUNES, runes == null ? "" : runes);
        circle.entityData.set(COLOR, color);
        circle.entityData.set(RADIUS, Math.max(0.1f, radius));
        circle.entityData.set(MODE, 2);
        circle.entityData.set(OWNER_ID, owner.getId());
        circle.ownerUuid = owner.getUUID();
        circle.life = CAST_VISUAL_LIFE_TICKS;
        circle.entityData.set(MAX_LIFE, circle.life);
        circle.entityData.set(BUILD_TICKS, CAST_VISUAL_BUILD_TICKS);
        level.addFreshEntity(circle);
        return circle;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(RUNES, "");
        entityData.define(COLOR, 0x3D9CB8);
        entityData.define(RADIUS, 2.5f);
        entityData.define(MODE, 0);
        entityData.define(OWNER_ID, -1);
        entityData.define(MAX_LIFE, CAST_VISUAL_LIFE_TICKS);
        entityData.define(BUILD_TICKS, CAST_VISUAL_BUILD_TICKS);
        entityData.define(NORMAL_X, 0.0f);
        entityData.define(NORMAL_Y, 1.0f);
        entityData.define(NORMAL_Z, 0.0f);
    }

    public String runeString() { return entityData.get(RUNES); }
    public int color() { return entityData.get(COLOR); }
    public float radius() { return entityData.get(RADIUS); }
    public int mode() { return entityData.get(MODE); }
    public int maxLife() { return entityData.get(MAX_LIFE); }
    public int buildTicks() { return entityData.get(BUILD_TICKS); }
    public Vec3 normal() {
        Vec3 value = new Vec3(entityData.get(NORMAL_X), entityData.get(NORMAL_Y), entityData.get(NORMAL_Z));
        return value.lengthSqr() > 1.0e-8 ? value.normalize() : new Vec3(0.0, 1.0, 0.0);
    }

    public Entity findOwner() {
        if (ownerUuid != null && level() instanceof ServerLevel serverLevel) {
            Entity byUuid = serverLevel.getEntity(ownerUuid);
            if (byUuid != null) return byUuid;
        }
        return level().getEntity(entityData.get(OWNER_ID));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (--life <= 0) { discard(); return; }
        if (mode() == 2) {
            Entity owner = findOwner();
            if (owner == null || !owner.isAlive()) { discard(); return; }
            // 蓄力期间保持法阵存在并持续跟随摄像机；释放蓄力后回到短时施法动画生命周期。
            if (owner instanceof net.minecraft.world.entity.player.Player player && PrayerData.charging(player))
                life = CAST_VISUAL_LIFE_TICKS;
            Vec3 eye = owner.getEyePosition();
            Vec3 view = owner.getLookAngle().normalize();
            Vec3 anchor = eye.add(view.scale(cn.blockforge.generated.modb22b5730.PrayerConfig.VISION_ANCHOR_DISTANCE.get()));
            if (level() instanceof ServerLevel server) {
                var hit = server.clip(new net.minecraft.world.level.ClipContext(eye, anchor,
                    net.minecraft.world.level.ClipContext.Block.COLLIDER,
                    net.minecraft.world.level.ClipContext.Fluid.NONE, owner));
                if (hit.getType() != net.minecraft.world.phys.HitResult.Type.MISS)
                    anchor = hit.getLocation().subtract(view.scale(0.08));
            }
            setPos(anchor.x, anchor.y, anchor.z);
            Vec3 n = view.scale(-1.0);
            entityData.set(NORMAL_X, (float)n.x); entityData.set(NORMAL_Y, (float)n.y); entityData.set(NORMAL_Z, (float)n.z);
        }
        if (mode() == 1 && tickCount % 20 == 0) {
            SpellCaster.applyZone(level(), findOwner(), PrayerData.parse(runeString()), position(), true);
        }
    }

    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return new ClientboundAddEntityPacket(this); }
    @Override public boolean isPickable() { return false; }
    @Override public boolean hurt(DamageSource source, float amount) { return false; }
    @Override public boolean canBeCollidedWith() { return false; }
    @Override public void push(Entity entity) { }
    @Override public void push(double x, double y, double z) { }
    @Override public boolean shouldRenderAtSqrDistance(double dist) { return dist < 256 * 256; }

    /**
     * 实体碰撞箱只有 1×0.1，而法阵贴图可达数格且可沿墙面竖起；
     * 不放大剔除盒的话，圆心一出屏幕法阵就会整体消失。
     */
    @Override
    public AABB getBoundingBoxForCulling() {
        double r = Math.max(0.5, radius()) * 1.2 + 0.3;
        return new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("prayer_runes", runeString());
        tag.putInt("prayer_color", color());
        tag.putFloat("prayer_radius", radius());
        tag.putInt("prayer_mode", mode());
        tag.putInt("prayer_life", life);
        tag.putInt("prayer_max_life", maxLife());
        tag.putInt("prayer_build_ticks", buildTicks());
        tag.putFloat("prayer_normal_x", entityData.get(NORMAL_X));
        tag.putFloat("prayer_normal_y", entityData.get(NORMAL_Y));
        tag.putFloat("prayer_normal_z", entityData.get(NORMAL_Z));
        if (ownerUuid != null) tag.putUUID("prayer_owner_uuid", ownerUuid);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(RUNES, tag.getString("prayer_runes"));
        entityData.set(COLOR, tag.getInt("prayer_color"));
        entityData.set(RADIUS, Math.max(0.1f, tag.getFloat("prayer_radius")));
        int savedMode = tag.getInt("prayer_mode");
        entityData.set(MODE, savedMode);
        int savedLife = Math.max(1, tag.contains("prayer_life") ? tag.getInt("prayer_life")
            : (savedMode == 0 ? CAST_VISUAL_LIFE_TICKS : 30));
        life = savedMode == 0 ? Math.min(CAST_VISUAL_LIFE_TICKS, savedLife) : savedLife;
        int maxLife = savedMode == 0 ? CAST_VISUAL_LIFE_TICKS
            : Math.max(life, tag.getInt("prayer_max_life"));
        entityData.set(MAX_LIFE, maxLife);
        int buildTicks = savedMode == 0 ? CAST_VISUAL_BUILD_TICKS : tag.getInt("prayer_build_ticks");
        entityData.set(BUILD_TICKS, Math.max(1, Math.min(maxLife, buildTicks)));
        entityData.set(NORMAL_X, tag.getFloat("prayer_normal_x"));
        entityData.set(NORMAL_Y, tag.contains("prayer_normal_y") ? tag.getFloat("prayer_normal_y") : 1.0f);
        entityData.set(NORMAL_Z, tag.getFloat("prayer_normal_z"));
        if (new Vec3(entityData.get(NORMAL_X), entityData.get(NORMAL_Y), entityData.get(NORMAL_Z)).lengthSqr() <= 1.0e-8) {
            entityData.set(NORMAL_X, 0.0f);
            entityData.set(NORMAL_Y, 1.0f);
            entityData.set(NORMAL_Z, 0.0f);
        }
        ownerUuid = tag.hasUUID("prayer_owner_uuid") ? tag.getUUID("prayer_owner_uuid") : null;
        entityData.set(OWNER_ID, -1);
    }
}
