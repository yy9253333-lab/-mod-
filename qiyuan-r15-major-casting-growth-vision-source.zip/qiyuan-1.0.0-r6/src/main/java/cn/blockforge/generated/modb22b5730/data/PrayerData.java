package cn.blockforge.generated.modb22b5730.data;

import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/**
 * 玩家自身的《祈愿》数据：魔力、已收集符文、当前刻印术式、10 个预制槽、冷却与引导进度。
 * 全部写入玩家的 persistent data（随玩家存档保存，不依赖外部存储）。
 */
public final class PrayerData {
    public static final String TAG = "prayer";
    public static final int PRESET_SLOTS = 10;
    public static final int RECENT_SLOTS = 3;

    public static CompoundTag of(Player player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(TAG, Tag.TAG_COMPOUND)) root.put(TAG, new CompoundTag());
        CompoundTag t = root.getCompound(TAG);
        if (!t.contains("mana")) t.putInt("mana", 200);
        if (!t.contains("mana_capacity")) { t.putInt("mana_capacity", cn.blockforge.generated.modb22b5730.PrayerConfig.INITIAL_CAPACITY.get()); t.putInt("mana", cn.blockforge.generated.modb22b5730.PrayerConfig.INITIAL_CAPACITY.get()); }
        if (!t.contains("instability")) t.putFloat("instability", 1.0F);
        if (!t.contains("proficiency")) t.putFloat("proficiency", 0.0F);
        if (!t.contains("comprehension")) t.putFloat("comprehension", 0.0F);
        if (!t.contains("growth_start")) t.putLong("growth_start", -1L);
        if (!t.contains("charge_start")) t.putLong("charge_start", -1L);
        if (!t.contains("spell_duplicates")) t.putInt("spell_duplicates", 1);
        return t;
    }

    /** 首次访问时将旧版 persistent NBT 属性迁移至 Capability；之后由 Capability 作为权威数据源。 */
    public static PlayerManaData manaData(Player player) {
        CompoundTag legacy = of(player);
        PlayerManaData data = player.getCapability(PlayerManaData.CAPABILITY).orElse(null);
        if (data != null && !data.initialized()) { data.loadLegacy(legacy); data.markInitialized(); }
        return data;
    }
    private static void mirrorManaData(Player player, PlayerManaData data) { if (data != null) data.writeLegacy(of(player)); }
    public static int mana(Player player) { PlayerManaData d = manaData(player); return d == null ? of(player).getInt("mana") : d.manaPool(); }
    /** 创造符文只需获得一次，解锁状态保存在玩家数据中。 */
    public static boolean creativeUnlocked(Player player) { return of(player).getBoolean("creative_unlocked"); }
    public static void unlockCreative(Player player) {
        CompoundTag t = of(player);
        t.putBoolean("creative_unlocked", true);
        Set<String> all = new LinkedHashSet<>(everHadStored(player));
        all.addAll(Runes.DATA.keySet());
        StringBuilder sb = new StringBuilder();
        for (String r : all) { if (sb.length() > 0) sb.append('|'); sb.append(r); }
        t.putString("ever", sb.toString());
    }
    private static Set<String> everHadStored(Player player) {
        Set<String> out = new LinkedHashSet<>();
        for (String r : of(player).getString("ever").split("\\|")) if (Runes.contains(r)) out.add(r);
        return out;
    }
    public static int capacity(Player player) { PlayerManaData d = manaData(player); return Math.max(1, Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CAPACITY.get(), d == null ? of(player).getInt("mana_capacity") : d.manaCapacity())); }
    public static float instability(Player player) { PlayerManaData d = manaData(player); return Math.max(0.0F, Math.min(1.0F, d == null ? of(player).getFloat("instability") : d.instability())); }
    public static float proficiency(Player player) { PlayerManaData d = manaData(player); return Math.max(0.0F, d == null ? of(player).getFloat("proficiency") : d.proficiency()); }
    public static float comprehension(Player player) { PlayerManaData d = manaData(player); return Math.max(0.0F, d == null ? of(player).getFloat("comprehension") : d.comprehension()); }
    public static void setCapacity(Player player, int value) { PlayerManaData d = manaData(player); int v = Math.max(1, Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CAPACITY.get(), value)); if (d != null) { d.setManaCapacity(v); d.setManaPool(Math.min(d.manaPool(), v)); d.setNoFocusUnlockFlag(v >= cn.blockforge.generated.modb22b5730.PrayerConfig.NO_FOCUS_UNLOCK_CAPACITY.get() && comprehension(player) >= cn.blockforge.generated.modb22b5730.PrayerConfig.COMPREHENSION_UNLOCK.get()); mirrorManaData(player, d); } else of(player).putInt("mana_capacity", v); }
    public static void addCapacity(Player player, int amount) { setCapacity(player, capacity(player) + amount); }
    public static boolean noFocusUnlocked(Player player) { PlayerManaData d = manaData(player); boolean unlocked = capacity(player) >= cn.blockforge.generated.modb22b5730.PrayerConfig.NO_FOCUS_UNLOCK_CAPACITY.get() && comprehension(player) >= cn.blockforge.generated.modb22b5730.PrayerConfig.COMPREHENSION_UNLOCK.get(); if (d != null) { d.setNoFocusUnlockFlag(unlocked); mirrorManaData(player, d); } return unlocked; }
    public static int maxMana(Player player) { return capacity(player); }
    public static void successfulCast(Player player) {
        CompoundTag t = of(player); PlayerManaData d = manaData(player);
        long start = d == null ? t.getLong("growth_start") : d.growthWindowStart();
        if (start < 0) { start = player.level().getGameTime(); if (d != null) d.setGrowthWindowStart(start); t.putLong("growth_start", start); }
        long elapsed = d == null ? Math.max(0L, player.level().getGameTime() - start) : d.growthWindowTimer();
        int casts = (d == null ? t.getInt("growth_casts") : d.growthCasts()) + 1;
        float prof = proficiency(player) + 0.05F;
        float comp = comprehension(player) + 0.02F;
        float inst = Math.max(0.05F, instability(player) - 0.003F);
        if (d != null) { d.setProficiency(prof); d.setComprehension(comp); d.setInstability(inst); d.setGrowthCasts(casts); }
        t.putFloat("proficiency", prof); t.putFloat("comprehension", comp); t.putFloat("instability", inst); t.putInt("growth_casts", casts);
        if (elapsed <= cn.blockforge.generated.modb22b5730.PrayerConfig.GROWTH_WINDOW_TICKS.get()
            && capacity(player) < cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CAPACITY.get()
            && casts % cn.blockforge.generated.modb22b5730.PrayerConfig.CASTS_PER_CAPACITY.get() == 0) setCapacity(player, capacity(player) + 1);
        noFocusUnlocked(player);
        mirrorManaData(player, d);
    }
    public static boolean charging(Player player) { return of(player).getLong("charge_start") >= 0; }
    public static void setCharging(Player player, boolean value) {
        CompoundTag t = of(player);
        if (value) { if (t.getLong("charge_start") < 0) t.putLong("charge_start", player.level().getGameTime()); }
        else {
            long start = t.getLong("charge_start");
            if (start >= 0) t.putInt("last_charge_ticks", (int)Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CHARGE_TICKS.get(), Math.max(0, player.level().getGameTime() - start)));
            t.putLong("charge_start", -1L);
        }
    }
    public static int chargeTicks(Player player) {
        long start = of(player).getLong("charge_start");
        return start < 0 ? Math.max(0, Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CHARGE_TICKS.get(), of(player).getInt("last_charge_ticks")))
            : (int)Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CHARGE_TICKS.get(), Math.max(0, player.level().getGameTime() - start));
    }
    public static void clearCharge(Player player) { of(player).putLong("charge_start", -1L); of(player).putInt("last_charge_ticks", 0); }
    public static int duplicates(Player player) { return Math.max(1, Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_DUPLICATES.get(), of(player).getInt("spell_duplicates"))); }
    public static void setDuplicates(Player player, int count) {
        int proficiencyLimit = Math.max(1, Math.min(cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_DUPLICATES.get(), 1 + (int)(proficiency(player) / 1.0F)));
        of(player).putInt("spell_duplicates", Math.max(1, Math.min(proficiencyLimit, count)));
    }
    public static void tickGrowthWindow(Player player) {
        PlayerManaData d = manaData(player);
        if (d == null || d.growthWindowTimer() >= cn.blockforge.generated.modb22b5730.PrayerConfig.GROWTH_WINDOW_TICKS.get()) return;
        d.tickGrowthWindowTimer(cn.blockforge.generated.modb22b5730.PrayerConfig.GROWTH_WINDOW_TICKS.get());
        mirrorManaData(player, d);
    }

    public static void exerciseTick(Player player) {
        CompoundTag t = of(player); PlayerManaData d = manaData(player);
        long start = d == null ? t.getLong("growth_start") : d.growthWindowStart();
        long elapsed = d == null ? (start < 0 ? 0L : Math.max(0L, player.level().getGameTime() - start)) : d.growthWindowTimer();
        if (start < 0 || elapsed <= cn.blockforge.generated.modb22b5730.PrayerConfig.GROWTH_WINDOW_TICKS.get() || !player.isSprinting() || player.getDeltaMovement().horizontalDistanceSqr() < 0.01) return;
        int ticks = (d == null ? t.getInt("exercise_ticks") : d.exerciseTicks()) + 1;
        if (d != null) d.setExerciseTicks(ticks); t.putInt("exercise_ticks", ticks);
        if (ticks >= cn.blockforge.generated.modb22b5730.PrayerConfig.EXERCISE_TICKS_PER_CAPACITY.get() && capacity(player) < cn.blockforge.generated.modb22b5730.PrayerConfig.MAX_CAPACITY.get()) {
            setCapacity(player, capacity(player) + 1); ticks = 0;
            if (d != null) d.setExerciseTicks(0); t.putInt("exercise_ticks", 0);
        }
        mirrorManaData(player, d);
    }
    public static boolean consumeExhaustion(Player player) {
        int threshold = Math.max(1, (int)Math.ceil(capacity(player) * cn.blockforge.generated.modb22b5730.PrayerConfig.EXHAUSTION_RATIO.get()));
        return mana(player) <= threshold;
    }
    public static void addMana(Player player, int amount) {
        CompoundTag t = of(player); PlayerManaData d = manaData(player);
        int next = Math.max(0, Math.min(maxMana(player), mana(player) + amount));
        if (d != null) { d.setManaPool(next); mirrorManaData(player, d); } else t.putInt("mana", next);
    }
    public static boolean spendMana(Player player, int amount) {
        if (creativeUnlocked(player)) return true;
        if (mana(player) < amount) return false;
        addMana(player, -amount);
        return true;
    }

    /** 已收集（曾经拥有过）的符文，用于解锁组阵界面。 */
    public static Set<String> everHad(Player player) {
        if (creativeUnlocked(player)) return new LinkedHashSet<>(Runes.DATA.keySet());
        String s = of(player).getString("ever");
        Set<String> out = new LinkedHashSet<>();
        for (String r : s.split("\\|")) if (Runes.contains(r)) out.add(r);
        return out;
    }

    public static boolean scanInventory(Player player) {
        if (!creativeUnlocked(player)) {
            for (ItemStack stack : player.getInventory().items) {
                if (!stack.isEmpty() && stack.is(cn.blockforge.generated.modb22b5730.GeneratedMod.CREATION_RUNE.get())) {
                    unlockCreative(player);
                    return true;
                }
            }
        }
        Set<String> ever = everHad(player);
        boolean changed = false;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() instanceof RuneItem ri) {
                if (ever.add(ri.def().rune)) changed = true;
            }
        }
        if (changed && !creativeUnlocked(player)) {
            StringBuilder sb = new StringBuilder();
            for (String r : ever) { if (sb.length() > 0) sb.append('|'); sb.append(r); }
            of(player).putString("ever", sb.toString());
        }
        return changed;
    }

    public static String active(Player player) { return of(player).getString("active"); }
    public static void setActive(Player player, String runes) { of(player).putString("active", runes == null ? "" : runes); }

    /** 最近一次成功刻印的符文组合；独立于最近施放历史与当前编辑状态保存。 */
    public static String lastEngraved(Player player) {
        CompoundTag data = of(player);
        String saved = data.getString("last_engraved");
        // 旧存档没有独立字段时，使用当前刻印作为兼容回退。
        return saved.isEmpty() ? data.getString("active") : saved;
    }
    public static void setLastEngraved(Player player, String runes) {
        List<String> parsed = parse(runes);
        if (parsed.isEmpty()) return;
        of(player).putString("last_engraved", String.join("·", parsed));
    }

    public static long cooldownEnd(Player player) { return of(player).getLong("cooldown"); }
    public static void setCooldownEnd(Player player, long v) { of(player).putLong("cooldown", v); }

    /** 最近成功施放的三个术式，最新的在索引 0；只返回仍可解析的符文串。 */
    public static List<String> recent(Player player) {
        List<String> out = new ArrayList<>();
        ListTag stored = of(player).getList("recent", Tag.TAG_STRING);
        for (int i = 0; i < stored.size() && out.size() < RECENT_SLOTS; i++) {
            List<String> parsed = parse(stored.getString(i));
            if (parsed.isEmpty()) continue;
            String canonical = String.join("·", parsed);
            if (!out.contains(canonical)) out.add(canonical);
        }
        return out;
    }

    public static void rememberRecent(Player player, String runeString) {
        List<String> parsed = parse(runeString);
        if (parsed.isEmpty()) return;
        String canonical = String.join("·", parsed);
        List<String> values = recent(player);
        values.remove(canonical);
        values.add(0, canonical);
        ListTag stored = new ListTag();
        for (int i = 0; i < Math.min(RECENT_SLOTS, values.size()); i++)
            stored.add(StringTag.valueOf(values.get(i)));
        of(player).put("recent", stored);
    }

    public static boolean guideDone(Player player) { return of(player).getBoolean("guide"); }
    public static void setGuideDone(Player player) { of(player).putBoolean("guide", true); }

    public static List<String[]> presets(Player player) {
        ListTag list = of(player).getList("presets", Tag.TAG_COMPOUND);
        List<String[]> out = new ArrayList<>();
        for (int i = 0; i < PRESET_SLOTS; i++) out.add(new String[]{"", ""});
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            int slot = c.getInt("slot");
            if (slot >= 0 && slot < PRESET_SLOTS) out.set(slot, new String[]{c.getString("name"), c.getString("runes")});
        }
        return out;
    }

    public static void savePreset(Player player, int slot, String name, String runes) {
        List<String[]> all = presets(player);
        all.set(slot, new String[]{name, runes});
        writePresets(player, all);
    }

    public static void deletePreset(Player player, int slot) {
        List<String[]> all = presets(player);
        all.set(slot, new String[]{"", ""});
        writePresets(player, all);
    }

    private static void writePresets(Player player, List<String[]> all) {
        ListTag list = new ListTag();
        for (int i = 0; i < PRESET_SLOTS; i++) {
            if (all.get(i)[1].isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putInt("slot", i);
            c.putString("name", all.get(i)[0]);
            c.putString("runes", all.get(i)[1]);
            list.add(c);
        }
        of(player).put("presets", list);
    }

    /** 发给客户端的同步包内容。 */
    public static CompoundTag syncTag(Player player) {
        CompoundTag t = new CompoundTag();
        t.putInt("mana", mana(player));
        t.putInt("max", maxMana(player));
        t.putFloat("instability", instability(player));
        t.putFloat("proficiency", proficiency(player));
        t.putFloat("comprehension", comprehension(player));
        t.putBoolean("no_focus_unlocked", noFocusUnlocked(player));
        t.putBoolean("charging", charging(player));
        t.putInt("charge_ticks", chargeTicks(player));
        t.putInt("duplicates", duplicates(player));
        t.putBoolean("creative", creativeUnlocked(player));
        t.putString("ever", of(player).getString("ever"));
        t.putString("active", active(player));
        t.putString("last_engraved", lastEngraved(player));
        t.putLong("cooldown", cooldownEnd(player));
        t.putBoolean("guide", guideDone(player));
        t.putLong("gameTime", player.level().getGameTime());
        ListTag recent = new ListTag();
        for (String rune : recent(player)) recent.add(StringTag.valueOf(rune));
        t.put("recent", recent);
        ListTag presets = new ListTag();
        List<String[]> all = presets(player);
        for (int i = 0; i < PRESET_SLOTS; i++) {
            CompoundTag c = new CompoundTag();
            c.putInt("slot", i);
            c.putString("name", all.get(i)[0]);
            c.putString("runes", all.get(i)[1]);
            presets.add(c);
        }
        t.put("presets", presets);
        return t;
    }

    public static List<String> parse(String runeString) {
        List<String> out = new ArrayList<>();
        if (runeString == null || runeString.isEmpty() || runeString.length() > 1024) return out;
        String[] tokens = runeString.split("·", -1);
        if (tokens.length > 64) return out;
        for (String r : tokens) {
            if (!Runes.contains(r)) return new ArrayList<>(); // 未知符文整串拒绝，避免静默变成另一种法术
            out.add(r);
        }
        return out;
    }

    private PrayerData() {}
}
