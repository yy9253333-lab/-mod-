package yourmodid.client;

/** 客户端法阵动画状态；需由客户端 tick 事件调用 clientTick()。 */
public final class ArrayAnchorState {
    private static long tick = 0L;
    private ArrayAnchorState() {}
    public static long getTick() { return tick; }
    public static void clientTick() { tick++; }
    public static void reset() { tick = 0L; }
}
