package yourmodid.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

public final class ArrayAnchorRenderer {
    private static final String MODID = "yourmodid";
    private static final ResourceLocation[] RING_TEX = {
        new ResourceLocation(MODID, "textures/effect/array/ring_inner.png"),
        new ResourceLocation(MODID, "textures/effect/array/ring_middle.png"),
        new ResourceLocation(MODID, "textures/effect/array/ring_outer.png"),
        new ResourceLocation(MODID, "textures/effect/array/nodes.png")
    };

    private static final float ARRAY_SIZE = 1.5f;
    private static final float DISTANCE = 2.0f;

    private ArrayAnchorRenderer() {}

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;

        Camera camera = event.getCamera();
        PoseStack poseStack = event.getPoseStack();
        float time = ArrayAnchorState.getTick() + event.getPartialTick();
        float[] angles = { time * 0.010f, -time * 0.015f, time * 0.020f, 0.0f };

        poseStack.pushPose();
        try {
            poseStack.translate(-camera.getPosition().x, -camera.getPosition().y, -camera.getPosition().z);
            poseStack.mulPose(camera.rotation());
            poseStack.translate(0.0, 0.0, DISTANCE);

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);

            Tesselator tessellator = Tesselator.getInstance();
            for (int i = 0; i < RING_TEX.length; i++) {
                poseStack.pushPose();
                try {
                    poseStack.mulPose(Axis.ZP.rotation(angles[i]));
                    Matrix4f matrix = poseStack.last().pose();
                    RenderSystem.setShaderTexture(0, RING_TEX[i]);
                    BufferBuilder buffer = tessellator.getBuilder();
                    buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
                    float half = ARRAY_SIZE * 0.5f;
                    buffer.vertex(matrix, -half, -half, 0).uv(0, 1).color(1, 1, 1, 1).endVertex();
                    buffer.vertex(matrix, -half, half, 0).uv(0, 0).color(1, 1, 1, 1).endVertex();
                    buffer.vertex(matrix, half, half, 0).uv(1, 0).color(1, 1, 1, 1).endVertex();
                    buffer.vertex(matrix, half, -half, 0).uv(1, 1).color(1, 1, 1, 1).endVertex();
                    tessellator.end();
                } finally {
                    poseStack.popPose();
                }
            }
        } finally {
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            poseStack.popPose();
        }
    }
}
