# 《祈愿》相机绑定法阵源码组件

目标环境：Minecraft Java 1.20.1 / Forge 47.x / Java 17。

## 目录内容
- `src/main/java/yourmodid/client/ArrayAnchorRenderer.java`：绘制四层法阵，前三层旋转，节点层不旋转。
- `src/main/java/yourmodid/client/ArrayAnchorState.java`：动画计时状态。
- `src/main/resources/assets/yourmodid/textures/effect/array/`：法阵 PNG 放置目录。

## 接入现有模组前必须修改
1. 将 Java 包名 `yourmodid.client` 改为你项目实际的包名。
2. 将 `MODID = "yourmodid"` 改为实际 mod ID。
3. 将四张 PNG 放到 `assets/<实际modid>/textures/effect/array/`，文件名保持一致。
4. 在客户端初始化时注册渲染事件：`MinecraftForge.EVENT_BUS.register(ArrayAnchorRenderer.class);`
5. 在客户端 tick 事件中调用 `ArrayAnchorState.clientTick()`，否则动画时间不会正常推进。

## 注意
这是可整合进现有 Forge 工程的源码组件 ZIP，不是可直接放进游戏的 JAR，也不是完整 Gradle 工程。代码尚未在你的实际项目中编译或实机验证；相机矩阵、法阵朝向和距离需要进入游戏确认。不要把本 ZIP 直接放进 mods 文件夹。
