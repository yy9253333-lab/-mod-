package cn.blockforge.generated.modb22b5730.client;

import cn.blockforge.generated.modb22b5730.data.PrayerData;
import cn.blockforge.generated.modb22b5730.item.RuneItem;
import cn.blockforge.generated.modb22b5730.net.PrayerNet;
import cn.blockforge.generated.modb22b5730.rune.RuneGroup;
import cn.blockforge.generated.modb22b5730.rune.Runes;
import cn.blockforge.generated.modb22b5730.spell.CodexData;
import cn.blockforge.generated.modb22b5730.spell.SpellCalculator;
import cn.blockforge.generated.modb22b5730.spell.SpellStats;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.*;

/**
 * 《祈愿》魔导书界面：
 * 组阵（点击左侧已收集符文 → 中间法阵 → 右侧实时预览阶位/耗魔/伤害 → 刻印）
 * 图鉴（与原网页一致的全量条目 + 搜索 + 详情）
 * 预制（10 个命名槽位，保存在玩家自身数据）
 * 引导（首次打开自动弹出的交互教程）
 */
public class BookScreen extends Screen {
    private static final int GW = 384, GH = 240;
    private static final int PANEL = 0xF012161B, BORDER = 0xFF3D6B7C, HEAD = 0xFFBFE7FF, TEXT = 0xFFE8E4DA, DIM = 0xFF9A948A, GOLD = 0xFFD9B45B, RED = 0xFFE06060, GREEN = 0xFF8FD4A0;

    private int tab = 0;
    private final List<String> circle = new ArrayList<>();
    private int paletteScroll = 0;
    private int wheelPage = 0;
    private int codexPage = 0;
    private CodexData.Spell selectedSpell = null;
    private boolean codexOwnedOnly = false;
    private List<CodexData.Spell> codexFiltered = null;
    private String codexSearch = "";
    // 分页懒加载状态：当前页切片 + 详情推演缓存 + 异常计数
    private List<CodexData.Spell> codexSlice = List.of();
    private int codexSlicePage = -1;
    private List<CodexData.Spell> codexSliceSource = null;
    private int codexSkipped = 0;
    private CodexData.Spell codexDetailFor = null;
    private SpellStats codexDetailStats = null;
    private boolean codexDetailFailed = false;
    private int guidePage = 0;
    private EditBox searchBox, presetBox;
    private final List<Object[]> hotspots = new ArrayList<>();
    private int left, top;

    public BookScreen() {
        super(Component.literal("《祈愿》魔导书"));
    }

    @Override
    protected void init() {
        super.init();
        left = (width - GW) / 2;
        top = (height - GH) / 2;
        if (!PrayerState.guideDone) tab = 3;
        searchBox = new EditBox(font, left + 30, top + 28, 130, 16, Component.literal("搜索"));
        searchBox.setMaxLength(24);
        searchBox.setResponder(s -> { codexSearch = s; codexFiltered = null; codexPage = 0; });
        addRenderableWidget(searchBox);
        presetBox = new EditBox(font, left + 60, top + 28, 120, 16, Component.literal("预制名称"));
        presetBox.setMaxLength(24);
        addRenderableWidget(presetBox);
        syncWidgets();
    }

    private void syncWidgets() {
        searchBox.setVisible(tab == 1);
        searchBox.active = tab == 1;
        presetBox.setVisible(tab == 2);
        presetBox.active = tab == 2;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTicks) {
        renderBackground(g);
        hotspots.clear();
        g.fill(left - 2, top - 2, left + GW + 2, top + GH + 2, 0xFF26221A);
        g.fill(left, top, left + GW, top + GH, PANEL);
        g.drawString(font, "《祈愿》魔导书", left + 8, top + 8, HEAD);
        String[] tabs = {"组阵", "图鉴", "预制", "引导"};
        for (int i = 0; i < 4; i++) {
            int x = left + 110 + i * 66;
            boolean activeTab = tab == i;
            g.fill(x, top + 4, x + 60, top + 20, activeTab ? BORDER : 0xFF2A3038);
            g.drawCenteredString(font, tabs[i], x + 30, top + 7, activeTab ? 0xFFFFFFFF : DIM);
            final int tabIndex = i;
            hotspot(x, top + 4, 60, 16, () -> { tab = tabIndex; syncWidgets(); }, null);
        }
        // 视图级兜底：单个页签渲染异常时显示错误占位，不再让整个界面（乃至客户端）崩溃。
        try {
            switch (tab) {
                case 0 -> renderCompose(g, mouseX, mouseY);
                case 1 -> renderCodex(g, mouseX, mouseY);
                case 2 -> renderPresets(g, mouseX, mouseY);
                default -> renderGuide(g, mouseX, mouseY);
            }
        } catch (Throwable t) {
            g.drawString(font, "该页渲染出现异常（已防御，界面不会崩溃）", left + 12, top + 60, RED);
            g.drawString(font, "可切换到其他页签继续使用", left + 12, top + 74, DIM);
        }
        // 底部：当前刻印与魔力
        g.drawString(font, "已收集符文 " + PrayerState.ever.size() + "/" + Runes.DATA.size() + "    魔力 " + (PrayerState.creative ? "∞（创造）" : PrayerState.mana + "/" + PrayerState.maxMana), left + 8, top + GH - 10, PrayerState.creative ? GOLD : DIM);
        SpellStats cur;
        try { cur = SpellCalculator.calculate(circle); } catch (Throwable t) { cur = new SpellStats(); }
        String act = PrayerState.active.isEmpty() ? "（未刻印）" : PrayerState.active;
        g.drawString(font, "刻印：" + clip(act, 40), left + 210, top + GH - 10, PrayerState.active.isEmpty() ? DIM : GOLD);
        super.render(g, mouseX, mouseY, partialTicks);
        renderTooltips(g, mouseX, mouseY);
    }

    // ───────────────────────── 组阵 ─────────────────────────
    private void renderCompose(GuiGraphics g, int mouseX, int mouseY) {
        // 左/中：实时符文轮盘（8 层，每层选入一个符文；每页 6 个候选符文）。
        int panelX = left + 8, panelY = top + 28;
        int centerX = left + 105, centerY = top + 102;
        List<String> choices = wheelChoices();
        int pageCount = Math.max(1, (choices.size() + 5) / 6);
        wheelPage = Math.max(0, Math.min(wheelPage, pageCount - 1));
        g.fill(panelX, panelY, left + 210, top + 186, 0xFF0C0F13);
        g.drawCenteredString(font, "实时符文轮盘 · 第 " + Math.min(8, circle.size() + 1) + "/8 层", centerX, panelY + 2, HEAD);
        // 当前轮盘环
        drawRing(g, centerX, centerY, 48, 0xFF315364);
        drawRing(g, centerX, centerY, 35, 0x553D6B7C);
        if (!circle.isEmpty()) drawRing(g, centerX, centerY, 25, 0xAA6FA8B8);
        for (int i = 0; i < 6; i++) {
            int index = wheelPage * 6 + i;
            if (index >= choices.size()) break;
            String rune = choices.get(index);
            double angle = -Math.PI / 2 + i * Math.PI / 3;
            int sx = (int) Math.round(centerX + Math.cos(angle) * 48) - 12;
            int sy = (int) Math.round(centerY + Math.sin(angle) * 48) - 12;
            Runes.Def def = Runes.get(rune);
            int runeColor = def == null ? 0xFF8DB6C7 : 0xFF000000 | def.color;
            g.fill(sx, sy, sx + 24, sy + 24, circle.contains(rune) ? 0xFF274D3A : 0xFF17242D);
            g.renderOutline(sx, sy, 24, 24, runeColor);
            g.drawCenteredString(font, rune, sx + 12, sy + 7, circle.contains(rune) ? GREEN : TEXT);
            hotspot(sx, sy, 24, 24, () -> addRune(rune), tooltipFor(rune), () -> removeRune(rune));
        }
        // 中心展示已构建层，最近两层保留可视反馈；更早层收进计数，避免挤满轮盘。
        g.fill(centerX - 24, centerY - 22, centerX + 24, centerY + 22, 0xFF101820);
        g.renderOutline(centerX - 24, centerY - 22, 48, 44, BORDER);
        g.drawCenteredString(font, circle.isEmpty() ? "起始" : "已选 " + circle.size(), centerX, centerY - 13, GOLD);
        if (!circle.isEmpty()) {
            String last = circle.get(circle.size() - 1);
            g.drawCenteredString(font, last, centerX, centerY + 1, TEXT);
        }
        if (circle.size() > 1) {
            String prev = circle.get(circle.size() - 2);
            g.drawCenteredString(font, "·" + prev, centerX, centerY + 12, DIM);
        }
        button(g, left + 10, top + 166, 42, "上一页", () -> wheelPage = Math.max(0, wheelPage - 1));
        g.drawCenteredString(font, (wheelPage + 1) + "/" + pageCount + "页", left + 105, top + 169, DIM);
        button(g, left + 158, top + 166, 42, "下一页", () -> wheelPage = Math.min(pageCount - 1, wheelPage + 1));
        // 右：实时预览
        int rx = left + 220, ry = top + 28;
        g.drawString(font, "术式推演", rx, ry, HEAD);
        SpellStats st = SpellCalculator.calculate(circle);
        int y = ry + 14;
        y = line(g, rx, y, "名称：" + st.name, GOLD);
        y = line(g, rx, y, "符文串：" + clip(st.runeString, 26), DIM);
        y = line(g, rx, y, "阶位：" + st.tier + (st.forbidden ? "（禁忌）" : ""), st.forbidden ? RED : HEAD);
        y = line(g, rx, y, "法阵：" + st.array + " · 稳定节点 " + st.stabilizers, TEXT);
        y = line(g, rx, y, "符文数：" + st.runeCount, TEXT);
        int manaColor = PrayerState.creative ? GREEN : (st.manaTotal > PrayerState.mana ? RED : GREEN);
        String manaLabel = PrayerState.creative ? "魔力消耗：0（创造模式豁免，原始消耗 " + st.manaTotal + "）" : "魔力消耗：" + st.manaTotal + (st.sustainPerSecond > 0 ? "（+" + st.sustainPerSecond + "/秒×" + st.duration + "秒）" : "");
        y = line(g, rx, y, manaLabel, manaColor);
        y = line(g, rx, y, "预估伤害：" + (st.hasDamage ? st.damage + " · " + SpellCalculator.damageTypeLabel(st.damageType) : "非伤害术式"), st.hasDamage ? TEXT : DIM);
        y = line(g, rx, y, "效果值：" + st.effectTotal + "（疗" + st.healing + "/控" + st.control + "/辅" + st.utility + "）", TEXT);
        if (!st.valid) {
            // 不完整的术式没有有效构建时间，避免显示误导性的 0.0s
            y = line(g, rx, y, "构建时间：--　冷却：--", DIM);
        } else {
            y = line(g, rx, y, String.format(Locale.ROOT, "构建时间：%.1fs · 冷却 %s", st.buildTime, st.flash ? "无（瞬发）" : st.cooldownTicks / 20.0 + "s"), st.flash ? GREEN : TEXT);
        }
        if (st.flash) y = line(g, rx, y, "「瞬」：无视冷却，耗魔×1.6", GREEN);
        if (st.hasSource) y = line(g, rx, y, "「源」：耗魔-30%，威力+30%", HEAD);
        if (st.codexMatch != null) y = line(g, rx, y, "图鉴匹配：" + st.codexMatch, GOLD);
        if (!st.valid) y = line(g, rx, y, st.error, RED);
        // 按钮
        button(g, left + 8, top + 192, 60, "刻印", () -> PrayerNet.sendEngrave(String.join("·", circle)));
        button(g, left + 74, top + 192, 44, "清空", this::clearCurrentComposition);
        button(g, left + 124, top + 192, 60, "存为预制", () -> { tab = 2; syncWidgets(); });
        g.drawString(font, "符文左键加入 / 右键取消单个 · 右键法杖施法", left + 8, top + 208, DIM);
        g.drawString(font, "滚轮 / Alt+Q、Alt+E 切换最近法术", left + 8, top + 218, DIM);
        int recentX = left + 220;
        g.drawString(font, "最近施放（点按切换）", recentX, top + 193, DIM);
        for (int i = 0; i < PrayerData.RECENT_SLOTS; i++) {
            final int slot = i;
            String rune = i < PrayerState.recent.size() ? PrayerState.recent.get(i) : "";
            String label = rune.isEmpty() ? "空" : recentName(rune);
            if (!rune.isEmpty() && rune.equals(PrayerState.active)) label = ">" + label;
            button(g, recentX + i * 52, top + 202, 48, label, () -> loadRecentSpell(slot));
        }
    }

    private List<Object[]> paletteRows() {
        List<Object[]> rows = new ArrayList<>();
        for (RuneGroup g : RuneGroup.values()) {
            List<String> owned = new ArrayList<>();
            for (String r : Runes.BY_GROUP.get(g.id)) if (PrayerState.ever.contains(r)) owned.add(r);
            rows.add(new Object[]{0, "【" + g.label + "】" + owned.size() + "/" + Runes.BY_GROUP.get(g.id).size(), 0xFF7C9BB5});
            for (String r : owned) rows.add(new Object[]{1, r, 0});
        }
        if (PrayerState.ever.isEmpty()) rows.add(new Object[]{0, "尚未收集符文：合成或探索地牢宝箱", 0xFF9A948A});
        return rows;
    }

    private int countInCircle(String rune) {
        int n = 0;
        for (String r : circle) if (r.equals(rune)) n++;
        return n;
    }

    private void addRune(String rune) {
        // 新轮盘最多 8 层；已载入的旧线性术式仍按原数据计算与刻印，不会在读入时被截断。
        if (circle.size() >= 8) return;
        circle.add(rune);
    }

    private void removeRune(String rune) {
        // 右键只移除一个匹配项，不清空整组，也不影响其他符文。
        circle.remove(rune);
    }

    /** 只清空当前编辑中的组合；最近施法记录保存在玩家数据中，不受此操作影响。 */
    private void clearCurrentComposition() {
        circle.clear();
    }

    /** 点击最近施法时同时恢复编辑区与实时参数预览，并同步服务器当前刻印。 */
    private void loadRecentSpell(int slot) {
        if (slot < 0 || slot >= PrayerState.recent.size()) return;
        String savedRunes = PrayerState.recent.get(slot);
        List<String> parsed = PrayerData.parse(savedRunes);
        if (parsed.isEmpty()) return;
        circle.clear();
        circle.addAll(parsed);
        PrayerNet.sendRecentSlot(slot);
    }

    private List<String> wheelChoices() {
        List<String> out = new ArrayList<>();
        for (String rune : Runes.DATA.keySet()) if (PrayerState.creative || PrayerState.ever.contains(rune)) out.add(rune);
        return out;
    }

    private List<Component> tooltipFor(String rune) {
        Runes.Def d = Runes.get(rune);
        if (d == null) return null;
        return List.of(Component.literal("符文·" + d.rune).withStyle(ChatFormatting.YELLOW),
            Component.literal(d.group.label + " · " + d.desc).withStyle(ChatFormatting.GRAY),
            Component.literal("魔力 " + d.mana + " · 伤害 " + d.damage + (d.sustain > 0 ? " · 持续 " + d.sustain + "/秒" : "")).withStyle(ChatFormatting.AQUA));
    }

    // ───────────────────────── 图鉴（分页懒加载 + 空值防御渲染） ─────────────────────────
    private void renderCodex(GuiGraphics g, int mouseX, int mouseY) {
        if (codexFiltered == null) buildCodexFilter();
        // 分页懒加载：只在页码/过滤条件变化时重建当前页切片，单页出错只影响本页。
        if (codexSlicePage != codexPage || codexSliceSource != codexFiltered) {
            codexSlicePage = codexPage; codexSliceSource = codexFiltered;
            codexSlice = new ArrayList<>();
            int per = 10;
            for (int i = codexPage * per; i < Math.min(codexFiltered.size(), codexPage * per + per); i++) {
                CodexData.Spell s = codexFiltered.get(i);
                if (s == null || s.rune() == null || s.rune().isEmpty()) continue; // 异常条目不进本页切片
                codexSlice.add(s);
            }
            codexDetailFor = null; // 翻页后详情缓存失效
        }
        g.drawString(font, "法术图鉴（共 " + codexFiltered.size() + " 条" + (codexSkipped > 0 ? "，已跳过 " + codexSkipped + " 条异常数据" : "") + "）", left + 8, top + 24, DIM);
        button(g, left + 168, top + 26, 70, codexOwnedOnly ? "仅已解锁" : "全部条目", () -> { codexOwnedOnly = !codexOwnedOnly; codexFiltered = null; codexPage = 0; });
        int lx = left + 8, ly = top + 48, lw = 230, lh = 160;
        g.fill(lx, ly, lx + lw, ly + lh, 0xFF0C0F13);
        int per = 10;
        g.enableScissor(lx, ly, lx + lw, ly + lh);
        for (int i = 0; i < codexSlice.size(); i++) {
            CodexData.Spell s = codexSlice.get(i);
            int ry = ly + i * 16 + 2;
            // 单条渲染兜底：任何一条数据异常只画占位行，不再让整页乃至整个客户端闪退。
            try {
                boolean sel = selectedSpell != null && selectedSpell.rune().equals(s.rune());
                if (sel) g.fill(lx + 1, ry - 2, lx + lw - 1, ry + 14, 0x336FB8FF);
                g.drawString(font, clip(nameOf(s), 12), lx + 4, ry + 2, sel ? GREEN : TEXT);
                g.drawString(font, clip(runeOf(s), 16), lx + 96, ry + 2, DIM);
                String tier = tierOf(s);
                g.drawString(font, tier, lx + 196, ry + 2, tier.contains("禁忌") ? RED : HEAD);
                final CodexData.Spell picked = s;
                hotspot(lx + 1, ry - 2, lw - 2, 16, () -> selectedSpell = picked, null);
            } catch (Throwable t) {
                g.drawString(font, "—— 条目数据异常，已跳过 ——", lx + 4, ry + 2, RED);
            }
        }
        g.disableScissor();
        int pages = Math.max(1, (codexFiltered.size() + per - 1) / per);
        button(g, lx, top + 212, 40, "上一页", () -> codexPage = Math.max(0, codexPage - 1));
        button(g, lx + 46, top + 212, 40, "下一页", () -> codexPage = Math.min(pages - 1, codexPage + 1));
        g.drawString(font, (codexPage + 1) + "/" + pages + " 页", lx + 96, top + 215, DIM);
        // 详情：只对当前选中条目做一次推演并缓存（懒加载），失败降级为占位文案。
        int dx = left + 246, dy = top + 48;
        g.drawString(font, "条目详情", dx, top + 24, HEAD);
        if (selectedSpell == null) {
            g.drawString(font, "点击左侧条目查看", dx, dy + 10, DIM);
            return;
        }
        if (codexDetailFor != selectedSpell) {
            codexDetailFor = selectedSpell;
            codexDetailFailed = false;
            try { codexDetailStats = SpellCalculator.calculate(PrayerData.parse(selectedSpell.rune())); }
            catch (Throwable t) { codexDetailStats = null; codexDetailFailed = true; }
        }
        if (codexDetailFailed) {
            int y0 = dy;
            y0 = line(g, dx, y0, "名称：" + nameOf(selectedSpell), GOLD);
            y0 = line(g, dx, y0, "符文：" + clip(runeOf(selectedSpell), 24), TEXT);
            y0 = line(g, dx, y0, "推演数据异常（已防御，不再崩溃）", RED);
            line(g, dx, y0, "该条目注册数据不完整，可用 /qiyuan selftest 复查", DIM);
            return;
        }
        SpellStats st = codexDetailStats;
        int y = dy;
        y = line(g, dx, y, "名称：" + nameOf(selectedSpell), GOLD);
        y = line(g, dx, y, "符文：" + clip(runeOf(selectedSpell), 24), TEXT);
        y = line(g, dx, y, "阶位：" + CodexData.safe(st.tier, "?"), HEAD);
        y = line(g, dx, y, "法阵：" + CodexData.safe(st.array, "?"), TEXT);
        y = line(g, dx, y, "魔力：" + st.manaTotal, GREEN);
        y = line(g, dx, y, "伤害：" + (st.hasDamage ? st.damage + " " + SpellCalculator.damageTypeLabel(st.damageType) : "无"), TEXT);
        y = line(g, dx, y, "效果：" + st.effectTotal, TEXT);
        y = line(g, dx, y, String.format(Locale.ROOT, "构建：%.1fs", st.buildTime), TEXT);
        Component descLine = Component.literal(CodexData.safe(effectOf(selectedSpell), "（此条目缺少描述）"));
        int clipRight = left + GW - 8;
        int clipBottom = top + GH - 16;
        if (clipRight > dx && clipBottom > y) {
            g.enableScissor(dx, y, clipRight, clipBottom);
            try {
                g.drawWordWrap(font, descLine, dx, y, clipRight - dx - 2, DIM);
            } finally {
                g.disableScissor();
            }
        }
        button(g, dx, top + 206, 60, "载入法阵", () -> { circle.clear(); circle.addAll(PrayerData.parse(selectedSpell.rune())); tab = 0; syncWidgets(); });
    }

    private String recentName(String runeString) {
        try {
            SpellStats stats = SpellCalculator.calculate(PrayerData.parse(runeString));
            String name = stats.valid ? CodexData.safe(stats.name, runeString) : runeString;
            return clip(name, 5);
        } catch (RuntimeException ex) {
            return clip(runeString, 5);
        }
    }

    // 空值防御访问器：字段为 null 时给占位显示，绝不让 drawString 崩掉渲染帧。
    private static String nameOf(CodexData.Spell s) { return s == null ? "（空条目）" : CodexData.safe(s.name(), "未名术式"); }
    private static String runeOf(CodexData.Spell s) { return s == null ? "" : CodexData.safe(s.rune(), ""); }
    private static String tierOf(CodexData.Spell s) { return s == null ? "?" : CodexData.safe(s.tier(), "一阶"); }
    private static String effectOf(CodexData.Spell s) { return s == null ? null : s.effect(); }

    private void buildCodexFilter() {
        codexFiltered = new ArrayList<>();
        codexSkipped = 0;
        for (CodexData.Spell s : CodexData.SPELLS) {
            if (s == null || s.rune() == null || s.rune().isEmpty()) { codexSkipped++; continue; }
            if (!codexSearch.isEmpty() && !nameOf(s).contains(codexSearch) && !s.rune().contains(codexSearch)) continue;
            if (codexOwnedOnly) {
                boolean owned = true;
                for (String r : PrayerData.parse(s.rune())) if (!PrayerState.ever.contains(r)) { owned = false; break; }
                if (!owned) continue;
            }
            codexFiltered.add(s);
        }
    }

    // ───────────────────────── 预制 ─────────────────────────
    private void renderPresets(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, "预制术式（保存在玩家自身数据，共 10 槽）", left + 8, top + 24, DIM);
        g.drawString(font, "命名：", left + 8, top + 32, TEXT);
        for (int i = 0; i < PrayerData.PRESET_SLOTS; i++) {
            final int slotIndex = i;
            String[] p = PrayerState.presets.get(i);
            int ry = top + 50 + i * 15;
            g.drawString(font, (i + 1) + ".", left + 8, ry, DIM);
            g.drawString(font, p[0].isEmpty() ? "空" : clip(p[0], 8), left + 24, ry, p[0].isEmpty() ? DIM : GOLD);
            g.drawString(font, clip(p[1], 40), left + 96, ry, p[1].isEmpty() ? DIM : TEXT);
            button(g, left + 280, ry - 2, 30, "保存", () -> {
                String runes = circle.isEmpty() ? PrayerState.active : String.join("·", circle);
                String name = presetBox.getValue().isEmpty() ? "预制" + (slotIndex + 1) : presetBox.getValue();
                PrayerNet.sendPreset(slotIndex, name, runes);
            });
            button(g, left + 312, ry - 2, 30, "载入", () -> { circle.clear(); circle.addAll(PrayerData.parse(p[1])); tab = 0; syncWidgets(); });
            button(g, left + 344, ry - 2, 30, "删除", () -> PrayerNet.sendPreset(slotIndex, "", ""));
        }
        g.drawString(font, "保存内容：当前法阵（若为空则保存已刻印术式）", left + 8, top + 214, DIM);
    }

    // ───────────────────────── 引导 ─────────────────────────
    private static final String[][] GUIDE = {
        {"欢迎使用《祈愿》魔导书", "这本书记载了你收集过的所有符文与术式。", "所有数据都保存在你自己的角色身上，换床重生也不会丢。", "", "① 组阵：把收集到的符文摆进法阵", "② 推演：右侧实时显示阶位、耗魔与预估伤害", "③ 刻印：点「刻印」把术式写入本书", "④ 法杖右键施法；潜行右键打开法阵台", "⑤ 滚轮或 Alt+Q/E 切换最近三种术式", "点右下角「下一页」继续"},
        {"收集符文", "七大类符文：目标 / 元素 / 远古 / 效果 / 形态 / 修饰 / 抗性。", "获取方式一：合成台 —— 魔素结晶 + 对应材料。", "魔素结晶 = 紫水晶碎片 + 荧石粉 + 红石（或开箱、吃结晶回蓝）。", "获取方式二：地牢、遗迹、末地城等宝箱会按稀有度掉落符文。", "远古符文（禁忌）最稀有，威力巨大但耗魔惊人。", "", "只要拥有过一次，符文就会永久解锁进本书。"},
        {"组阵与推演", "在「组阵」页点击左侧符文加入中央法阵（最多 16 枚）。", "点击法阵中的符文可以移除。", "右侧即时推演：阶位由符文总数决定（超过 12 枚为五阶）。", "含远古符文 → 禁忌阶：固定附加 2000 魔力消耗。", "耗魔与伤害公式与原《祈愿》魔法生成器网页一致。", "预览为红色表示魔力不足或组合不完整。"},
        {"魔力与冷却", "屏幕左下角蓝色条是你的魔力槽（上限随经验等级提升）。", "施法消耗魔力；魔力随时间缓慢恢复。", "右键吃掉「魔素结晶」可立即 +100 魔力。", "构建时间越长，施法后冷却越久。", "「瞬」符文：无视冷却瞬间释放，", "但模组规则下耗魔提升至 ×1.6 —— 蓝条会掉得更明显！", "「倍」威力×1.8 耗魔×3，「微」各减半，「裂」分裂成三发。"},
        {"图鉴与预制", "「图鉴」页收录了与原网页一致的全量术式条目，可搜索。", "点条目查看推演详情，可一键载入法阵。", "「预制」页可保存 10 个命名术式，随时载入或刻印。", "组阵页还可点按最近三术式，触屏设备也能快速切换。", "", "祝你旅途愉快，愿你的祈愿得到回应。"},
    };

    private void renderGuide(GuiGraphics g, int mouseX, int mouseY) {
        String[] page = GUIDE[guidePage];
        g.drawString(font, "新手引导（" + (guidePage + 1) + "/" + GUIDE.length + "）", left + 8, top + 24, HEAD);
        int y = top + 44;
        boolean first = true;
        for (String s : page) {
            g.drawString(font, s, left + 12, y, first ? GOLD : TEXT);
            first = false;
            y += 14;
        }
        button(g, left + 8, top + 206, 50, "上一页", () -> guidePage = Math.max(0, guidePage - 1));
        if (guidePage < GUIDE.length - 1)
            button(g, left + 64, top + 206, 50, "下一页", () -> guidePage++);
        else
            button(g, left + 64, top + 206, 60, "开始使用", () -> { PrayerNet.sendGuideDone(); tab = 0; syncWidgets(); });
        button(g, left + 300, top + 206, 40, "跳过", () -> { PrayerNet.sendGuideDone(); tab = 0; syncWidgets(); });
    }

    // ───────────────────────── 工具 ─────────────────────────
    /** 使用原版 GUI 像素绘制圆环，避免依赖桌面 OpenGL/AWT API，兼容 FCL 渲染路径。 */
    private void drawRing(GuiGraphics g, int cx, int cy, int radius, int color) {
        for (int i = 0; i < 120; i++) {
            double angle = Math.PI * 2.0 * i / 120.0;
            int x = (int) Math.round(cx + Math.cos(angle) * radius);
            int y = (int) Math.round(cy + Math.sin(angle) * radius);
            g.fill(x, y, x + 2, y + 2, color);
        }
    }

    private void hotspot(int x, int y, int w, int h, Runnable action, List<Component> tooltip) {
        hotspot(x, y, w, h, action, tooltip, null);
    }

    private void hotspot(int x, int y, int w, int h, Runnable action, List<Component> tooltip, Runnable rightAction) {
        hotspots.add(new Object[]{new int[]{x, y, w, h}, action, tooltip, rightAction});
    }

    private void button(GuiGraphics g, int x, int y, int w, String label, Runnable action) {
        g.fill(x, y, x + w, y + 14, 0xFF22303C);
        g.renderOutline(x, y, w, 14, BORDER);
        g.drawCenteredString(font, label, x + w / 2, y + 3, TEXT);
        hotspot(x, y, w, 14, action, null);
    }

    private int line(GuiGraphics g, int x, int y, String text, int color) {
        g.drawString(font, text, x, y, color);
        return y + 11;
    }

    private String clip(String s, int max) {
        if (s == null) s = "";
        if (max <= 0) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button == 0 || button == 1) {
            for (int i = hotspots.size() - 1; i >= 0; i--) {
                Object[] h = hotspots.get(i);
                int[] r = (int[]) h[0];
                if (mouseX >= r[0] && mouseX < r[0] + r[2] && mouseY >= r[1] && mouseY < r[1] + r[3]) {
                    Runnable action = button == 1 ? (h.length > 3 ? (Runnable) h[3] : null) : (Runnable) h[1];
                    if (action != null) { action.run(); return true; }
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (tab == 0 && mouseX > left + 8 && mouseX < left + 210 && mouseY > top + 28 && mouseY < top + 186) {
            int pages = Math.max(1, (wheelChoices().size() + 5) / 6);
            wheelPage = Math.max(0, Math.min(pages - 1, wheelPage - (int) Math.signum(delta)));
            return true;
        }
        if (tab == 1) {
            if (codexFiltered == null) buildCodexFilter();
            int pages = Math.max(1, (codexFiltered.size() + 9) / 10);
            codexPage = Math.max(0, Math.min(pages - 1, codexPage - (int) Math.signum(delta)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @SuppressWarnings("unchecked")
    private void renderTooltips(GuiGraphics g, int mouseX, int mouseY) {
        for (Object[] h : hotspots) {
            int[] r = (int[]) h[0];
            if (h[2] != null && mouseX >= r[0] && mouseX < r[0] + r[2] && mouseY >= r[1] && mouseY < r[1] + r[3]) {
                g.renderTooltip(font, (List<Component>) h[2], Optional.empty(), mouseX, mouseY);
                return;
            }
        }
    }

    @Override public boolean isPauseScreen() { return false; }
}
