# 奥术小法杖（Forge 1.20.1）

这是一个独立的 Minecraft Forge 1.20.1 模组源码工程。

## 当前包含
- 右键使用奥术小法杖发射实体魔法弹。
- 魔法弹具有真实飞行轨迹、实体/方块碰撞、伤害和击退。
- 飞行时生成粒子拖尾，命中时生成蓝白风格的粒子爆发。
- 法杖有耐久与短冷却。
- 注册实体采用 Forge 网络生成数据包，其他玩家可同步看到实体。

## 尚未完成
- 当前使用原版粒子组合模拟效果，不是最终的多层自定义渲染。
- 法杖与能量球的 PNG 贴图尚未提供。请把 `arcane_wand.png` 和 `arcane_orb.png` 放入：
  `src/main/resources/assets/arcanewand/textures/item/`
- 目前还没有 Blockbench 3D 法杖模型、施法前置法阵、资源包自定义音效、配置菜单。
- 代码尚未在本环境实际运行 Gradle 编译；需要在安装了 JDK 17 的电脑上验证。

## 编译
1. 安装 JDK 17。
2. 使用支持 Gradle 的 IDE 打开此目录，或在目录中运行：
   - Windows：`gradlew.bat build`
   - Linux/macOS：`./gradlew build`
3. 成功后在 `build/libs/` 中找到 `arcanewand-1.0.0.jar`。
4. 将 JAR 放入 Minecraft 1.20.1 Forge 实例的 `mods` 文件夹。

## 测试指令
进入创造模式后：
`/give @s arcanewand:arcane_wand`

## 兼容提醒
此工程目标是 Forge 1.20.1。Android FCL 上的表现取决于设备、渲染器和启动器环境；必须在目标实例实际测试。
