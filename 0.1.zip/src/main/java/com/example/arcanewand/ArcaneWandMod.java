package com.example.arcanewand;

import com.example.arcanewand.registry.ModEntities;
import com.example.arcanewand.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ArcaneWandMod.MOD_ID)
public class ArcaneWandMod {
    public static final String MOD_ID = "arcanewand";

    public ArcaneWandMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
    }
}
