package com.example.arcanewand.entity;

import com.example.arcanewand.registry.ModEntities;
import com.example.arcanewand.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

public class ArcaneOrbEntity extends ThrowableItemProjectile {
    private int age;

    public ArcaneOrbEntity(net.minecraft.world.entity.EntityType<? extends ArcaneOrbEntity> type, Level level) {
        super(type, level);
    }

    public ArcaneOrbEntity(Level level, LivingEntity owner) {
        super(ModEntities.ARCANE_ORB.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.ARCANE_ORB.get();
    }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (level() instanceof ServerLevel server) {
            // Sparse server-side trail; clients receive these particles through the world.
            if (tickCount % 2 == 0) {
                server.sendParticles(ParticleTypes.END_ROD, getX(), getY(), getZ(),
                        2, 0.07, 0.07, 0.07, 0.005);
                server.sendParticles(ParticleTypes.WITCH, getX(), getY(), getZ(),
                        2, 0.10, 0.10, 0.10, 0.01);
            }
        }
        if (age > 80) discard();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide) return;

        if (result.getType() == HitResult.Type.ENTITY && result instanceof EntityHitResult entityHit) {
            Entity target = entityHit.getEntity();
            if (target instanceof LivingEntity living && target != getOwner()) {
                DamageSource source = damageSources().indirectMagic(this, getOwner());
                living.hurt(source, 6.0F);
                living.knockback(0.45D, getX() - living.getX(), getZ() - living.getZ());
            }
        }

        if (level() instanceof ServerLevel server) {
            double x = result.getLocation().x;
            double y = result.getLocation().y;
            double z = result.getLocation().z;
            server.sendParticles(ParticleTypes.FLASH, x, y, z, 1, 0, 0, 0, 0);
            server.sendParticles(ParticleTypes.END_ROD, x, y, z, 24, 0.35, 0.35, 0.35, 0.08);
            server.sendParticles(ParticleTypes.WITCH, x, y, z, 18, 0.28, 0.28, 0.28, 0.04);
            server.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 12, 0.25, 0.25, 0.25, 0.04);
            server.playSound(null, x, y, z, SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.NEUTRAL, 0.8F, 1.5F);
        }
        discard();
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
