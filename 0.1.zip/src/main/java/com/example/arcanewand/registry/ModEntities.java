package com.example.arcanewand.registry;

import com.example.arcanewand.ArcaneWandMod;
import com.example.arcanewand.entity.ArcaneOrbEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ArcaneWandMod.MOD_ID);

    public static final RegistryObject<EntityType<ArcaneOrbEntity>> ARCANE_ORB =
            ENTITY_TYPES.register("arcane_orb",
                    () -> EntityType.Builder.<ArcaneOrbEntity>of(ArcaneOrbEntity::new, MobCategory.MISC)
                            .sized(0.35F, 0.35F)
                            .clientTrackingRange(64)
                            .updateInterval(1)
                            .build("arcane_orb"));

    private ModEntities() {}
}
