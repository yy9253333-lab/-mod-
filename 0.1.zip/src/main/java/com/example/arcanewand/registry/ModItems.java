package com.example.arcanewand.registry;

import com.example.arcanewand.ArcaneWandMod;
import com.example.arcanewand.item.ArcaneWandItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ArcaneWandMod.MOD_ID);

    public static final RegistryObject<Item> ARCANE_WAND = ITEMS.register("arcane_wand",
            () -> new ArcaneWandItem(new Item.Properties().stacksTo(1).durability(250)));

    public static final RegistryObject<Item> ARCANE_ORB = ITEMS.register("arcane_orb",
            () -> new Item(new Item.Properties()));

    private ModItems() {}
}
