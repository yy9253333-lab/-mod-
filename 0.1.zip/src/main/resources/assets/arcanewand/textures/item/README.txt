Add your 16x16 or 32x32 PNG textures here:
- arcane_wand.png (wand item texture)
- arcane_orb.png (orb projectile icon)
Until these PNGs are added, Minecraft will show missing-texture icons.
